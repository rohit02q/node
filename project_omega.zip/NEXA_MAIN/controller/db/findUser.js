export { db } from './db.js'
export default async function findUser(id) {
    const docRef = db.collection().doc(id)
    const userSnap = await docRef.get()
    return { _id: userSnap.id, ...userSnap.data() }
}