import admin from "firebase-admin"
import serviceAccount from "../config/firebase/key1.json" with { type: "json" }
admin.initializeApp({credential: admin.credential.cert(serviceAccount)})
// const admin1 = admin.initializeApp({credential:admin.credential.cert(serviceAccount)},"db1")
// const admin2 = admin.initializeApp({credential:admin.credential.cert(serviceAccount)},"db2")
// export const db1 = admin1.firestore()
// export const db2 = admin2.firestore()
export const db = admin.firestore()