import admin from "firebase-admin"
import serviceAccount from "../config/firebase/key1.json" with { type: "json" };
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});
export const db = admin.firestore()







import fs from "fs"
import path from "path"
const dbPath = path.resolve(import.meta.dirname, '../firebase.json')
const loadData = () => { return JSON.parse(fs.readFileSync(dbPath, "utf-8")) }
class Storage {
    static get(path) {
        let db = loadData()
        try {
            const keys = path.split('/');
            return keys.reduce((acc, key) => {
                if (acc && acc[key] !== undefined) {
                    return acc[key];
                }
                return null
            }, db)

        } catch (error) {
            console.error(error)
            return null
        }
    }

    static set(path, value) {
        try {
            let data = loadData()
            const keys = path.split('/')
            let current = data;
            keys.slice(0, -1).forEach(key => {
                if (!current[key]) {
                    current[key] = {}
                }
                current = current[key]
            });
            current[keys[keys.length - 1]] = value
            fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
            console.log('File set succesfully')
            return true
        } catch (error) {
            console.error(error)
            return false
        }
    }
    static update(path, value) {
        const preData = this.get(path)
        this.set(path, { ...preData, ...value })
    }
    static remove(path) {
        let data = loadData()
        const keys = path.split('/')
        let current = data;
        keys.slice(0, -1).forEach(key => {
            if (!current[key]) {
                current[key] = {}
            }
            current = current[key]
        });
        delete current[keys[keys.length - 1]]
        fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
    }
    static addUser(uid, userData) {
        this.set(`users/${uid}`, userData)
    }
    static increaseXp(uid, xp) {
        let preXp = this.get(`users/${uid}/xp`)
        this.set(`users/${uid}/xp`, preXp + xp)
    }
}

export default Storage