export const EDIT_TEST_SCHEMA = {
  title: "string",
  entryType: ["free", "locked"],
  entryCode: "string",
  duration: "number",
  description: "string",
  shuffle: "boolean",
  isResultHidden: "boolean",
  isSolutionsHidden: "boolean",
  isReattemptAllowed: "boolean",
  blockedUsers: "array",
  focusGuard: {
    enabled: "boolean",
    maxAwayTime: "number",
    maxTabSwitch: "number",
  },
}
export const TEST_QUESTION_SCHEMA = {
  type: ["mcq", "numeric"],
  text: "string",
  explanation: "string",
  positiveMarks: "number",
  negativeMarks: "number",
  options: "array",
  answer: "number"
}