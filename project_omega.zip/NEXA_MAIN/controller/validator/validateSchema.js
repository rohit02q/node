import { validateType } from './validateType.js'
export function validateSchema(obj, schema) {
    for (let key of Object.keys(obj)) {
        if (!schema[key]) return { valid: false, message: `Unknown field: ${key}` }
    }
    for (let key of Object.keys(schema)) {
        const type = schema[key]
        const val = obj[key]
        if (val === undefined) continue;
        if (typeof type === "object" && !Array.isArray(type)) {
            if (typeof val !== "object" || Array.isArray(val)) {
                return { valid: false, message: `${key} must be an object` }
            }
            const nested = validateSchema(val, type)
            if (!nested.valid) return nested
            continue
        }
        if (Array.isArray(type)) {
            if (!type.includes(val))
                return {
                    valid: false,
                    message: `${key} must be one of: ${type.join(", ")}`,
                };
            continue
        }
        if (!validateType(val, type)) {
            return {
                valid: false,
                message: `${key} must be type ${type}`,
            };
        }
    }
    return { valid: true }
}
