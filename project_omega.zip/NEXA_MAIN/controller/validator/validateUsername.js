export function validateUsername(username) {
    if (!username) return { ok: false, msg: 'Enter new username.' };
    const cleaned = String(username).trim().toLowerCase();
    if (cleaned.length < 4) return { ok: false, msg: 'Username must be at least 4 characters long.' };
    if (cleaned.length > 30) return { ok: false, msg: 'Username cannot exceed 30 characters.' };
    if (!/^[a-z0-9._]+$/.test(cleaned)) return { ok: false, msg: 'Username can only contain letters, numbers, dots, and underscores.' };
    if (/^[._]/.test(cleaned)) return { ok: false, msg: 'Username cannot start with a dot or underscore.' };
    if (/[._]$/.test(cleaned)) return { ok: false, msg: 'Username cannot end with a dot or underscore.' };
    if (/\.\./.test(cleaned)) return { ok: false, msg: 'Username cannot contain consecutive dots.' };
    if (/__/.test(cleaned)) return { ok: false, msg: 'Username cannot contain consecutive underscores.' };
    const dots = (cleaned.match(/\./g) || []).length;
    const underscores = (cleaned.match(/_/g) || []).length;
    if (dots > 1) return { ok: false, msg: 'Username can contain only one dot.' };
    if (underscores > 4) return { ok: false, msg: 'Username can contain at most four underscores.' };
    if (/^(\w)\1+$/.test(cleaned)) return { ok: false, msg: 'Username cannot consist of a single repeated character.' };
    const chars = cleaned.split('').map(c => c.charCodeAt(0));
    let inc = 1, dec = 1;
    for (let i = 1; i < chars.length; i++) {
      if (chars[i] === chars[i - 1] + 1) inc++; else inc = 1;
      if (chars[i] === chars[i - 1] - 1) dec++; else dec = 1;
      if (inc >= 4 || dec >= 4) return { ok: false, msg: 'Username cannot contain sequential characters.' };
    }
    const badWords = [
      'admin', 'support', 'test', 'demo', 'user', 'null', 'root', 'owner', 'superuser', 'master',
      'moderator', 'staff', 'staffmember', 'system', 'guest', 'info', 'contact', 'help', 'service',
      'manager', 'webmaster', 'security', 'mail', 'email', 'postmaster', 'noreply', 'no-reply',
      'password', 'pass', 'login', 'signup', 'account', 'billing', 'temp', 'temporary', 'trial',
      'fake', 'bot', 'robot', 'spam', 'junk', 'offer', 'free', 'discount', 'sale', 'cash', 'money',
      'win', 'winner', 'prize', 'gift', 'giveaway', 'hot', 'sex', 'xxx', 'porn', 'adult', 'erotic',
      'nude', 'fuck', 'shit', 'bitch', 'ass', 'dick', 'pussy', 'cock', 'cunt', 'whore', 'slut',
      'damn', 'crap', 'idiot', 'stupid', 'fakeuser', 'tester', 'sample', 'example', 'qwerty', 'asdf',
      'zxcv', 'abc123', '123abc', '123456', 'abcdef', 'password123','hack', 'black', 'topper',
      'king', 'funny', 'badboy', 'love','aura'
    ];
    for (const bad of badWords) {
      if (cleaned.includes(bad)) return { ok: false, msg: 'This username is not allowed.' };
    }
    return { ok: true, value: cleaned };
  }