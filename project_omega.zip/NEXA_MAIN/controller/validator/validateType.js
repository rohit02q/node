export function validateType(value, type) {
  if (type === "string") return typeof value === "string";
  if (type === "number") return typeof value === "number" && !isNaN(value);
  if (type === "boolean") return typeof value === "boolean";
  if (type === "array") return Array.isArray(value);
  if (type === "object") return typeof value === "object";
  return false;
}