import dotenv from "dotenv"
dotenv.config()
export const JWT_MASTER_KEY = process.env.JWT_1 || "JWT_MASTER_KEY_154c30a1f6d$%&%##$%@##d1iQ7e2zRgx5AS5OoENuv7aa3"
export const JWT_ACCESS_KEY = process.env.JWT_2 || "JWT_ACCESS_KEY_$2b$10$my$%#!45#%$efR4sfsrf4idwPILfVx87B0glqE"
export const JWT_REFRESH_KEY = process.env.JWT_3 || "JWT_REFRESH_KEY_1542bfAcadhIhbFmVTieEWRWR$$%#%#$15334%$5e3a7aa3"
export const MAX_REATTEMPT_LIMIT = 20
export const ACCESS_TOKEN_EXP_TIME = '30m'
export const REFRESH_TOKEN_EXP_TIME = "10d"