// ============================================
// STATE MANAGEMENT
// ============================================

const APP_STATE = {
    currentRoute: '/',
    currentUser: null,
    isLoggedIn: false,
    modalOpen: false,
    drawerOpen: false,
    currentFilter: 'all',
    searchQuery: '',
    carouselIndex: 0,
    isOffline: false,
    routeParams: {}
};

// ============================================
// SPA ROUTER SYSTEM
// ============================================
function pathToRegex(path) {
    const paramNames = [];
    const regexPath = path
        .replace(/\//g, '\\/')
        .replace(/:\w+\?/g, (match) => {
            paramNames.push(match.slice(1, -1));
            return '(?:\\/([^\\/]+))?';
        })
        .replace(/:\w+/g, (match) => {
            paramNames.push(match.slice(1));
            return '([^\\/]+)';
        });
    return { regex: new RegExp('^' + regexPath + '$'), paramNames };
}

// Route Guards
const authGuard = (params) => {
    if (!APP_STATE.isLoggedIn) {
        toast('Please login to access this page', 'error');
        navigate('/');
        return false;
    }
    return true;
};

const guestOnlyGuard = (params) => {
    if (APP_STATE.isLoggedIn) {
        toast('You are already logged in', 'normal');
        navigate('/');
        return false;
    }
    return true;
};

// Route Definitions with lazy loading and guards
const routes = [
    {
        path: '/',
        component: Home,
        title: 'Home'
    },
    {
        path: '/tests',
        component: Tests,
        title: 'Tests'
    },
    {
        path: '/tests/:id',
        component: TestDetail,
        title: 'Test Details'
    },
    {
        path: '/results',
        component: Results,
        guard: authGuard,
        title: 'Results'
    },
    {
        path: '/results/:id',
        component: ResultDetail,
        guard: authGuard,
        title: 'Result Details'
    },
    {
        path: '/create',
        component: Create,
        fullModal: true,
        guard: authGuard,
        title: 'Create Test'
    },
    {
        path: '/create/:id/edit',
        component: EditTest,
        guard: authGuard,
        title: 'Edit Test',
        fullModal: true
    },
    {
        path: '/profile',
        component: Profile,
        fullModal: true,
        guard: authGuard,
        lazy: true,
        title: 'Profile'
    },
    {
        path: '/settings',
        component: Settings,
        guard: authGuard,
        lazy: true,
        fullModal: true,
        title: 'Settings'
    },
    {
        path: '/login',
        component: Login,
        guard: guestOnlyGuard,
        fullModal: true,
        title: 'Login'
    },
    {
        path: '/logout',
        component: Logout,
        title: 'Logout'
    }
];

// Compile routes
const compiledRoutes = routes.map(r => {
    const { regex, paramNames } = pathToRegex(r.path);
    return { ...r, regex, paramNames };
});

// Router function
async function router() {
    const path = window.location.pathname || '/';
    closeSideMenu();
    closeModal()
    for (let route of compiledRoutes) {
        const match = path.match(route.regex);
        if (match) {
            const params = {};
            route.paramNames.forEach((name, i) => {
                params[name] = match[i + 1] || null;
            });

            APP_STATE.routeParams = params;

            // Route guard check
            if (route.guard && !route.guard(params)) {
                return;
            }

            // Update active tab in bottom nav
            updateActiveTab(route.path);
            // Update document title
            document.title = `Nexa - ${route.title}`;

            // Lazy load simulation or direct render
            let html;
            if (route.lazy) {
                html = '<div class="flex items-center justify-center h-full"><div class="text-center"><div class="inline-block animate-spin rounded-full h-12 w-12 border-2 border-gray loader"></div><p class="mt-4 te0xt-gray-500">Loading...</p></div></div>';
                if (route.fullModal) {
                    openModal(route.title, html)
                } else {
                    const app = document.getElementById('app');
                    app.innerHTML = html
                }
                await new Promise(resolve => setTimeout(resolve, 1500));
                html = await route.component(params);
            } else {
                html = await route.component(params);
            }
            if (route.fullModal) {
                openModal(route.title, html)
            } else {
                const app = document.getElementById('app');
                app.innerHTML = html
                app.scrollTop = 0;
            }
            updateFABVisibility(route.path);
            return;
        }
    }
    // 404 Not Found
    const app = document.getElementById('app');
    app.innerHTML = NotFoundComponent();
    document.title = "Page Not Found"
    updateActiveTab('/error')
}

// Navigation helper
function navigate(path) {
    if(path === location.pathname) return
    history.pushState({}, '', path)
    handleRouteChange()
}

// Update active tab in bottom navigation
function updateActiveTab(path) {
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => {
        tab.classList.remove('active');
        const tabPath = tab.getAttribute('href').replace('#', '');
        if (path === tabPath || (path.startsWith(tabPath) && tabPath !== '/')) {
            tab.classList.add('active');
        } else if (path === '/' && tabPath === '/') {
            tab.classList.add('active');
        }
    });
}

// Update FAB visibility based on route
function updateFABVisibility(path) {
    const fab = document.getElementById('fabBtn');
    if (path === '/create' && APP_STATE.isLoggedIn) {
        fab.classList.remove('hidden');
    } else {
        fab.classList.add('hidden');
    }
}

// ============================================
// COMPONENTS (React-like structure)
// ============================================

// Home Component
async function Home(params) {
    return `
        <div class="p-4">
            <!-- Carousel -->
            <div class="carousel-container" id="carousel">
                ${MOCK_DB.carouselSlides.map((slide, i) => `
                    <div class="carousel-slide ${i === 0 ? 'active' : ''}" data-index="${i}">
                        <h3>${slide.title}</h3>
                        <p>${slide.description}</p>
                        <button class="btn-primary" onclick="navigate('${slide.cta === 'Create Now' ? '/create' : '/tests'}')">${slide.cta}</button>
                    </div>
                `).join('')}
            </div>
            <div class="carousel-dots">
                ${MOCK_DB.carouselSlides.map((_, i) => `
                    <div class="carousel-dot ${i === 0 ? 'active' : ''}" data-index="${i}"></div>
                `).join('')}
            </div>
            
            <!-- Quick Actions -->
            <h2 class="section-title">Quick Actions</h2>
            <div class="quick-actions">
                <div class="quick-action-card" onclick="navigate('/tests')">
                    <div class="quick-action-icon">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div class="quick-action-label">Browse Tests</div>
                </div>
                <div class="quick-action-card" onclick="handleCreateClick()">
                    <div class="quick-action-icon">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                    </div>
                    <div class="quick-action-label">Create Test</div>
                </div>
                <div class="quick-action-card" onclick="navigate('/results')">
                    <div class="quick-action-icon">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/>
                        </svg>
                    </div>
                    <div class="quick-action-label">Leaderboard</div>
                </div>
            </div>
            
            <!-- Featured Tests -->
            <h2 class="section-title">Featured Tests</h2>
            <div id="featuredTests"></div>
        </div>
    `;
}

// Tests Component
async function Tests(params) {
    return `
        <div class="p-4">
            <!-- Search -->
            <div class="search-wrapper mb-4">
                <svg class="search-icon w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                </svg>
                <input type="text" class="search-input" placeholder="Search tests by name or subject" id="testSearch">
            </div>
            
            <!-- Filters -->
            <div class="filter-chips">
                <div class="filter-chip active" data-filter="all">All</div>
                <div class="filter-chip" data-filter="public">Public</div>
                <div class="filter-chip" data-filter="locked">Locked</div>
                <div class="filter-chip" data-filter="users">Only Users</div>
            </div>
            
            <!-- Test List -->
            <div id="testList"></div>
        </div>
    `;
}

// Test Detail Component
async function TestDetail(params) {
    const test = await API.getTestDetails(params.id);

    if (!test) {
        return NotFoundComponent();
    }

    return `
        <div class="p-6">
            <div class="mb-6">
                <div class="w-20 h-20 rounded-2xl mx-auto mb-4" style="background: ${test.color}; display: flex; align-items: center; justify-content: center;">
                    <span class="text-white text-3xl font-bold">${getInitials(test.subject)}</span>
                </div>
                <h3 class="text-2xl font-bold text-center mb-2">${test.title}</h3>
                <p class="text-center text-gray-500">${test.subject}</p>
            </div>
            
            <div class="bg-gray-50 rounded-2xl p-4 mb-6">
                <div class="grid grid-cols-2 gap-4">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-primary">${test.questionCount}</div>
                        <div class="text-sm text-gray-500">Questions</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-primary">${test.duration}</div>
                        <div class="text-sm text-gray-500">Minutes</div>
                    </div>
                    <div class="text-center">
                        <div class="text-2xl font-bold text-primary">${test.maxMarks}</div>
                        <div class="text-sm text-gray-500">Max Marks</div>
                    </div>
                    <div class="text-center">
                        <div class="test-card-chip chip-${test.visibility}">${test.visibility === 'users' ? 'Only Users' : test.visibility}</div>
                        <div class="text-sm text-gray-500 mt-1">Visibility</div>
                    </div>
                </div>
            </div>
            
            <div class="space-y-3">
                ${test.isLocked ? `
                    <button class="btn-secondary w-full" disabled>
                        <svg class="w-5 h-5 inline mr-2" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zM9 7c0-1.654 1.346-3 3-3s3 1.346 3 3v3H9V7z"/>
                        </svg>
                        Locked Test
                    </button>
                ` : `
                    <button class="btn-primary w-full" onclick="handleStartTest('${test.id}')">
                        Start Test
                    </button>
                `}
                <button class="btn-secondary w-full" onclick="navigate('/tests')">Back to Tests</button>
            </div>
            
            <div class="mt-6 pt-6 border-t border-gray-200">
                <h4 class="font-semibold mb-3">Test Instructions</h4>
                <ul class="text-sm text-gray-600 space-y-2">
                    <li>• Read each question carefully before answering</li>
                    <li>• You can navigate between questions freely</li>
                    <li>• Your progress is automatically saved</li>
                    <li>• Submit before time runs out to record your score</li>
                </ul>
            </div>
        </div>
    `;
}

// Results Component
async function Results(params) {
    const attempts = await API.getAttempts(APP_STATE.currentUser.id);

    return `
        <div class="p-4">
            <h2 class="section-title">Your Results</h2>
            <div id="resultsList">
                ${attempts.length === 0 ? `
                    <div class="empty-state">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                        <h3>No Results Yet</h3>
                        <p>Take your first test to see results here</p>
                    </div>
                ` : attempts.map(attempt => {
        const test = MOCK_DB.tests.find(t => t.id === attempt.testId);
        return `
                        <div class="result-card">
                            <div class="result-header">
                                <div>
                                    <div class="result-title">${test.title}</div>
                                    <div class="result-date">${formatDate(attempt.date)}</div>
                                </div>
                                <div class="result-score">${attempt.score}/${attempt.maxScore}</div>
                            </div>
                            <div class="result-meta">
                                <span>Rank: #${attempt.rank}</span>
                                ${attempt.canReattempt ? '<span class="badge badge-info">Can Reattempt</span>' : ''}
                            </div>
                            <div class="result-actions">
                                <button class="btn-secondary text-sm" onclick="navigate('/results/${attempt.id}')">View Details</button>
                                ${attempt.canReattempt ? `<button class="btn-primary text-sm" onclick="handleReattempt('${test.id}')">Reattempt</button>` : ''}
                            </div>
                        </div>
                    `;
    }).join('')}
            </div>
        </div>
    `;
}

// Result Detail Component
async function ResultDetail(params) {
    const attempt = MOCK_DB.attempts.find(a => a.id === params.id);

    if (!attempt) {
        return NotFoundComponent();
    }

    const test = MOCK_DB.tests.find(t => t.id === attempt.testId);

    return `
        <div class="p-6">
            <div class="text-center mb-6">
                <div class="text-6xl font-bold text-primary mb-2">${attempt.score}</div>
                <div class="text-gray-500">out of ${attempt.maxScore}</div>
                <div class="mt-4 inline-block px-4 py-2 bg-gray-100 rounded-lg">
                    Rank: <span class="font-bold">#${attempt.rank}</span>
                </div>
            </div>
            
            <div class="bg-gray-50 rounded-2xl p-4 mb-6">
                <h4 class="font-semibold mb-2">${test.title}</h4>
                <div class="text-sm text-gray-500">
                    Attempted on ${formatDate(attempt.date)}
                </div>
            </div>
            
            <div class="space-y-3">
                <div class="flex justify-between items-center p-3 bg-white rounded-lg">
                    <span class="text-gray-600">Percentage</span>
                    <span class="font-semibold">${Math.round((attempt.score / attempt.maxScore) * 100)}%</span>
                </div>
                <div class="flex justify-between items-center p-3 bg-white rounded-lg">
                    <span class="text-gray-600">Questions</span>
                    <span class="font-semibold">${test.questionCount}</span>
                </div>
                <div class="flex justify-between items-center p-3 bg-white rounded-lg">
                    <span class="text-gray-600">Duration</span>
                    <span class="font-semibold">${test.duration} min</span>
                </div>
            </div>
            
            <button class="btn-primary w-full mt-6" onclick="navigate('/results')">Back to Results</button>
        </div>
    `;
}

// Create Component
async function Create(params) {
    const userTests = MOCK_DB.tests.filter(t => t.createdBy === APP_STATE.currentUser.id);

    return `
        <div class="p-4">
            <h2 class="section-title">Your Tests</h2>
            <div id="createdTestsList">
                ${userTests.length === 0 ? `
                    <div class="empty-state">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                        <h3>No Tests Created</h3>
                        <p>Create your first test using the + button</p>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}


// Edit Test Component
async function EditTest(params) {
    const test = MOCK_DB.tests.find(t => t.id === params.id);

    if (!test) {
        return NotFoundComponent();
    }

    return `
        <div class="p-6">
            <h2 class="text-2xl font-bold mb-6">Edit Test</h2>
            <form class="space-y-4" onsubmit="handleEditTestSubmit(event, '${test.id}')">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Test Title</label>
                    <input type="text" value="${test.title}" class="w-full px-4 py-3 border border-gray-300 rounded-xl outline-none focus:border-primary" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                    <input type="text" value="${test.subject}" class="w-full px-4 py-3 border border-gray-300 rounded-xl outline-none focus:border-primary" required>
                </div>
                <div class="space-y-2">
                    <button type="submit" class="btn-primary w-full">Save Changes</button>
                    <button type="button" class="btn-secondary w-full" onclick="navigate('/create')">Cancel</button>
                </div>
            </form>
        </div>
    `;
}

// Profile Component
async function Profile(params) {
    const user = APP_STATE.currentUser;

    return `
        <div class="p-6">
            <!-- Profile Picture -->
            <div class="text-center mb-8">
                <div class="relative inline-block">
                    <div class="w-32 h-32 rounded-full bg-primary text-white flex items-center justify-center text-4xl font-bold mx-auto">
                        ${getInitials(user.name)}
                    </div>
                    <button class="absolute bottom-0 right-0 w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center border-2 border-gray-100" onclick="editProfilePicture()">
                        <svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <!-- Personal Info Card -->
            <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-6">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-bold text-gray-900">Personal info</h3>
                    <button class="text-primary font-semibold" onclick="navigate('/profile/edit')">Edit</button>
                </div>
                
                <!-- Name -->
                <div class="flex items-start mb-6 pb-6 border-b border-gray-100">
                    <div class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <svg class="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <div class="text-sm text-gray-500 mb-1">Full Name</div>
                        <div class="font-semibold text-gray-900">${user.name}</div>
                    </div>
                </div>
                
                <!-- Email -->
                <div class="flex items-start mb-6 pb-6 border-b border-gray-100">
                    <div class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <svg class="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <div class="text-sm text-gray-500 mb-1">E-mail</div>
                        <div class="font-semibold text-gray-900">${user.email}</div>
                    </div>
                </div>
                
                <!-- Phone -->
                <div class="flex items-start">
                    <div class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <svg class="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
                        </svg>
                    </div>
                    <div class="flex-1">
                        <div class="text-sm text-gray-500 mb-1">Phone number</div>
                        <div class="font-semibold text-gray-900">${user.phone || '+1 201 555-0123'}</div>
                    </div>
                </div>
            </div>
            
            <!-- Logout Button -->
            <button class="btn-secondary w-full text-red-600 border-red-600" onclick="navigate('/logout')">
                Logout
            </button>
        </div>
    `;
}

// Settings Component
async function Settings(params) {
    return `
        <div class="p-4">
            <h2 class="section-title">Settings</h2>
            <div class="space-y-2">
                <div class="bg-white rounded-xl p-4 shadow-sm">
                    <h3 class="font-semibold mb-2">Account</h3>
                    <a href="/profile" class="flex items-center justify-between py-2">
                        <span>Profile</span>
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                        </svg>
                    </a>
                </div>
                
                <div class="bg-white rounded-xl p-4 shadow-sm">
                    <h3 class="font-semibold mb-2">Preferences</h3>
                    <div class="flex items-center justify-between py-2">
                        <span>Notifications</span>
                        <label class="relative inline-block w-12 h-6">
                            <input type="checkbox" class="opacity-0 w-0 h-0" checked>
                            <span class="absolute cursor-pointer inset-0 bg-primary rounded-full transition"></span>
                        </label>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-4 shadow-sm">
                    <h3 class="font-semibold mb-2">About</h3>
                    <div class="py-2">
                        <p class="text-sm text-gray-500">Version 1.0.0</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Login Component
async function Login(params) {
    return `
        <div class="flex  justify-center h-full">
            <div class="login-modal-content">
                <h2>Welcome Back</h2>
                <p>Login to access all features</p>
                
                <form onsubmit="handleLoginSubmit(event)">
                    <input type="email" placeholder="Email" required id="loginEmail">
                    <input type="password" placeholder="Password" required id="loginPassword">
                    <button type="submit" class="btn-primary w-full">Login</button>
                </form>
                
                <p class="text-center text-sm text-gray-500 mt-4">
                    Don't have an account? <a href="/" class="text-primary font-semibold">Sign up</a>
                </p>
            </div>
        </div>
    `;
}

// Logout Component
async function Logout(params) {
    logout();
    return ''
}

// 404 Not Found Component
function NotFoundComponent() {
    return `
        <div class="empty-state">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
            </svg>
            <h3>404 - Page Not Found</h3>
            <p>The page you are looking for does not exist</p>
            <button class="btn-primary mt-4" onclick="navigate('/')">Go Home</button>
        </div>
    `;
}

const MOCK_DB = {
    user: {
        id: 'user_1',
        name: 'Alex Johnson',
        email: 'alex@example.com',
        phone: '+1 201 555-0123',
        avatar: null
    },

    tests: [
        {
            id: 'test_1',
            title: 'Introduction to JavaScript',
            subject: 'Programming',
            visibility: 'public',
            questionCount: 25,
            duration: 30,
            maxMarks: 100,
            isLocked: false,
            color: '#3b82f6',
            createdBy: 'user_2'
        },
        {
            id: 'test_2',
            title: 'Advanced React Patterns',
            subject: 'Web Dev',
            visibility: 'locked',
            questionCount: 18,
            duration: 45,
            maxMarks: 75,
            isLocked: true,
            color: '#8b5cf6',
            createdBy: 'user_3'
        },
        {
            id: 'test_3',
            title: 'Mathematics - Calculus I',
            subject: 'Mathematics',
            visibility: 'users',
            questionCount: 30,
            duration: 60,
            maxMarks: 150,
            isLocked: false,
            color: '#10b981',
            createdBy: 'user_1'
        },
        {
            id: 'test_4',
            title: 'Physics: Mechanics',
            subject: 'Physics',
            visibility: 'public',
            questionCount: 20,
            duration: 40,
            maxMarks: 100,
            isLocked: false,
            color: '#f59e0b',
            createdBy: 'user_4'
        },
        {
            id: 'test_5',
            title: 'English Grammar Basics',
            subject: 'English',
            visibility: 'public',
            questionCount: 15,
            duration: 20,
            maxMarks: 50,
            isLocked: false,
            color: '#ec4899',
            createdBy: 'user_2'
        },
        {
            id: 'test_6',
            title: 'Data Structures & Algorithms',
            subject: 'Computer Science',
            visibility: 'locked',
            questionCount: 35,
            duration: 90,
            maxMarks: 200,
            isLocked: true,
            color: '#06b6d4',
            createdBy: 'user_5'
        },
        {
            id: 'test_7',
            title: 'World History: Ancient Civilizations',
            subject: 'History',
            visibility: 'users',
            questionCount: 22,
            duration: 35,
            maxMarks: 80,
            isLocked: false,
            color: '#ef4444',
            createdBy: 'user_1'
        },
        {
            id: 'test_8',
            title: 'Chemistry: Organic Compounds',
            subject: 'Chemistry',
            visibility: 'public',
            questionCount: 28,
            duration: 50,
            maxMarks: 120,
            isLocked: false,
            color: '#14b8a6',
            createdBy: 'user_6'
        }
    ],

    attempts: [
        {
            id: 'attempt_1',
            testId: 'test_1',
            userId: 'user_1',
            score: 85,
            maxScore: 100,
            date: '2024-10-28',
            rank: 12,
            canReattempt: true
        },
        {
            id: 'attempt_2',
            testId: 'test_3',
            userId: 'user_1',
            score: 142,
            maxScore: 150,
            date: '2024-10-25',
            rank: 5,
            canReattempt: false
        },
        {
            id: 'attempt_3',
            testId: 'test_4',
            userId: 'user_1',
            score: 78,
            maxScore: 100,
            date: '2024-10-20',
            rank: 28,
            canReattempt: true
        }
    ],

    carouselSlides: [
        {
            title: 'Master Your Skills',
            description: 'Access thousands of practice tests',
            cta: 'Explore Tests'
        },
        {
            title: 'Track Your Progress',
            description: 'Detailed analytics and insights',
            cta: 'View Results'
        },
        {
            title: 'Create & Share',
            description: 'Build custom tests for your students',
            cta: 'Create Now'
        },
           {
            title: 'Master Your Skills',
            description: 'Access thousands of practice tests',
            cta: 'Explore Tests'
        },
        {
            title: 'Track Your Progress',
            description: 'Detailed analytics and insights',
            cta: 'View Results'
        },
        {
            title: 'Create & Share',
            description: 'Build custom tests for your students',
            cta: 'Create Now'
        }
    ]
};

// ============================================
// MOCK API FUNCTIONS
// ============================================

const API = {
    async login(email, password) {
        await delay(800);
        return { success: true, user: MOCK_DB.user };
    },

    async getTests(filter = 'all') {
        await delay(300);
        if (filter === 'all') return MOCK_DB.tests;
        return MOCK_DB.tests.filter(t => t.visibility === filter);
    },

    async searchTests(query) {
        await delay(200);
        return MOCK_DB.tests.filter(t =>
            t.title.toLowerCase().includes(query.toLowerCase()) ||
            t.subject.toLowerCase().includes(query.toLowerCase())
        );
    },

    async getAttempts(userId) {
        await delay(300);
        return MOCK_DB.attempts.filter(a => a.userId === userId);
    },

    async startAttempt(testId) {
        await delay(500);
        return { attemptId: `attempt_${Date.now()}`, started: true };
    },

    async getTestDetails(testId) {
        await delay(200);
        return MOCK_DB.tests.find(t => t.id === testId);
    }
};

// ============================================
// UTILITY FUNCTIONS
// ============================================

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function formatDate(dateStr) {
    const date = new Date(dateStr);
    const now = new Date();
    const diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function getInitials(name) {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
}

function saveToCache(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
        console.error('Cache save failed:', e);
    }
}

function loadFromCache(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (e) {
        console.error('Cache load failed:', e);
        return null;
    }
}

// ============================================
// TOAST NOTIFICATIONS
// ============================================

function toast(message, type = 'normal', duration = 2500) {
    const container = document.getElementById('toastContainer');
    const toastEl = document.createElement('div');
    toastEl.className = `toast ${type}`;

    const icon = type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ';
    toastEl.innerHTML = `<span style="font-size: 18px;">${icon}</span><span>${message}</span>`;

    container.appendChild(toastEl);

    setTimeout(() => {
        toastEl.style.opacity = '0';
        toastEl.style.transform = 'translateY(-20px)';
        setTimeout(() => toastEl.remove(), 300);
    }, duration);
}

// ============================================
// MODAL MANAGEMENT
// ============================================

function openModal(title, content) {
    const modal = document.getElementById('fullModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalContent = document.getElementById('modalContent');

    modalTitle.textContent = title;
    modalContent.innerHTML = content;
    modal.classList.remove('hidden');
    APP_STATE.modalOpen = true;

    // Focus trap
    const firstFocusable = modalContent.querySelector('button, input, a');
    if (firstFocusable) firstFocusable.focus();
}

function closeModal() {
    const modal = document.getElementById('fullModal');
    modal.classList.add('hidden');
    APP_STATE.modalOpen = false;
}

// ============================================
// DRAWER MANAGEMENT
// ============================================

let drawerStartY = 0;
let drawerCurrentY = 0;
let isDragging = false;

function openDrawer(content, height = '50vh') {
    const drawer = document.getElementById('bottomDrawer');
    const overlay = document.getElementById('drawerOverlay');
    const drawerContent = document.getElementById('drawerContent');

    drawerContent.innerHTML = content;
    drawerContent.style.maxHeight = height;

    overlay.classList.remove('hidden');
    drawer.classList.remove('translate-y-full');
    APP_STATE.drawerOpen = true;
}

function closeDrawer() {
    const drawer = document.getElementById('bottomDrawer');
    const overlay = document.getElementById('drawerOverlay');

    drawer.classList.add('translate-y-full');
    overlay.classList.add('hidden');
    APP_STATE.drawerOpen = false;
}

function initDrawerDrag() {
    const handle = document.getElementById('drawerHandle');
    const drawer = document.getElementById('bottomDrawer');

    handle.addEventListener('touchstart', (e) => {
        isDragging = true;
        drawerStartY = e.touches[0].clientY;
        drawer.style.transition = 'none';
    });

    handle.addEventListener('touchmove', (e) => {
        if (!isDragging) return;
        drawerCurrentY = e.touches[0].clientY - drawerStartY;
        if (drawerCurrentY > 0) {
            drawer.style.transform = `translateY(${drawerCurrentY}px)`;
        }
    });

    handle.addEventListener('touchend', () => {
        if (!isDragging) return;
        isDragging = false;
        drawer.style.transition = 'transform 0.3s';

        if (drawerCurrentY > 100) {
            closeDrawer();
        } else {
            drawer.style.transform = 'translateY(0)';
        }
        drawerCurrentY = 0;
    });
}

// ============================================
// SIDE MENU
// ============================================

function openSideMenu() {
    const menu = document.getElementById('sideMenu');
    const overlay = document.getElementById('sideMenuOverlay');

    overlay.classList.remove('hidden');
    menu.style.transform = 'translateX(0)';
}

function closeSideMenu() {
    const menu = document.getElementById('sideMenu');
    const overlay = document.getElementById('sideMenuOverlay');

    menu.style.transform = 'translateX(-100%)';
    overlay.classList.add('hidden');
}

function updateSideMenuUser() {
    const nameEl = document.getElementById('menuUserName');
    const avatarEl = document.getElementById('menuUserAvatar');

    if (APP_STATE.isLoggedIn && APP_STATE.currentUser) {
        nameEl.textContent = APP_STATE.currentUser.name;
        avatarEl.innerHTML = `<span class="text-white font-semibold text-lg">${getInitials(APP_STATE.currentUser.name)}</span>`;
        avatarEl.className = 'w-12 h-12 rounded-full bg-primary flex items-center justify-center cursor-pointer';
    } else {
        nameEl.textContent = 'Guest';
        avatarEl.innerHTML = `
            <svg class="w-6 h-6 text-gray-500" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
            </svg>
        `;
        avatarEl.className = 'w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center cursor-pointer';
    }
}

// ============================================
// TAB NAVIGATION
// ============================================


function renderTestList(container, tests, showActions = false) {
    if (tests.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                        </path>
                    </svg>
                <h3>No Tests Found</h3>
                <p>Try adjusting your search or filters</p>
            </div>
        `;
        return;
    }

    container.innerHTML = tests.map(test => `
        <div class="test-card" onclick="navigate('/tests/${test.id}')">
            ${test.isLocked ? '<div class="test-card-lock">' + document.getElementById('lockIcon').innerHTML + '</div>' : ''}
            <div class="test-card-avatar" style="background: ${test.color}">
                ${getInitials(test.subject)}
            </div>
            <div class="test-card-content">
                <div class="test-card-title">${test.title}</div>
                <div class="test-card-meta">
                    <span class="test-card-chip chip-${test.visibility}">${test.visibility === 'users' ? 'Only Users' : test.visibility}</span>
                    <span>${test.questionCount} Q</span>
                    <span>${test.maxMarks} marks</span>
                    <span>${test.duration} min</span>
                </div>
            </div>
            <div class="test-card-action">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                </svg>
            </div>
        </div>
    `).join('');
}

// ============================================
// POST-RENDER HOOKS
// ============================================

// Called after Home component renders
async function initHomePage() {
    initCarousel();
    const featuredTests = MOCK_DB.tests.slice(0, 4);
    renderTestList(document.getElementById('featuredTests'), featuredTests);
}

// Called after Tests component renders  
async function initTestsPage() {
    const searchInput = document.getElementById('testSearch');
    const filterChips = document.querySelectorAll('.filter-chip');
    const testList = document.getElementById('testList');

    // Initial render
    loadTests();

    // Search handler
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            APP_STATE.searchQuery = e.target.value;
            loadTests();
        }, 300);
    });

    // Filter handlers
    filterChips.forEach(chip => {
        chip.addEventListener('click', () => {
            filterChips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            APP_STATE.currentFilter = chip.dataset.filter;
            loadTests();
        });
    });

    async function loadTests() {
        testList.innerHTML = '<div class="skeleton h-20 mb-3"></div>'.repeat(3);

        let tests;
        if (APP_STATE.searchQuery) {
            tests = await API.searchTests(APP_STATE.searchQuery);
        } else if (APP_STATE.currentFilter === 'all') {
            tests = await API.getTests();
        } else {
            tests = await API.getTests(APP_STATE.currentFilter);
        }

        renderTestList(testList, tests);
    }
}

// Called after Create component renders
async function initCreatePage() {
    const userTests = MOCK_DB.tests.filter(t => t.createdBy === APP_STATE.currentUser.id);
    const createdTestsList = document.getElementById('createdTestsList');

    if (userTests.length > 0) {
        renderTestList(createdTestsList, userTests, true);
    }
}

// ============================================
// ACTION HANDLERS
// ============================================

function handleCreateClick() {
    if (!APP_STATE.isLoggedIn) {
        navigate('/login');
    } else {
        navigate('/create');
    }
}

async function handleStartTest(testId) {
    if (!APP_STATE.isLoggedIn) {
        navigate('/login');
        return;
    }

    toast('Starting test...', 'normal');

    try {
        const result = await API.startAttempt(testId);
        toast('Test started successfully!', 'success');

        // Here you would navigate to the test player
        // For demo, just show a message
        setTimeout(() => {
            toast('Test player would load here', 'normal');
        }, 1000);
    } catch (e) {
        toast('Failed to start test', 'error');
    }
}

function handleReattempt(testId) {
    openDrawer(`
        <div class="text-center">
            <h3 class="text-xl font-semibold mb-3">Reattempt Test?</h3>
            <p class="text-gray-600 mb-6">Your previous score will be replaced with the new attempt.</p>
            <div class="space-y-2">
                <button class="btn-primary w-full" onclick="confirmReattempt('${testId}')">Yes, Reattempt</button>
                <button class="btn-secondary w-full" onclick="closeDrawer()">Cancel</button>
            </div>
        </div>
    `, '40vh');
}

function confirmReattempt(testId) {
    closeDrawer();
    handleStartTest(testId);
}

async function handleLoginSubmit(event) {
    event.preventDefault();

    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    toast('Logging in...', 'normal');

    try {
        const result = await API.login(email, password);

        if (result.success) {
            APP_STATE.isLoggedIn = true;
            APP_STATE.currentUser = result.user;

            // Update UI
            updateUserSection();
            updateSideMenuUser();

            // Save to cache
            saveToCache('user', result.user);
            saveToCache('isLoggedIn', true);

            toast('Login successful!', 'success');
            navigate('/');
        }
    } catch (e) {
        toast('Login failed. Please try again.', 'error');
    }
}

function handleEditTestSubmit(event, testId) {
    event.preventDefault();
    toast('Test updated successfully!', 'success');
    navigate('/create');
}

function initCarousel() {
    let currentIndex = 0;
    const slides = document.querySelectorAll('.carousel-slide');
    const dots = document.querySelectorAll('.carousel-dot');

    function showSlide(index) {
        slides.forEach(s => s.classList.remove('active'));
        dots.forEach(d => d.classList.remove('active'));

        slides[index].classList.add('active');
        dots[index].classList.add('active');
        currentIndex = index;
    }

    // Auto-advance
    setInterval(() => {
        currentIndex = (currentIndex + 1) % slides.length;
        showSlide(currentIndex);
    }, 4000);

    // Dot click handlers
    dots.forEach((dot, i) => {
        dot.addEventListener('click', () => showSlide(i));
    });
}

// ============================================
// TEST DETAILS MODAL
// ============================================

async function showTestDetails(testId) {
    const test = await API.getTestDetails(testId);

    const content = `
        <div class="p-6">
            <div class="mb-6">
                <div class="w-20 h-20 rounded-2xl mx-auto mb-4" style="background: ${test.color}; display: flex; align-items: center; justify-content: center;">
                    <span class="text-white text-3xl font-bold">${getInitials(test.subject)}</span>
                </div>
                <h3 class="text-2xl font-bold text-center mb-2">${test.title}</h3>
                <p class="text-center text-gray-500">${test.subject}</p>
            </div>
            
            <div class="bg-gray-50 rounded-2xl p-4 mb-6">
                <div class="grid grid-cols-2 gap-4">
                    <div class="text-center">
                        <div class="text-2xl font-bold text-primary">${test.maxMarks}</div>
                        <div class="text-sm text-gray-500">Max Marks</div>
                    </div>
                    <div class="text-center">
                        <div class="test-card-chip chip-${test.visibility}">${test.visibility === 'users' ? 'Only Users' : test.visibility}</div>
                        <div class="text-sm text-gray-500 mt-1">Visibility</div>
                    </div>
                </div>
            </div>
            
            <div class="space-y-3">
                ${test.isLocked ? `
                    <button class="btn-secondary w-full" disabled>
                        <svg class="w-5 h-5 inline mr-2" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zM9 7c0-1.654 1.346-3 3-3s3 1.346 3 3v3H9V7z"/>
                        </svg>
                        Locked Test
                    </button>
                ` : `
                    <button class="btn-primary w-full" onclick="startTest('${test.id}')">
                        Start Test
                    </button>
                `}
                <button class="btn-secondary w-full" onclick="closeModal()">Cancel</button>
            </div>
            
            <div class="mt-6 pt-6 border-t border-gray-200">
                <h4 class="font-semibold mb-3">Test Instructions</h4>
                <ul class="text-sm text-gray-600 space-y-2">
                    <li>• Read each question carefully before answering</li>
                    <li>• You can navigate between questions freely</li>
                    <li>• Your progress is automatically saved</li>
                    <li>• Submit before time runs out to record your score</li>
                </ul>
            </div>
        </div>
    `;

    openModal(test.title, content);
}

async function startTest(testId) {
    if (!APP_STATE.isLoggedIn) {
        closeModal();
        showLoginModal();
        return;
    }

    toast('Starting test...', 'normal');

    try {
        const result = await API.startAttempt(testId);
        toast('Test started successfully!', 'success');
        closeModal();

        // Here you would navigate to the test player
        // For demo, just show a message
        setTimeout(() => {
            toast('Test player would load here', 'normal');
        }, 1000);
    } catch (e) {
        toast('Failed to start test', 'error');
    }
}

// ============================================
// LOGIN MODAL
// ============================================

function showLoginModal() {
    navigate('/login')
}

async function handleLogin(event) {
    event.preventDefault();

    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    toast('Logging in...', 'normal');

    try {
        const result = await API.login(email, password);

        if (result.success) {
            APP_STATE.isLoggedIn = true;
            APP_STATE.currentUser = result.user;

            // Update UI
            updateUserSection();
            updateSideMenuUser();

            // Save to cache
            saveToCache('user', result.user);
            saveToCache('isLoggedIn', true);

            toast('Login successful!', 'success');
            closeModal();
            // Refresh current view
            renderTabContent(APP_STATE.currentTab);
            // 548
        }
    } catch (e) {
        toast('Login failed. Please try again.', 'error');
    }
}

function logout() {
    APP_STATE.isLoggedIn = false;
    APP_STATE.currentUser = null;

    // Clear cache
    localStorage.removeItem('user');
    localStorage.removeItem('isLoggedIn');

    // Update UI
    updateUserSection();
    updateSideMenuUser();
    closeSideMenu();

    toast('Logged out successfully', 'normal');

    // Navigate to home
    navigate('/')
}

function updateUserSection() {
    const userSection = document.getElementById('userSection');

    if (APP_STATE.isLoggedIn && APP_STATE.currentUser) {
        userSection.innerHTML = `
            <div class="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-sm font-semibold cursor-pointer" onclick="openSideMenu()">
                ${getInitials(APP_STATE.currentUser.name)}
            </div>
        `;
    } else {
        userSection.innerHTML = `
            <button id="loginBtn" class="px-4 py-1.5 bg-primary text-white rounded-lg text-sm font-medium">Login</button>
        `;

        document.getElementById('loginBtn').addEventListener('click', showLoginModal);
    }
}

// ============================================
// RESULT ACTIONS (Removed - Now uses SPA routing)
// ============================================

// viewResult and reattemptTest now use navigation

function editProfilePicture() {
    toast('Profile picture upload coming soon!', 'normal');
}

// ============================================
// PROFILE MODAL (Removed - Now uses SPA routing)
// ============================================

// showProfileModal, editProfile, editProfilePicture, saveProfile
// are now replaced by Profile in SPA

// ============================================
// OFFLINE SUPPORT
// ============================================

function checkOnlineStatus() {
    const isOnline = navigator.onLine;
    const banner = document.querySelector('.offline-banner') || createOfflineBanner();

    if (!isOnline && !APP_STATE.isOffline) {
        APP_STATE.isOffline = true;
        banner.classList.add('show');
        toast('You are offline. Using cached data.', 'normal');
    } else if (isOnline && APP_STATE.isOffline) {
        APP_STATE.isOffline = false;
        banner.classList.remove('show');
        toast('Back online!', 'success');
    }
}

function createOfflineBanner() {
    const banner = document.createElement('div');
    banner.className = 'offline-banner';
    banner.textContent = '⚠ Offline Mode - Using cached data';
    document.body.appendChild(banner);
    return banner;
}

// ============================================
// KEYBOARD NAVIGATION
// ============================================

function initKeyboardNav() {
    document.addEventListener('keydown', (e) => {
        // ESC closes modal/drawer
        if (e.key === 'Escape') {
            if (APP_STATE.modalOpen) {
                closeModal();
            } else if (APP_STATE.drawerOpen) {
                closeDrawer();
            }
        }

        // Tab navigation with numbers (1-4)
        if (e.key >= '1' && e.key <= '4' && !APP_STATE.modalOpen) {
            const tabs = ['/', '/tests', '/results', '/create'];
            const index = parseInt(e.key) - 1;
            navigate(tabs[index]);
        }
    });
}

// ============================================
// INITIALIZATION
// ============================================

function init() {
    // Check cached login state
    const cachedUser = loadFromCache('user');
    const cachedLoginState = loadFromCache('isLoggedIn');

    if (cachedLoginState && cachedUser) {
        APP_STATE.isLoggedIn = true;
        APP_STATE.currentUser = cachedUser;
    }
    updateUserSection();
    updateSideMenuUser();

    // Initialize drawer drag
    initDrawerDrag();

    // Initialize keyboard navigation
    initKeyboardNav();

    // Menu button
    document.getElementById('menuBtn').addEventListener('click', openSideMenu);

    // Side menu overlay
    document.getElementById('sideMenuOverlay').addEventListener('click', closeSideMenu);

    // Profile click in side menu
    const menuProfile = document.getElementById('menuProfile');
    menuProfile.addEventListener('click', () => {
        if (APP_STATE.isLoggedIn) {
            closeSideMenu();
            navigate('/profile');
        } else {
            closeSideMenu();
            navigate('/login');
        }
    });

    // Modal back button
    document.getElementById('modalBack').addEventListener('click', () => {
        closeModal()
        history.back()
    });

    // Drawer overlay
    document.getElementById('drawerOverlay').addEventListener('click', closeDrawer);

    // FAB button
    document.getElementById('fabBtn').addEventListener('click', () => {
        openDrawer(`
            <div class="text-center">
                <h3 class="text-xl font-semibold mb-3">Create New Test</h3>
                <p class="text-gray-600 mb-6">Build a custom test for your students or practice.</p>
                <button class="btn-primary w-full" onclick="closeDrawer(); location.hash ='/create/test_1/edit'">
                    Start Creating
                </button>
            </div>
        `, '40vh');
    });

    // Online/offline detection
    // window.addEventListener('online', checkOnlineStatus);
    // window.addEventListener('offline', checkOnlineStatus);
    // checkOnlineStatus();

    // Initialize SPA Router
    window.addEventListener('popstate', handleRouteChange);
    document.body.addEventListener('click', (e) => {
        const link = e.target.closest('a[href]')
        if (link && link.origin == location.origin) {
            e.preventDefault()
            navigate(link.getAttribute('href'))
        }
    })
    handleRouteChange();
}

// Route change handler with post-render hooks
async function handleRouteChange() {
    await router();
    // Call appropriate init function based on current route
    const path = window.location.pathname || "/"
    if (path === '/') {
        setTimeout(initHomePage, 0);
    } else if (path === '/tests') {
        setTimeout(initTestsPage, 0);
    } else if (path === '/create') {
        setTimeout(initCreatePage, 0);
    }
}

// Make functions globally accessible
window.navigate = navigate;
window.handleLoginSubmit = handleLoginSubmit;
window.handleStartTest = handleStartTest;
window.handleReattempt = handleReattempt;
window.confirmReattempt = confirmReattempt;
window.handleEditTestSubmit = handleEditTestSubmit;
window.handleCreateClick = handleCreateClick;
window.openSideMenu = openSideMenu;
window.closeSideMenu = closeSideMenu;
window.closeModal = closeModal;
window.closeDrawer = closeDrawer;
window.editProfilePicture = editProfilePicture;

// Start the app
document.addEventListener('DOMContentLoaded', init);
function h(){
    console.log('854');
}
window.h = h
async function check() {
    const module = await import('/script/config.js')
    // module.init(params)
    module['sum']()
}
check()