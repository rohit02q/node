export async function PublicProfile(params) {
    return `
  <div id="profile_content" class="w-full min-h-full">
  <div class="flex items-center justify-center h-full mt-48">
            <div class="text-center">
                <div class="inline-block animate-spin rounded-full h-12 w-12 loader"></div>
            </div>
        </div>
   </div>
  `
}
export function init(params, box) {
    const user = APP_STATE.user
    const getEle = (id) => document.getElementById(id)
    getEle('modalTopBar').classList.add('hidden')
    getEle('profile_content').innerHTML = `
      <div class="min-h-fit overflow-y-auto pb-4 bg-white">
      <!-- Nav -->
      <div class="flex items-center gap-2 fixed inset-0 h-fit z-[2] bg-white py-4 px-3  border-b">
        <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="history.back()">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
      </button>
      <div class="flex-1 font-bold text-secondary text-xl flex items-center gap-1.5">
        ${user.username}
        ${user.verified
                    ? '<svg stroke="currentColor" id="verifyIcon" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="mt-1 text-blue-500 w-4 h-4"xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0z"></path><path d="M23 12l-2.44-2.79.34-3.69-3.61-.82-1.89-3.2L12 2.96 8.6 1.5 6.71 4.69 3.1 5.5l.34 3.7L1 12l2.44 2.79-.34 3.7 3.61.82L8.6 22.5l3.4-1.47 3.4 1.46 1.89-3.19 3.61-.82-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81 1.48-1.48 2.32 2.33 5.85-5.87 1.48 1.48-7.33 7.35z"></path></svg>'
                    : ''
        }
         </div>
       </div>
      <!-- Main Content -->
       <div class="pt-16 space-y-4 w-full h-full">


          <div class="px-4 pt-2 pb-4 space-y-3 border-b">
          <div class="flex items-center w-full h-fit gap-4">

            <div class="flex items-center justify-center">
              <div class="w-20 h-20 p-1 border-2 overflow-hidden border-primary rounded-full">
                <img src="${user.profile}" class="w-full object-cover h-full rounded-full" 
                alt="${user.username}-pic">
              </div> 
            </div> 
            <div class="space-y-2 flex-1">
              <div class="text-lg font-semibold text-secondary">
               ${user.fullname}
               </div> 
               <div class="flex items-center gap-10">
                 <div class="flex flex-col justify-between items-center">
                 <div class="font-semibold text-xl">${user.totalTests}</div>
                 <div class="font-medium">Tests</div>
                 </div> 
                 <div class="flex flex-col justify-between items-center">
                 <div class="font-semibold text-xl">${user.xp}</div>
                 <div class="font-medium">Total XP</div>
                 </div>
              </div>
          </div> 
       </div>

       <div class="pl-2">
       7teen
      \nStorytelling & Video Editing
      \nLife Mistakes
      </div>

       </div> 






   </div>
  `
}