import jwt from "jsonwebtoken"
import { JWT_MASTER_KEY } from "../config/constant.js"
let payload = {
    uid: "USERrEOTQEmYVBMRumtC",
    type: "reset-password",
}
const options = {
    expiresIn: 10,
}
// let token = jwt.sign(payload, JWT_MASTER_KEY, options)
let token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiJVU0VSckVPVFFFbVlWQk1SdW10QyIsInR5cGUiOiJyZXNldC1wYXNzd29yZCIsImlhdCI6MTc2MzAyMTA5MSwiZXhwIjoxNzYzMDIxMTAxfQ.uS5Yg-zwtZPq7l1DLLGiZspwRPROI8WjZmfJmsLMZ8E"
let decoded;
try {
    decoded = jwt.verify(token, JWT_MASTER_KEY)
} catch (error) {
    decoded = error.message
}

console.log(token);
console.log(decoded);