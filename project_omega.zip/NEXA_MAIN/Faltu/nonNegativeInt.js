function nonNegativeInt(value) {
    const num = Number(value)
    if (!Number.isFinite(num)) return 0
    return Math.trunc(Math.abs(num))
}