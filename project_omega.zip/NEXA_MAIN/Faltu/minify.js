import fs from "fs"
import path from "path"
const cssPath = path.join(import.meta.dirname, 'frontend/styles/index.css')
const css = fs.readFileSync(cssPath, "utf-8")
const result = css.replace(/[\n\s]/g, "")
fs.writeFileSync("mymify.css",result);