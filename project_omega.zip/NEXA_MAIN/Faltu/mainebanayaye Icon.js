function icon() {
    const x1 = 0
    const y1 = 0
    const x2 = 24
    const y2 = 24
    const w = 16
    const h = 16
    const r1 = [x1 - (w / 2), y1 - (h / 2)]
    const r2 = [x1 - (w / 2), y2 - (h / 2)]
    const r3 = [x2 - (w / 2), y1 - (h / 2)]
    const r4 = [x2 - (w / 2), y2 - (h / 2)]
    return `
       <svg fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"
       viewBox="${x1} ${y1} ${x2} ${y2}" class="inline w-6 h-6">
       <rect x="${r1[0]}" y="${r1[1]}" width="${w}" height="${h}"></rect>
       <rect x="${r2[0]}" y="${r2[1]}" width="${w}" height="${h}"></rect>
       <rect x="${r3[0]}" y="${r3[1]}" width="${w}" height="${h}"></rect>
       <rect x="${r4[0]}" y="${r4[1]}" width="${w}" height="${h}"></rect>
       </svg>
    `
}