function toggleBtn(id,checked = false) {
  return `<div class="relative inline-flex items-center">
    <input type="checkbox" class="sr-only peer" id="${id}" ${checked ? 'checked' : ''}>
      <label for="${id}" class="cursor-pointer w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary">
      </label>
  </div>`
}
export async function EditTest(params) {
  const id = params.testId
  return `
    <div class="p-4 min-h-[100vh] overflow-y-auto pb-28 bg-white">
      <div class="flex items-center gap-3  fixed inset-0 h-fit bg-white px-4 py-3 border-b">
        <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="history.back()">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
      </button>
        <div class="flex-1">
          <div class="font-semibold text-secondary">Edit Test</div>
          <div class="text-sm text-gray-500">${id}</div>
        </div>
        <button id="save_top_btn" class="btn-primary py-2 px-3">Save</button>
      </div>
      <div class="mt-4 space-y-4">
        <!-- META -->
        <div class="bg-white p-3 rounded-lg border">
          <label class="text-sm font-medium">Test Title</label>
          <input id="meta_title" class="w-full p-3 rounded-lg border mt-2" placeholder="Enter test title" />
          <div class="grid grid-cols-2 gap-2 mt-3">
            <input id="meta_duration" type="number" class="p-3 rounded-lg border" placeholder="Duration (mins)"/>
            <select id="meta_visibility" class="p-3 rounded-lg border">
              <option value="PUBLIC">Public</option>
              <option value="PRIVATE">Private</option>
            </select>
          </div>
          <div class="grid grid-cols-2 gap-2 mt-3">
            <select id="meta_entryType" class="p-3 rounded-lg border">
              <option value="OPEN">Open</option>
              <option value="LOCKED">Locked</option>
            </select>
            <input id="meta_entryCode" class="p-3 rounded-lg border" placeholder="Entry code (if locked)"/>
          </div>
        </div>

        <!-- SETTINGS -->
        <div class="bg-white p-3 rounded-lg border">
          <div class="flex items-center justify-between">
            <div>
              <div class="font-medium">Settings</div>
              <div class="text-sm text-gray-500">Control result & attempt behavior</div>
            </div>
          </div>
          <div class="mt-3 space-y-2">
            <label class="flex items-center justify-between">
              <span class="text-sm">Allow Reattempt</span>
              ${toggleBtn('s_reattempt')}
            </label>
            <label class="flex items-center justify-between">
              <span class="text-sm">Make solutions hidden</span>
               ${toggleBtn('s_solutions')}
              </label>
            <label class="flex items-center justify-between">
              <span class="text-sm">Hide result</span>
                ${toggleBtn('s_resultHidden')}
            </label>
            <label class="flex items-center justify-between">
              <span class="text-sm">Shuffle questions</span>
               ${toggleBtn('s_shuffle')}
            </label>
          </div>
        </div>
        <!-- ADVANCED -->
        <div class="bg-white p-3 rounded-lg border">
          <div class="font-medium">Advanced</div>
          <div class="text-sm text-gray-500 mt-1">Focus guard & blocked users</div>
          <div class="mt-3">
            <label class="flex items-center justify-between">
              <span class="text-sm">Enable focus guard</span>
              ${toggleBtn('fg_enabled')}
            </label>
            <div id="fg_controls" class="mt-2 hidden">
              <input id="fg_maxAway" type="number" class="w-full p-3 border rounded-lg my-2" placeholder="Max away (ms)"/>
              <input id="fg_maxTabs" type="number" class="w-full p-3 border rounded-lg my-2" placeholder="Max tab switches"/>
            </div>
            <label class="text-sm mt-2">Blocked users (comma separated ids)</label>
            <input id="blocked_users" class="w-full p-3 border rounded-lg mt-2" placeholder="uid1,uid2"/>
          </div>
        </div>
        <!-- QUESTIONS summary + list -->
        <div class="bg-white p-3 rounded-lg border">
          <div class="flex items-center justify-between">
            <div>
              <div class="font-medium">Questions</div>
              <div class="text-sm text-gray-500" id="questions_count">0 questions</div>
            </div>
            <div class="flex gap-2">
              <button id="add_question_btn" class="px-3 py-2 rounded-lg bg-primary text-white">+ Add</button>
              <button id="import_btn" class="px-3 py-2 rounded-lg border">Import</button>
            </div>
          </div>

          <div id="questions_list" class="mt-3 space-y-2">
            <!-- list items -->
          </div>
        </div>

        <!-- question editor area -->
        <div id="question_editor" class="bg-white p-3 rounded-lg border hidden">
          <div class="flex items-center justify-between mb-2">
            <div class="font-medium" id="qe_index">Question</div>
            <div class="text-sm text-gray-500" id="qe_type_label">MCQ</div>
          </div>

          <textarea id="qe_text" class="w-full p-3 border rounded-lg" rows="3" placeholder="Type question text"></textarea>

          <div class="mt-3">
            <label class="text-sm">Type</label>
            <select id="qe_type" class="w-full p-3 border rounded-lg mt-1">
              <option value="mcq">MCQ</option>
              <option value="numeric">Numeric</option>
            </select>
          </div>

          <div id="qe_options_wrap" class="mt-3">
            <div class="text-sm">Options</div>
            <div id="qe_options" class="mt-2 space-y-2">
              <!-- option rows -->
            </div>
            <div class="flex gap-2 mt-2">
              <button id="qe_add_opt" class="flex-1 py-2 rounded-lg border">Add option</button>
              <button id="qe_remove_opt" class="flex-1 py-2 rounded-lg border">Remove</button>
            </div>
          </div>

          <div class="mt-3">
            <label class="text-sm">Correct answer (index)</label>
            <input id="qe_answer" class="w-full p-3 border rounded-lg mt-1" placeholder="e.g. 0 for first option or exact number"/>
          </div>

          <div class="grid grid-cols-2 gap-2 mt-3">
            <input id="qe_marks_pos" type="number" class="p-3 border rounded-lg" placeholder="+ marks"/>
            <input id="qe_marks_neg" type="number" class="p-3 border rounded-lg" placeholder="- marks"/>
          </div>

          <div class="mt-3 flex gap-2">
            <button id="qe_save" class="flex-1 py-3 rounded-lg bg-primary text-white">Save question</button>
            <button id="qe_cancel" class="flex-1 py-3 rounded-lg border">Cancel</button>
          </div>
        </div>

        <div class="h-24"></div>
      </div>
    </ >

    <!--bottom fixed actions -->
    <div style="position:fixed;left:0;right:0;bottom:0;padding:12px;background:linear-gradient(0deg,#fff, rgba(255,255,255,0.9));border-top:1px solid #eee;display:flex;gap:6px">
      <button id="delete_btn" class="flex-1 py-3 rounded-lg border text-red-600">Delete</button>
      <button id="publish_btn" class="flex-1 py-3 rounded-lg bg-primary text-white">Publish</button>
    </div>
  `
}

function localStoreKey() { return 'nexa_tests_local_v1' }
function loadLocalAll() { return JSON.parse(localStorage.getItem(localStoreKey()) || '{}') }
function saveLocalAll(obj) { localStorage.setItem(localStoreKey(), JSON.stringify(obj)) }

export function init(params) {
  const testId = params?.testId || location.pathname.split('/').at(-1)
  let test = null
  let autosaveInterval = null
  let currentEditingQid = null

  // load test (backend try then local)
  async function loadTest() {
    // try backend
    try {
      if (fetchData) {
        const resp = await fetchData(`/ tests / ${ testId } `)
        if (resp && resp.success) { test = resp.data; return renderAll() }
      }
    } catch (e) { /* ignore */ }

    // local fallback
    const store = loadLocalAll()
    test = store[testId] || {
      _id: testId,
      title: '',
      duration: 45,
      visibility: 'PUBLIC',
      entryType: 'OPEN',
      entryCode: '',
      blockedUsers: [],
      focusGuard: { enabled:false, maxAwayTime:120000, maxTabSwitch:5 },
      isReattemptAllowed: true,
      isSolutionsPublic: true,
      isResultHidden: false,
      shuffle: false,
      questions: {},
      draft: true,
      published: false,
      createdAt: Date.now(),
      updatedAt: Date.now()
    }
    renderAll()
  }

  function renderAll() {
    document.getElementById('meta_title').value = test.title || ''
    document.getElementById('meta_duration').value = test.duration || 45
    document.getElementById('meta_visibility').value = test.visibility || 'PUBLIC'
    document.getElementById('meta_entryType').value = test.entryType || 'OPEN'
    document.getElementById('meta_entryCode').value = test.entryCode || ''
    document.getElementById('s_reattempt').checked = !!test.isReattemptAllowed
    document.getElementById('s_solutions').checked = !!test.isSolutionsPublic
    document.getElementById('s_resultHidden').checked = !!test.isResultHidden
    document.getElementById('s_shuffle').checked = !!test.shuffle
    document.getElementById('fg_enabled').checked = !!test.focusGuard?.enabled
    document.getElementById('fg_maxAway').value = test.focusGuard?.maxAwayTime || 120000
    document.getElementById('fg_maxTabs').value = test.focusGuard?.maxTabSwitch || 5
    document.getElementById('blocked_users').value = (test.blockedUsers||[]).join(',')
    // questions list
    renderQuestionsList()
    updateQuestionsCount()
  }

  function updateQuestionsCount() {
    const qs = Object.keys(test.questions || {}).length
    document.getElementById('questions_count').innerText = `${ qs } question${ qs !== 1 ? 's' : '' } `
  }

  function renderQuestionsList() {
    const wrap = document.getElementById('questions_list')
    const keys = Object.keys(test.questions || {})
    if (!keys.length) {
      wrap.innerHTML = `<div class="text-sm text-gray-500"> No questions yet.Tap + Add to create one.</div> `
      return
    }
    wrap.innerHTML = keys.map((qid, i) => {
      const q = test.questions[qid]
      return `
    < div class="p-2 border rounded-lg flex items-center justify-between" data - qid="${qid}" >
          <div>
            <div class="font-medium">Q${i+1}. ${ (q.text||'Untitled').slice(0,60) }</div>
            <div class="text-xs text-gray-500">${q.type.toUpperCase()} • +${q.marks?.correct || 0} / ${q.marks?.wrong || 0}</div>
          </div>
          <div class="flex gap-2">
            <button class="btn-edit small" data-action="edit" data-qid="${qid}">Edit</button>
            <button class="btn-del small" data-action="del" data-qid="${qid}">Delete</button>
          </div>
        </ >
    `
    }).join('')
  }

  // question editor helpers
  function openQuestionEditor(qid) {
    currentEditingQid = qid
    const q = test.questions[qid] || { type:'mcq', text:'', options:[], marks:{correct:4, wrong: -1}, answer:0 }
    document.getElementById('qe_index').innerText = `Question`
    document.getElementById('qe_type').value = q.type
    document.getElementById('qe_type_label').innerText = q.type.toUpperCase()
    document.getElementById('qe_text').value = q.text || ''
    document.getElementById('qe_answer').value = q.answer ?? ''
    document.getElementById('qe_marks_pos').value = q.marks?.correct ?? 4
    document.getElementById('qe_marks_neg').value = q.marks?.wrong ?? -1
    renderOptions(q.options || [], q.type)
    document.getElementById('question_editor').classList.remove('hidden')
  }

  function renderOptions(options, type='mcq') {
    const wrap = document.getElementById('qe_options')
    if (type === 'numeric') {
      wrap.innerHTML = `< div class="text-sm text-gray-500" > Numeric answer — use the answer input for the exact number</ > `
      return
    }
    wrap.innerHTML = (options.length ? options : ['','','','']).map((opt, idx) => `
    < div class="flex gap-2" >
      <input data-opt-index="${idx}" class="flex-1 p-3 border rounded-lg" value="${opt ?? ''}" placeholder="Option ${idx+1}" />
      </ >
    `).join('')
  }

  // add new question
  document.getElementById('add_question_btn').addEventListener('click', ()=> {
    const qid = (Date.now().toString(36)+Math.random().toString(36).slice(2,8))
    test.questions[qid] = { type:'mcq', text:'', options:['','','',''], marks:{correct:4, wrong:-1}, answer:0 }
    renderQuestionsList(); updateQuestionsCount(); openQuestionEditor(qid)
  })

  // question list click (edit/delete)
  document.getElementById('questions_list').addEventListener('click', (e)=> {
    const el = e.target.closest('button')
    if (!el) return
    const action = el.dataset.action
    const qid = el.dataset.qid
    if (action === 'edit') openQuestionEditor(qid)
    if (action === 'del') {
      delete test.questions[qid]
      renderQuestionsList(); updateQuestionsCount()
      toast('Question removed','success')
    }
  })

  // editor buttons
  document.getElementById('qe_cancel').addEventListener('click', ()=> {
    document.getElementById('question_editor').classList.add('hidden')
    currentEditingQid = null
  })

  document.getElementById('qe_add_opt').addEventListener('click', ()=> {
    const type = document.getElementById('qe_type').value
    if (type === 'numeric') return toast('Numeric type has no options','info')
    // append empty option
    const els = document.querySelectorAll('#qe_options input')
    const vals = Array.from(els).map(i=>i.value)
    vals.push(''); renderOptions(vals, 'mcq')
  })

  document.getElementById('qe_remove_opt').addEventListener('click', ()=> {
    const els = document.querySelectorAll('#qe_options input')
    if (els.length <= 1) return toast('Need at least one option','info')
    const vals = Array.from(els).map(i=>i.value)
    vals.pop(); renderOptions(vals, 'mcq')
  })

  document.getElementById('qe_save').addEventListener('click', ()=> {
    const qid = currentEditingQid
    if (!qid) return
    const type = document.getElementById('qe_type').value
    const text = document.getElementById('qe_text').value.trim()
    const answerRaw = document.getElementById('qe_answer').value.trim()
    const pos = Number(document.getElementById('qe_marks_pos').value)||0
    const neg = Number(document.getElementById('qe_marks_neg').value)||0
    let options = []
    if (type === 'mcq') {
      const els = document.querySelectorAll('#qe_options input')
      options = Array.from(els).map(i=>i.value)
    }
    const ans = type === 'numeric' ? Number(answerRaw || 0) : Number(answerRaw || 0)
    test.questions[qid] = { type, text, options, answer: ans, marks:{correct:pos, wrong:neg} }
    // update view
    renderQuestionsList(); updateQuestionsCount()
    document.getElementById('question_editor').classList.add('hidden')
    currentEditingQid = null
    toast('Question saved','success')
  })

  // fg toggle show/hide
  document.getElementById('fg_enabled').addEventListener('change', (e) => {
    const show = e.target.checked
    document.getElementById('fg_controls').classList.toggle('hidden', !show)
  })

  // top save button
  document.getElementById('save_top_btn').addEventListener('click', saveTest)

  // publish / delete
  document.getElementById('publish_btn').addEventListener('click', async ()=> {
    await saveTest()
    // set published flag
    test.published = true; test.draft = false; test.updatedAt = Date.now()
    // try backend
    try {
      if (fetchData) {
        await fetchData(`/ tests / save`, { method:'POST', body: JSON.stringify(test) })
        toast('Published (backend)','success')
      } else {
        const store = loadLocalAll(); store[test._id] = test; saveLocalAll(store); toast('Published (local)','success')
      }
    } catch(e) {
      const store = loadLocalAll(); store[test._id] = test; saveLocalAll(store); toast('Published (local)','success')
    }
  })

  document.getElementById('delete_btn').addEventListener('click', ()=> {
    const store = loadLocalAll(); delete store[test._id]; saveLocalAll(store)
    toast('Test deleted','success'); navigate('/create')
  })

  // autosave every 60s
  function startAutosave() {
    if (autosaveInterval) clearInterval(autosaveInterval)
    autosaveInterval = setInterval(()=> {
      saveTest(true)
    }, 60 * 1000)
  }

  async function saveTest(isAuto=false) {
    try {
      // read meta & settings from form
      test.title = document.getElementById('meta_title').value.trim()
      test.duration = Number(document.getElementById('meta_duration').value) || 45
      test.visibility = document.getElementById('meta_visibility').value
      test.entryType = document.getElementById('meta_entryType').value
      test.entryCode = document.getElementById('meta_entryCode').value
      test.isReattemptAllowed = document.getElementById('s_reattempt').checked
      test.isSolutionsPublic = document.getElementById('s_solutions').checked
      test.isResultHidden = document.getElementById('s_resultHidden').checked
      test.shuffle = document.getElementById('s_shuffle').checked
      test.focusGuard = {
        enabled: document.getElementById('fg_enabled').checked,
        maxAwayTime: Number(document.getElementById('fg_maxAway').value) || 120000,
        maxTabSwitch: Number(document.getElementById('fg_maxTabs').value) || 5
      }
      test.blockedUsers = (document.getElementById('blocked_users').value || '').split(',').map(s=>s.trim()).filter(Boolean)
      test.updatedAt = Date.now()

      // try backend save
      if (!isAuto && fetchData) {
        const resp = await fetchData(`/ tests / save`, { method:'POST', body: JSON.stringify(test) })
        if (resp && resp.success) toast('Saved','success')
        else {
          // fallback local
          const store = loadLocalAll(); store[test._id] = test; saveLocalAll(store)
          if (!isAuto) toast('Saved locally','success')
        }
      } else {
        const store = loadLocalAll(); store[test._id] = test; saveLocalAll(store)
        if (!isAuto) toast('Saved locally','success')
      }
    } catch (e) {
      console.error(e)
      if (!isAuto) toast('Save failed','error')
    }
  }

  // initial load
  loadTest().then(()=> {
    startAutosave()
    // ensure save before leaving
    window.addEventListener('beforeunload', saveTest)
  })
}
