import Storage from "../controller/storage.js"
export async function addXp(uid, n) {
    let user = await Storage.get(`users/${uid}`)
    if (!user) return
    user.xp += n
    await Storage.set(`users/${uid}`, user)
}