export function formatTimeString(time){
    let date = new Date(time)
    let timeString = date.toLocaleTimeString("en-us",{
        hour:"numeric",
        minute:"numeric",
        hour12:true
    })
    return timeString
}