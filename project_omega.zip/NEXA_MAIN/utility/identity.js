import crypto from "crypto"
export const getToken = (length = 32) => { return crypto.randomBytes(length).toString('hex') }
export const getId = (length = 16) => {
    let chars = "67890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz12345"
    let tsb36 = (Date.now() + Math.floor(Math.random() * 10**10)).toString(36)
    if(tsb36.length >= length){
       tsb36 = ""
    }
    length = length - tsb36.length
    let randomBytes = crypto.randomBytes(length);
    let id = ""
    for (let i = 0; i < length; i++) { id += chars[randomBytes[i] % chars.length] }
    return id + tsb36;
}