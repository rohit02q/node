import jwt from "jsonwebtoken"
import { JWT_ACCESS_KEY, JWT_REFRESH_KEY, ACCESS_TOKEN_EXP_TIME, REFRESH_TOKEN_EXP_TIME } from "../config/constant.js"
export const generateAccessToken = (uid, user) => {
    let payload = {
        uid,
        username: user.username || "",
        fullname: user.fullname || "",
        email: user.email || "",
        role: user.role.toUpperCase(),
        type: "access-token",
        sessionId: user.sessionId,
        app: {
            name: "Next Exam - Nexa",
            devloper: {
                name: "Rohit kumar thakur",
                country: "INDIA",
                state: "BIHAR",
            },
            year: 2025
        }
    }
    const options = {
        expiresIn: ACCESS_TOKEN_EXP_TIME,
    }
    let token = jwt.sign(payload, JWT_ACCESS_KEY, options)
    return token
}

export const generateRefreshToken = (uid, user) => {
    let payload = {
        uid,
        username: user.username || "",
        fullname: user.fullname || "",
        email: user.email || "",
        role: user.role.toUpperCase(),
        type: "refresh-token",
        sessionId: user.sessionId,
        app: {
            name: "Next Exam - Nexa",
            devloper: {
                name: "Rohit kumar thakur",
                country: "INDIA",
                state: "BIHAR",
            },
            year: 2025
        }
    }
    const options = {
        expiresIn: REFRESH_TOKEN_EXP_TIME,
    }
    let token = jwt.sign(payload, JWT_REFRESH_KEY, options)
    return token
}
