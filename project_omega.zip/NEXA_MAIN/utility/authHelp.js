import bcrypt from "bcrypt"
import Storage from "../controller/storage.js"
export const hashPassword = async (pass, salt = 10) => { return await bcrypt.hash(pass, salt) }
export const comparePassword = async (pass, hash) => { return await bcrypt.compare(pass, hash) }
export const checkExists = async (type, data) => {
    if (type == 'email') {
        if (!data?.email) {
            return { success: false, exists: true, message: "Need Email" }
        }
        const users = await Storage.get('users') || {}
        const user = Object.values(users)
        for (let u of user) {
            if (u.phone == data.phone || u.email == data.email) { return { exists: true, succes: true } }
        }
    }
    else if (type == 'username') {
        if (!data?.username) {
            return { success: false, exists: true, message: "Need username" }
        }
        const users = await Storage.get('users') || {}
        const user = Object.values(users)
        for (let u of user) {
            if (u.username == data.username) { return { exists: true, success: true } }
        }
    }
    else {
        const users = await Storage.get('users') || {}
        const user = Object.values(users)
        for (let u of user) {
            if (u.username == data.username || u.email == data.email || u.phone == data.u) { return { exists: true, success: true } }
        }
    }
    return { success: true, exists: false }
}