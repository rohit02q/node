import jwt from "jsonwebtoken"
import { JWT_ACCESS_KEY } from "../config/constant.js"
import Storage from "../controller/storage.js"
export const verify = async (req, res, next) => {
    const authHeader = req.headers["Authorization"] || req.headers["authorization"]
    const token = authHeader && authHeader.split(' ')[1]
    if (!token) {
        return res.status(401).json({ success: false, message: "#Unauthorized Access#", statusCode: 401,type:"TokenError" })
    }
    try {
        let decoded = jwt.verify(token, JWT_ACCESS_KEY)
        let user = await Storage.get(`users/${decoded.uid}`)
        if (user.sessionId == decoded.sessionId) {
            req.user = { ...user, uid: decoded.uid }
            return next()
        }
        return res.status(401).json({ success: false, error, message: "Other login detected,Session expire", statusCode: 401,type:"TokenError" })
    } catch (error) {
        return res.status(401).json({ success: false, error, message: "Invalid or Expire token", statusCode:401, type:"TokenError"})
    }
}