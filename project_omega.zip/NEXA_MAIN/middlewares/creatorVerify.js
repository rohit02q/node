import Storage from "../controller/storage.js"
export const creatorVerify = async (req, res, next) => {
    try {
        const test = await Storage.get(`tests/${req.params.testId}`)
        if (!test) return res.status(404).json({ success: false, message: "Test not found" })
        if (test.creator !== req.user.uid) return res.status(403).json({ success: false, message: "#Not Allowed#", error: { "message": "#Not Allowed#", "status": 403 } })
        req.test = test
        next()
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Internal Server Error" })
    }
}