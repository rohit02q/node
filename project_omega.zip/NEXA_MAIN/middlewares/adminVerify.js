import jwt from "jsonwebtoken"
import { JWT_ACCESS_KEY } from "../config/constant.js"
import Storage from "../controller/storage.js"
export const adminVerify = (req, res, next) => {
    const authHeader = req.headers["Authorization"] || req.headers["authorization"]
    const token = authHeader && authHeader.split(' ')[1]
    if (!token) {
        return res.status(403).json({success: false,message: "#Request Blocked#",error: {"message": "#Request Blocked#","status": 403}})
    }
    try {
        let decoded = jwt.verify(token, JWT_ACCESS_KEY)
        let user = Storage.get(`users/${decoded.uid}`)
        if (user.sessionId == decoded.sessionId) {
            if(user.role.toLowerCase() !=== "admin"){
           return res.status(403).json({success: false,message: "#Request Blocked#",error: {"message": "#Request Blocked#","status": 403}})
      }
            req.user = { ...user, uid: decoded.uid }
            return next()
        }
        return res.status(401).json({ success: false, error, message: "Session expire", statusCode: 401 })
    } catch (error) {
      return res.status(403).json({success: false,message: "#Request Blocked#",error: {"message": "#Request Blocked#","status": 403}})
    }
}