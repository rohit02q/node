import express from "express"
import appRoute from "./appRoutes/appRoutes.js"
import attemptRoute from "./testRoutes/attempt.js"
import authRoute from "./auth/authRoute.js"
import myTests from "./myTests/myTests.js"
import support from "./support/support.js"
import testRoute from "./testRoutes/testRoute.js"
import userRoute from "./userRoutes/userRoute.js"
import {verify} from "../middlewares/verify.js"
const router = express.Router()
router.use('/app',appRoute)
router.use('/attempts',verify,attemptRoute)
router.use('/auth', authRoute)
router.use('/my-tests',verify,myTests)
router.use('/support',support)
router.use('/tests', testRoute)
router.use('/users', verify,userRoute)
router.use((_, res) => res.status(404).json({ success: false, error: { message: 'API not found!' }, data: {}, message: "Not found", statusCode: 404 }))
export default router