import express from "express"
import path from "path"
const router = express.Router()
const HTML = path.resolve(import.meta.dirname, '../frontend')
router.use(express.static(HTML))
function htmlFile(fileName) {return path.join(HTML, fileName)}
router.get('/auth', (_, res) => {res.sendFile(htmlFile('auth.html'))})
// router.get('/tests/:testId/attempt-test', (_, res) => {res.sendFile(htmlFile('test.html'))})
router.get('*', (_, res) => {res.sendFile(htmlFile('index.html'))})
export default router