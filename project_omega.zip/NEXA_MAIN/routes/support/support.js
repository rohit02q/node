import express from "express"
import {db} from "../../controller/storage.js"
import Storage from "../../controller/storage.js"
import { verify } from "../../middlewares/verify.js"
import { getId } from "../../utility/identity.js"
const router = express.Router()
router.get("/chat", verify, async (req, res) => {
  try {
    const uid = req.user.uid
    const snapshot = await db
      .collection("support")
      .doc("chats")
      .collection(uid)
      .orderBy("ts", "asc")
      .get();
    const messages = snapshot.docs.map(doc => ({
      _id: doc.id,
      ...doc.data()
    }));
    return res.json({ success: true, data: messages })
  } catch (e) {
    return res.status(500).json({ success: false, data: [] })
  }
})

router.post("/chat/send", verify, async (req, res) => {
  try {
    const uid = req.user.uid
    const { text } = req.body
    if (!text) {
      return res.json({ success: false, message: "Message required" })
    }
    const messageId = getId(10)
    const message = {
      text,
      from: "user",
      ts: Date.now(),
    }
    await db.collection("support")
      .doc("chats")
      .collection(uid)
      .doc(messageId)
      .set(message);
    return res.json({ success: true,message:"Message sent" })
  } catch (err) {
    return res.status(500).json({ success: false })
  }
})
export default router