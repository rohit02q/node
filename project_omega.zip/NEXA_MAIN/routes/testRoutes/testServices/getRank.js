export function getRank(entiresObject, data) {
    if (!entiresObject) return 1
    const entires = Object.values(entiresObject).map(e => ({
        marks: e.marks,
        timeTaken: e.timeTaken,
        createdAt: e.createdAt
    }))
    entires.push({ ...data, id: "_NEW_" })
    entires.sort((a, b) => {
        if (b.marks !== a.marks) return b.marks - a.marks
        if (a.timeTaken !== b.timeTaken) return a.timeTaken - b.timeTaken
        return a.createdAt - b.createdAt
    })
    return entires.findIndex(e => e.id === "_NEW_") + 1
}

export function getTopperId(entiresObject) {
    const entires = Object.values(entiresObject).map(e => ({
        marks: e.marks,
        timeTaken: e.timeTaken,
        createdAt: e.createdAt,
        attemptId:e.attemptId
    }))
    entires.sort((a, b) => {
        if (b.marks !== a.marks) return b.marks - a.marks
        if (a.timeTaken !== b.timeTaken) return a.timeTaken - b.timeTaken
        return a.createdAt - b.createdAt
    })
    return entires[0].attemptId
}