import Storage from "../../../controller/storage.js"
export async function updateLeaderboard(data) {
    let { testId, uid, ...rest } = data
    let user = await Storage.get(`users/${uid}`)
    await Storage.set(`leaderboard/${testId}/entries/${uid}`,
        { ...rest, fullname: user.fullname, profile: user.profile, createdAt: Date.now() }
    )
}