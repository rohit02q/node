import Storage from "../../../controller/storage.js"
export async function updateTestCounts(testId,newUser = false) {
    let test = await Storage.get(`tests/${testId}`)
if(!test) return
test.totalAttemptsCount += 1
if(newUser){
    test.popularity += 3
    test.totalUsersAttempted +=1
}
else{
    test.popularity += 1
}
await Storage.set(`tests/${testId}`,test)
}