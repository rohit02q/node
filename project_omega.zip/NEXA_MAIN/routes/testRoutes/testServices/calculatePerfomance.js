import Storage from "../../../controller/storage.js"
export const calculatePerfomance = async (testId, userAnswers) => {
    try {
        let test = await Storage.get(`tests/${testId}`)
        if (!test || !userAnswers) return null
        let totalMarks = 0;
        let questionsValue = Object.values(test.questions)
        questionsValue.forEach(q => totalMarks += q.positiveMarks)
        let totalQuestions = questionsValue.length;
        let marksObtained = 0;
        let marksLost = 0;
        let marksSkipped = 0;
        let correctQuestionsCount = 0
        let incorrectQuestionsCount = 0
        let skippedQuestionsCount = 0
        for (let [id, q] of Object.entries(test.questions)) {
            if(!userAnswers[id]) userAnswers[id] = {}
            let userAnswer = userAnswers[id].value
            if (userAnswer == null || userAnswer == undefined) {
                skippedQuestionsCount++
                marksSkipped += q.positiveMarks
                userAnswers[id].status = "skipped"
                userAnswers[id].marks = 0
                userAnswers[id].value = null
            }
            else if (userAnswer === q.answer) {
                correctQuestionsCount++
                marksObtained += q.positiveMarks
                userAnswers[id].status = "correct"
                userAnswers[id].marks = q.positiveMarks
            }
            else {
                incorrectQuestionsCount++
                marksLost += q.negativeMarks
                userAnswers[id].status = 'incorrect'
                userAnswers[id].marks = -q.negativeMarks
            }
        }
        let finalMarks = marksObtained - marksLost
        let accuracy = 0
        if (totalQuestions !== skippedQuestionsCount) {
            accuracy = ((correctQuestionsCount / (totalQuestions - skippedQuestionsCount)) * 100).toFixed(2)
        }
        let completed = (((totalQuestions - skippedQuestionsCount) / totalQuestions) * 100).toFixed(2)
        return {
            userAnswers,
            finalMarks,
            totalMarks,
            totalQuestions,
            correctQuestionsCount,
            incorrectQuestionsCount,
            skippedQuestionsCount,
            marksObtained,
            marksLost,
            marksSkipped,
            accuracy: Number(accuracy),
            completed:Number(completed)
        }
    } catch (e) {
        console.log("Error to calculatePerfomance: ", String(e))
        return null
    }
}