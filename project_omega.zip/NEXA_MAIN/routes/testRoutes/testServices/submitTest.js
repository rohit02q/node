import Storage from "../../../controller/storage.js";
import { calculatePerfomance } from "./calculatePerfomance.js";
import { addXp } from "../../../utility/addXp.js"
import { updateLeaderboard } from "./updateLb.js";
import { getRank } from "./getRank.js";
export const submitTest = async (attemptId, data, uid) => {
    let submitTime = Date.now()
    let userAnswers = data.userAnswers
    let timeSpent = data.timeSpent
    let awayTime = data.awayTime
    let tabSwitchCount = data.tabSwitchCount
    let status = data.status
    let validStatus = ['submitted', 'fired', 'timeout']
    if (!status || !validStatus.includes(status)) {
        return { success: false, message: "Invalid status type", statusCode: 400 }
    }
    if (!data || !userAnswers || !timeSpent || awayTime == null || tabSwitchCount == null) return { success: false, message: "Proper Data not provided", statusCode: 400 }
    let attempt = await Storage.get(`attempts/${attemptId}`)
    if (!attempt || attempt.uid !== uid) { return { success: false, message: "Invalid attempt Id", statusCode: 400 } }
    if (attempt.status !== "ongoing") return { success: false, message: "Attempt already submitted", statusCode: 400 }
    let timeTaken = 0
    if (attempt.endTime > submitTime) {
        timeTaken = submitTime - attempt.startTime
    } else {
        timeTaken = attempt.endTime - attempt.startTime
    }
    attempt.submitTime = submitTime
    attempt.timeTaken = timeTaken
    attempt.userAnswers = userAnswers
    attempt.timeSpent = timeSpent
    attempt.status = status
    if (attempt.tabSwitchCount < tabSwitchCount) { attempt.tabSwitchCount = tabSwitchCount }
    if (attempt.awayTime < awayTime) { attempt.awayTime = awayTime }
    let result = await calculatePerfomance(attempt.testId, userAnswers)
    if (!result) return { success: false, message: "Something went wrong", statusCode: 500 }
    attempt.userAnswers = result.userAnswers // Updated 
    let entiresObject = await Storage.get(`leaderboard/${attempt.testId}/entries`)
    attempt.rankAtSubmission = getRank(entiresObject, { marks: result.finalMarks, timeTaken, createdAt: submitTime })
    if (attempt.attemptNumber > 1) {
        await addXp(uid, Number(result.correctQuestionsCount))
    }
    else {
        await updateLeaderboard(
            {
                testId: attempt.testId,
                uid,
                attemptId,
                marks: result.finalMarks,
                correct: result.correctQuestionsCount,
                timeTaken
            }
        )
        await addXp(uid, Number(result.correctQuestionsCount) * 3)
    }
    await Storage.set(`attempts/${attemptId}`, { ...attempt, ...result })
    return { success: true, message: "Test submitted successfully" }

}
