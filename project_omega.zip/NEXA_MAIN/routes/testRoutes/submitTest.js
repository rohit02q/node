import express from "express"
import { submitTest } from "./testServices/submitTest.js";
import { verify } from "../../middlewares/verify.js";
const router = express.Router()
router.use(express.json())
router.use(express.urlencoded({ extended: true }))
router.post("/:attemptId/submit-test", verify, async (req, res) => {
    try{
    let attemptId = req.params.attemptId
    let data = req.body
    let resp = await submitTest(attemptId, data, req.user.uid)
    return res.status(resp.statusCode || 200).json({ ...resp })
  } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Server Error" })
    }
})

export default router