import express from "express"
import Storage from "../../controller/storage.js";
import { verify } from "../../middlewares/verify.js";
const router = express.Router()
router.get('/:attemptId/solutions', verify, async (req, res) => {
    try {
        let attemptId = req.params.attemptId;
        let attempt = await Storage.get(`attempts/${attemptId}`)
        let viewer = req.query.viewer
        if (!viewer) return res.status(400).json({ success: false, message: "Viewer query not given" })
        if (viewer.toLowerCase() === 'user') {
            if (!attempt) return res.status(400).json({ success: false, message: "Invalid attempt id" })
            if (attempt.uid !== req.user.uid) return res.status(400).json({ success: false, message: "#You Have Not Permission#" })
            if (attempt.status == "ongoing") return res.status(403).json({ success: false, message: "Kindly submit this attempt to see solutions" })
            let test = await Storage.get(`tests/${attempt.testId}`)
            if (test.isSolutionsHidden) return res.status(403).json({ success: false, message: "Solutions is hidden by test creator" })
            let TOTAL_ALL = Object.keys(test.questions).length;
            let TOTAL_CORRECT = attempt.correctQuestionsCount;
            let TOTAL_INCORRECT = attempt.incorrectQuestionsCount;
            let TOTAL_SKIPPED = attempt.skippedQuestionsCount;
            let userAnswers = attempt.userAnswers;
            let QUESTIONS = attempt.questionIds.map((id, index) => {
                const { answer, text, type, image, options, explanation } = test.questions[id]
                return { id: index + 1, timeSpent: attempt.timeSpent[id] || 0, status: userAnswers[id].status, marks: userAnswers[id].marks, type, text, explanation, correctAnswer: answer, userAnswer: userAnswers[id].value, options, image, _id: id, }
            });
            return res.json({
                success: true, data: {
                    TOTAL_ALL, TOTAL_CORRECT, TOTAL_INCORRECT, TOTAL_SKIPPED, QUESTIONS
                }
            })
        }
        else {
            return res.status(400).json({ success: false, message: "Invalid viewer query" })
        }
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Server Error" })
    }
})
export default router