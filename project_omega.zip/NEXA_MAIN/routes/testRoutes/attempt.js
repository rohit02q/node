import express from "express"
import Storage from "../../controller/storage.js";
import submitRoute from './submitTest.js'
import solutionRoute from "./solutionRoute.js"
const router = express.Router()
router.use(express.json())
router.use(express.urlencoded({ extended: true }))
router.get("/:attmptId/questions/:qId", async (req, res) => {
    try {
        let attemptId = req.params.attmptId
        let qId = req.params.qId
        let attempt = await Storage.get(`attempts/${attemptId}`)
        if (!attempt || attempt.uid !== req.user.uid) {
            return res.status(400).json({ success: false, message: "Invalid attempt Id", statusCode: 400 })
        }
        if (attempt.status !== "ongoing") return res.status(403).json({ success: false, message: "Test is submitted", statusCode: 403 })
        let testId = attempt.testId
        let question = await Storage.get(`tests/${testId}/questions/${qId}`)
        if (!question) {
            return res.status(404).json({ success: false, message: "Question not found", statusCode: 404 })
        }
        const { answer, explanation, ...q } = question
        return res.json({ success: true, data: q })
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Server Error" })
    }
})
router.post("/:attemptId/sync", async (req, res) => {
    try {
        let data = req.body
        let userAnswers = data.userAnswers
        let timeSpent = data.timeSpent
        let awayTime = data.awayTime
        let tabSwitchCount = data.tabSwitchCount
        if (!data || !userAnswers || !timeSpent || awayTime == null || tabSwitchCount == null) return res.status(400).json({ success: false, message: "Proper Data not provided", statusCode: 400 })
        let attemptId = req.params.attemptId
        let attempt = await Storage.get(`attempts/${attemptId}`)
        if (!attempt || attempt.uid !== req.user.uid) {
            return res.status(400).json({ success: false, message: "Invalid attempt Id", statusCode: 400 })
        }
        if (attempt.status != "ongoing") return res.status(400).json({ success: false, message: "Attempt already submited", statusCode: 400 })
        attempt.userAnswers = userAnswers
        attempt.timeSpent = timeSpent
        if (attempt.tabSwitchCount < tabSwitchCount) {
            attempt.tabSwitchCount = tabSwitchCount
        }
        if (attempt.awayTime < awayTime) {
            attempt.awayTime = awayTime
        }
        if (Date.now() < attempt.endTime) {
            attempt.lastSync = new Date().toISOString()
        }
        await Storage.set(`attempts/${attemptId}`, attempt)
        return res.json({ success: true, message: "Attempt Synced successfully" })
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message }, message: "Something went wrong" })
    }
})
router.use(solutionRoute)
router.use(submitRoute)
export default router