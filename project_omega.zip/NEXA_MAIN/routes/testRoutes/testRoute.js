import express from "express"
import leaaderboad from "./leaderboard.js"
import resultRoute from "./resultRoute.js"
import solutionsRoute from "./solutionRoute.js"
import startTest from "./startTest.js"
import summary from "./summary.js"
import testDetails from "./testDetails.js"
import allTestListRoute from './listAll.js'
const router = express.Router()
router.use(allTestListRoute)
router.use(leaaderboad)
router.use(resultRoute)
router.use(solutionsRoute)
router.use(startTest)
router.use(summary)
router.use(testDetails)
export default router