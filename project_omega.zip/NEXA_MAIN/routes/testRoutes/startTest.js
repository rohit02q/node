import express from "express"
import jwt from "jsonwebtoken"
import Storage from "../../controller/storage.js";
import { verify } from "../../middlewares/verify.js";
import { getId } from "../../utility/identity.js"
import { shuffle } from "../../utility/shuffle.js";
import { submitTest } from "./testServices/submitTest.js";
import { formatTimeString } from "../../utility/formatTimeString.js"
import { updateTestCounts } from "./testServices/updateTestCounts.js";
import { JWT_MASTER_KEY, MAX_REATTEMPT_LIMIT } from "../../config/constant.js";
const router = express.Router()
router.post("/:testId/start-test-token", verify, async (req, res) => {
    try {
        const { code } = req.body
        if (!code) return res.status(400).json({ success: false, message: "Code required" })
        const testId = req.params.testId
        const test = await Storage.get(`tests/${testId}`)
        if (!test) return res.status(404).json({ success: false, message: "Test not found" })
        if (test.entryType === "free") return res.json({ success: true, data: { token: "" } })
        if (test.entryCode !== code) return res.status(403).json({ success: false, message: "Invalid Code" })
        const tokenPayload = {
            uid: req.user.uid,
            type: "attempt-token"
        }
        const options = {
            expiresIn: "5m",
        }
        const token = jwt.sign(tokenPayload, JWT_MASTER_KEY, options)
        return res.json({ success: true, data: { token } })
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, error: String(e) }, message: "Internal Server Error" })
    }
})
router.get("/:testId/start-test", verify, async (req, res) => {
    try {
        let testId = req.params.testId;
        let type = req.query.type;
        let validTypes = ["Start", "Resume", "Reattempt"]
        if (!type || !validTypes.includes(type)) return res.status(400).json({ success: false, message: "Type query must be one of these: Start,Resume,Reattempt" })
        let test = await Storage.get(`tests/${testId}`)
        if (!test) return res.status(404).json({ success: false, message: "Test not exists with given id" })
        const attemptSyncInterval = 2 * 60 * 1000
        const attemptsSnap = await Storage.get(`attempts`) || {}
        const previousAttempts = Object.entries(attemptsSnap).map(e => {
            if (e[1].testId == testId && e[1].uid == req.user.uid) {
                return { ...e[1], id: e[0] }
            }
        }
        ).filter(e => e !== undefined)
        if (previousAttempts[0] && previousAttempts.length !== 0) {
            const lastAttempt = previousAttempts.find(a => a.attemptNumber == previousAttempts.length)
            if (lastAttempt.status === "ongoing") {
                if (type !== "Resume") return res.status(400).json({ success: false, message: `Test is not in ${type} state` })
                if (lastAttempt.endTime <= Date.now()) {
                    let submitResp = await submitTest(lastAttempt.id, { ...lastAttempt, status: "timeout" }, req.user.uid)
                    if (submitResp.success) {
                        lastAttempt.status = "timeout"
                        return res.json({
                            success: false, message: `Test auto-submitted at <b> ${formatTimeString(lastAttempt.endTime)} </b> <br>
                            since you <b> left test at ${formatTimeString(lastAttempt.lastSync || lastAttempt.startTime)} </b> and <br> didn't return withwin test duration 
                            ` , type: " ⌛<br> Important", submitted: true
                        })
                    }
                }
                return res.json({
                    success: true, data: {
                        testMeta: {
                            title: test.title,
                            duration: test.duration,
                            startTime: lastAttempt.startTime,
                            endTime: lastAttempt.endTime,
                        },
                        type: "Resume",
                        serverTime: Date.now(),
                        attemptId: lastAttempt.id,
                        focusGuard: test.focusGuard,
                        awayTime: lastAttempt.awayTime,
                        tabSwitchCount: lastAttempt.tabSwitchCount,
                        userAnswers: lastAttempt.userAnswers,
                        timeSpent: lastAttempt.timeSpent,
                        questionIds: lastAttempt.questionIds,
                        attemptSyncInterval
                    }
                })
            }
            if (type !== "Reattempt") return res.status(400).json({ success: false, message: "Test is already submitted", type: " ❗ <br>Important", submitted: true })
            if (!test.isReattemptAllowed) return res.status(403).json({ success: false, message: "Reattempt not allowed by test creator" })
        }
        if (test.visibility == "PRIVATE") return res.status(403).json({ success: false, message: "This test is private", type: "🔒" })
        if (previousAttempts.length + 1 == 1 && type !== "Start") return res.status(400).json({ success: false, message: `Test is not in ${type} state` })
        if (test.entryType === "locked") {
            try {
                const token = req.query.token
                if (!token) return res.status(401).json({ success: false, error, message: "Required token for locked test", statusCode: 401 })
                const decoded = jwt.verify(token, JWT_MASTER_KEY)
                if (decoded.uid !== req.user.uid) {
                    return res.status(403).json({ success: false, error, message: "#Invalid token#", statusCode: 403 })
                }
            } catch (error) {
                return res.status(401).json({ success: false, error, message: "Invalid or Expire token", statusCode: 401 })
            }
        }
        if (test.blockedUsers.includes(req.user.username)) {
            return res.status(403).json({ success: false, message: "Test is private" })
        }
        if (previousAttempts.length >= MAX_REATTEMPT_LIMIT) {
            return res.json({ success: false, message: "Max Reattempt limit exceeds" })
        }
        if (type == "Reattempt") {
            updateTestCounts(testId, false)
        } else {
            updateTestCounts(testId, true)
        }
        const questionIds = Object.keys(test.questions)
        const shuffleQuestionIds = test.shuffle ? shuffle(questionIds) : questionIds
        const attemptNumber = previousAttempts.length + 1
        const attemptId = "A" + getId(16)
        const startTime = Date.now()
        const endTime = startTime + test.duration * 60 * 1000
        const attemptData = {
            testId,
            uid: req.user.uid,
            attemptNumber,
            userAnswers: {},
            timeSpent: {},
            awayTime: 0,
            tabSwitchCount: 0,
            questionIds: shuffleQuestionIds,
            status: "ongoing",
            startTime,
            endTime,
            createdAt: new Date().toISOString()
        }
        let testData = {
            testMeta: {
                title: test.title,
                duration: test.duration,
                startTime,
                endTime,
            },
            type,
            serverTime: Date.now(),
            attemptId,
            focusGuard: test.focusGuard,
            userAnswers: {},
            timeSpent: {},
            awayTime: 0,
            tabSwitchCount: 0,
            questionIds: shuffleQuestionIds,
            attemptSyncInterval,
        }
        await Storage.set(`attempts/${attemptId}`, attemptData)
        return res.status(201).json({ success: true, data: testData })
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: String(e) }, message: "Internal Server Error" })
    }
})
export default router