import express from "express"
import Storage from "../../controller/storage.js";
const router = express.Router()
router.get("/list-all", async (req, res) => {
    try {
        const tests = await Storage.get('tests')
        const result = []
        for (const [id, t] of Object.entries(tests)) {
            if (t.visibility !== "public" || t.isDeleted || t.blockedUsers.includes(req.user?.uid)) { }
            else {
                const testCreator = await Storage.get(`users/${t.creator}`)
                result.push({
                    _id: id,
                    title: t.title,
                    duration: t.duration,
                    totalQuestions: t.totalQuestions,
                    totalMarks: t.totalMarks,
                    entryType: t.entryType,
                    totalAttemptsCount: t.totalAttemptsCount,
                    totalUsersAttempted: t.totalUsersAttempted,
                    publishedAt:t.publishedAt,
                    testCreator: {
                        username: testCreator.username,
                        profile: testCreator.profile,
                        verified: testCreator.verified,
                    },
                })
            }
        }
        result.sort((a, b) => b.publishedAt - a.publishedAt)
        return res.json({ success: true, data: result })
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Internal Server Error" })
    }
})
export default router