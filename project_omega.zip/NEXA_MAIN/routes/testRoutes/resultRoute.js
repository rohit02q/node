import express from "express"
import { getRank, getTopperId } from "./testServices/getRank.js"
import { verify } from "../../middlewares/verify.js"
import Storage from "../../controller/storage.js"
const router = express.Router()
router.get('/:testId/my-result', verify, async (req, res) => {
    try {
    let testId = req.params.testId
    let test = await Storage.get(`tests/${testId}`)
    if (!test) {
        return res.status(404).json({ success: false, message: "Unknwon test id", statusCode: 404 })
    }
    if (test.isResultHidden) {
        return res.status(403).json({ success: false, message: "Creator not allowed to see Result" })
    }
    let totalMarks = 0;
    Object.values(test.questions).forEach(q => totalMarks += q.positiveMarks)
    let testMeta = {
        title: test.title,
        duration: test.duration,
        totalQuestions: Object.keys(test.questions).length,
        totalMarks,
        isSolutionsPublic: test.isSolutionsPublic,
        isReattemptAllowed: test.isReattemptAllowed,
        entryType: test.entryType
    }
    let attemptsSnap = await Storage.get(`attempts`) || {}
    let allResult = {
        totalAttempts: 0
    }
    let entiresObject = await Storage.get(`leaderboard/${testId}/entries`) || {}
    let totalFirstAttempt = 0
    let totalScore = 0
    let totalCorrect = 0
    let totalAccuracy = 0
    let totalIncorrect = 0
    let totalSkipped = 0
    let totalComplete = 0
    let totalTimeTaken = 0
    for (let [id, value] of Object.entries(attemptsSnap)) {
        if (value.testId === testId && value.uid === req.user.uid && value.status !== 'ongoing') {
            let { testId, uid, userAnswers, timeSpent, status, awayTime, tabSwitchCount, lastSync, questionIds, ...thisResult } = value
            let rank = getRank(entiresObject, { marks: value.finalMarks, timeTaken: value.timeTaken, createdAt: Date.now() })
            if (value.attemptNumber === 1) rank -= 1
            allResult[`attempt${value.attemptNumber}`] = { ...thisResult, liveRank: rank, _id: id }
            allResult.totalAttempts += 1
        }
        if (value.testId === testId && value.status !== 'ongoing' && value.attemptNumber == 1) {
            totalFirstAttempt += 1
            totalScore += value.finalMarks
            totalCorrect += value.correctQuestionsCount
            totalIncorrect += value.incorrectQuestionsCount
            totalSkipped += value.skippedQuestionsCount
            totalAccuracy += value.accuracy
            totalComplete += value.completed
            totalTimeTaken += value.timeTaken
        }
    }
    if (allResult.totalAttempts == 0) return res.status(403).json({ success: false, message: "You not attempt this test" })
    let topperResult = attemptsSnap[getTopperId(entiresObject)]
    let performance = {
        Score: {
            topper: topperResult.finalMarks,
            average: Math.round(totalScore / totalFirstAttempt)
        },
        Correct: {
            topper: topperResult.correctQuestionsCount,
            average: Math.round(totalCorrect / totalFirstAttempt)
        },
        Incorrect: {
            topper: topperResult.incorrectQuestionsCount,
            average: Math.round(totalIncorrect / totalFirstAttempt)
        },
        Skipped: {
            topper: topperResult.skippedQuestionsCount,
            average: Math.round(totalSkipped / totalFirstAttempt)
        },
        Accuracy: {
            topper: topperResult.accuracy + "%",
            average: Number((totalAccuracy / totalFirstAttempt).toFixed(2)) + "%"
        },
        Complete: {
            topper: topperResult.completed + "%",
            average: Number((totalComplete / totalFirstAttempt).toFixed(2)) + "%"
        },
        TimeTaken: {
            topper: topperResult.timeTaken,
            average: Math.round(totalTimeTaken / totalFirstAttempt)
        }
    }
    return res.json({ success: true, data: { results: allResult, testMeta, performance, userXP: req.user.xp } })       
     } catch (e) {
        console.log(e)
        return res.status(500).json({ success: false, error: { message: e.message, data: String(e) }, message: "Server Error" })
    }
})
export default router