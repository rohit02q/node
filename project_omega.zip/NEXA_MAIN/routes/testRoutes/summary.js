import express from "express"
import Storage from "../../controller/storage.js";
import { verify } from "../../middlewares/verify.js";
const router = express.Router()
router.get('/summary', verify, async (req, res) => {
    try {
        let attemptsSnap = await Storage.get(`attempts`) || {}
        let attempts = Object.entries(attemptsSnap).map(([id, doc]) => ({ id, ...doc })).filter(a => a.uid === req.user.uid)
        const groups = {}
        for (const a of attempts) {
            if (!groups[a.testId]) { groups[a.testId] = [] }
            groups[a.testId].push(a)
        }
        const results = []
        for (const testId in groups) {
            const arr = groups[testId]
            arr.sort((a, b) => b.startTime - a.startTime)
            let test = await Storage.get(`tests/${testId}`)
            const latest = arr[0]
            let testCreator = await Storage.get(`users/${test.creator}`)
            results.push({
                _id: testId,
                title: test.title,
                duration: test.duration,
                totalQuestions: Object.keys(test.questions).length,
                totalMarks: Object.values(test.questions).reduce((sum, q) => sum + q.positiveMarks, 0),
                attemptCount: arr.length,
                testCreator: {
                    username: testCreator.username,
                    profile: testCreator.profile,
                    verified: testCreator.verified,
                },
                lastAttempt: {
                    status: latest.status === "ongoing" ? "resume" : "completed",
                    createdAt: latest.startTime,
                    _id: latest.id
                }
            })
        }
        results.sort((a, b) => b.lastAttempt.createdAt - a.lastAttempt.createdAt)
        return res.json({ success: true, data: results })
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Server Error" })
    }
})
export default router 