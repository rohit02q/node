import express from "express"
import Storage from "../../controller/storage.js";
import { verify } from "../../middlewares/verify.js";
const router = express.Router()
router.get('/:testId/leaderboard', verify, async (req, res) => {
    try {
        let testId = req.params.testId;
        let uid = req.user.uid;
        let viewer = req.query?.viewer;
        if (viewer === "User") {
            let entiresObject = await Storage.get(`leaderboard/${testId}/entries`)
            if (!entiresObject) return []
            const entires = Object.values(entiresObject).map(e => ({
                marks: e.marks,
                correct: e.correct,
                name: e.fullname,
                profile: e.profile,
                timeTaken: e.timeTaken,
                createdAt: e.createdAt
            }))
            entires.sort((a, b) => {
                if (b.marks !== a.marks) return b.marks - a.marks
                if (a.timeTaken !== b.timeTaken) return a.timeTaken - b.timeTaken
                return a.createdAt - b.createdAt
            })
            let data = entires.map((e, index) => {
                return { rank: index + 1, ...e }
            })
            return res.status(200).json({ success: true, data })
        }
        return res.status(400).json({ success: false, message: "Unknown viewer" })
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Server Error" })
    }
})

export default router