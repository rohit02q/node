import express from "express"
import Storage from "../../controller/storage.js";
const router = express.Router()
router.get('/:testId/details', async (req, res) => {
    let testId = req.params.testId;
    let test = await Storage.get(`tests/${testId}`)
    if (!test) {
        return res.status(404).json({ success: false, message: "Test not exists" })
    }
    if (test.visibility == "PRIVATE") return res.status(403).json({ success: false, message: "This test is private" })
    let testCreator = await Storage.get(`users/${test.creator}`)
    let testData = {
        _id: testId,
        title: test.title,
        duration: test.duration,
        totalQuestions: test.totalQuestions,
        totalMarks: test.totalMarks,
        entryType: test.entryType,
        description: test.description,
        testCreator: {
            username: testCreator.username,
            profile: testCreator.profile,
            verified: testCreator.verified,
        }
    }
    res.json({ success: true, data: testData, statusCode: 200 })
})

export default router