import express from "express"
import Storage from "../../controller/storage.js"
const router = express.Router()
router.get('/banners', async (req, res) => {
const banners = {
  "banner_1": {
    _id: "B01",
    contentType: "html",
    html: `
      <div class="text-center space-y-2">
        <p class='text-2xl font-bold'>Welcome to NEXA 🚀</p>
        <p class="text-sm opacity-80">Start your journey now</p>
      </div>
    `,
    actionUrl: "/home"
  },

  "banner_2": {
    _id: "B02",
    contentType: "image",
    imageUrl: "/assets/img/Q1.jpg",
    actionUrl: "/tests"
  },

  "banner_3": {
    _id: "B03",
    contentType: "html",
    html: `
      <div class="text-center space-y-2">
        <p class='text-xl font-semibold'>Update your profile</p>
        <p class="text-sm opacity-80">Add name & phone number</p>
      </div>
    `,
    actionUrl: "/profile"
  },

  "banner_4": {
    _id: "B04",
    contentType: "image",
    imageUrl: "/assets/img/Q2.jpg",
    actionUrl: "/results"
  },

  "banner_5": {
    _id: "B05",
    contentType: "html",
    html: `
      <div class="text-center space-y-2">
        <p class='text-xl font-semibold'>Check your progress 📊</p>
        <p class="text-sm opacity-80">View results & analytics</p>
      </div>
    `,
    actionUrl: "/results"
  },

  "banner_6": {
    _id: "B06",
    contentType: "image",
    imageUrl: "/assets/img/Q3.jpg",
    actionUrl: "/social-links"
  },

  "banner_7": {
    _id: "B07",
    contentType: "html",
    html: `
      <div class="text-center space-y-2">
        <p class='text-xl font-semibold'>Connect with Developer 🤝</p>
        <p class="text-sm opacity-80">Social & Contact links</p>
      </div>
    `,
    actionUrl: "/social-links"
  },

  "banner_8": {
    _id: "B08",
    contentType: "image",
    imageUrl: "/assets/img/Q4.jpg",
    actionUrl: "/settings"
  }
}

    return res.json(Object.values(banners))
})
router.get('/about', async (req, res) => {
    const aboutApp = `
    <style>
      .fade-in { animation: fadeIn 0.8s ease forwards; opacity: 0; }
      .slide-up { animation: slideUp 0.6s ease forwards; opacity: 0; }
      .delay-1 { animation-delay: .2s }
      .delay-2 { animation-delay: .4s }
      .delay-3 { animation-delay: .6s }
      .delay-4 { animation-delay: .8s }
      .delay-5 { animation-delay: 1s }

      @keyframes fadeIn {
        from { opacity: 0 }
        to { opacity: 1 }
      }
      @keyframes slideUp {
        from { transform: translateY(20px); opacity: 0 }
        to { transform: translateY(0); opacity: 1 }
      }

      .timeline {
        border-left: 3px solid #111;
        padding-left: 15px;
      }
    </style>

    <div class="p-6 overflow-x-hidden min-h-full space-y-10 text-gray-800">

        <div class="fade-in">
            <h3 class="text-2xl font-bold pb-2">What is NEXA?</h3>
            <p>
                <strong>NEXA</strong> is not just a normal test-taking application. It is a vision, a mindset and a
                powerful learning ecosystem created for students who are tired of average and are ready to push
                themselves towards greatness.
            </p>
            <p class="mt-2">
                NEXA is designed to give students one simple thing — <strong>clarity</strong>. Clarity in learning,
                clarity in performance, and clarity in growth. Whether you are preparing for an exam, improving your
                skills, or just challenging yourself, NEXA is built to stand by you at every step.
            </p>
        </div>

        <div class="slide-up delay-1">
            <h3 class="text-xl font-bold pb-2">The Story Behind NEXA</h3>
            <p>
                NEXA was not created in a company office or a big startup environment. It was created in silence,
                dedication, and long isolated hours. It is the result of countless ideas, repeated failures, and
                a strong refusal to give up.
            </p>
            <p class="mt-2">
                It was built slowly, piece by piece, feature by feature, with one mission:
                <strong>to build something meaningful for students.</strong>
                No shortcuts. No copied ideas. Only hard work, learning, and growth.
            </p>
        </div>

        <div class="slide-up delay-2">
            <h3 class="text-xl font-bold pb-2">What you can do on NEXA</h3>
            <ul class="list-disc ml-5 space-y-2">
                <li>Create, attempt, and manage your own tests</li>
                <li>Practice regularly and track your improvement</li>
                <li>Analyze your accuracy, speed, and performance</li>
                <li>Resume tests from where you left off</li>
                <li>See yourself on the Leaderboard</li>
                <li>Build daily consistency and discipline</li>
            </ul>
        </div>

        <div class="slide-up delay-3">
            <h3 class="text-xl font-bold pb-2">Our Mission</h3>
            <p>
                The mission of NEXA is simple but powerful — 
                <strong>to make every student better than they were yesterday.</strong>
            </p>
            <p class="mt-2">
                NEXA does not believe in shortcuts. It believes in consistency, discipline, hard work, and self-respect.
                Every test you take, every mistake you make, and every improvement you see is a step closer to the
                better version of yourself.
            </p>
        </div>

        <div class="slide-up delay-4">
            <h3 class="text-xl font-bold pb-2">Vision & Roadmap</h3>

            <div class="timeline mt-4 space-y-4">
                <div>
                    <strong>Phase 1 – Foundation</strong>
                    <p class="text-sm text-gray-600">Core test system, UI, analysis, authentication</p>
                </div>
                <div>
                    <strong>Phase 2 – Expansion</strong>
                    <p class="text-sm text-gray-600">Advanced statistics, custom test editor, leaderboard</p>
                </div>
                <div>
                    <strong>Phase 3 – Community</strong>
                    <p class="text-sm text-gray-600">Public challenges, user-created content, collaborations</p>
                </div>
                <div>
                    <strong>Phase 4 – Intelligence</strong>
                    <p class="text-sm text-gray-600">AI-based analysis, smart recommendations, study plans</p>
                </div>
            </div>
        </div>

        <div class="slide-up delay-3">
            <h3 class="text-xl font-bold pb-2">Technology & Performance</h3>
            <p>
                NEXA is powered by modern web technologies such as HTML, Tailwind CSS, JavaScript, and a strong
                backend infrastructure. The system is carefully designed to be fast, clean, responsive, and scalable.
            </p>
            <p class="mt-2">
                Even in low network conditions, NEXA aims to provide a smooth and reliable experience. It is optimized
                for both mobile and desktop devices, ensuring accessibility for all students.
            </p>
        </div>

        <div class="slide-up delay-5">
            <h3 class="text-xl font-bold pb-2">Developer Info</h3>
            <p>
                NEXA is developed by <strong>Rohit</strong>, a student, dreamer, and self-taught developer who believes
                that real change comes from discipline, sacrifice, and consistency.
            </p>
            <p class="mt-2">
                This application is the result of <strong>countless sleepless nights</strong>, continuous learning,
                fixing errors at 2 AM, and rewriting the same code over and over again until it was perfect.
                It wasn’t easy. It wasn’t fast. But it was real — and it was worth it.
            </p>
            <p class="mt-2 font-semibold text-gray-700">
                Built with ❤️, dedication, and many sleepless nights.
            </p>
        </div>

        <div class="slide-up delay-5">
            <h3 class="text-xl font-bold pb-2">A Message For You</h3>
            <p>
                If you are reading this, then you are already someone who wants to improve. Remember, success is not
                built in one day. It is built by tiny efforts repeated every single day.
            </p>
            <p class="mt-2">
                Use NEXA not just as an app, but as a habit. A discipline. A daily reminder that your future depends
                on what you do today.
            </p>
            <p class="font-semibold mt-3">
                Keep learning.  
                Keep pushing.  
                Keep growing.
            </p>
            <p class="mt-2 text-sm text-gray-500">
                – Team NEXA
            </p>
        </div>

    </div>
    `
    return res.json({ html: aboutApp })
})

router.get("/faq",(req,res) =>{
      const faq = [
    {
        _id:"faq_01",
        question:"Who made NEXA",
        answer:`<p>
                NEXA is developed by <strong>Rohit</strong>, a student, dreamer, and self-taught developer who believes
                that real change comes from discipline, sacrifice, and consistency.
            </p>
            <p class="mt-2">
                This application is the result of <strong>countless sleepless nights</strong>, continuous learning,
                fixing errors at 2 AM, and rewriting the same code over and over again until it was perfect.
                It wasn’t easy. It wasn’t fast. But it was real — and it was worth it.
            </p>
            <p class="mt-2 font-semibold text-gray-700">
                Built with ❤️, dedication, and many sleepless nights.
            </p>`
    },
    {
        _id:"faq_02",
        question:"What is NEXA?",
        answer:`<p>
                <strong>NEXA</strong> is not just a normal test-taking application. It is a vision, a mindset and a
                powerful learning ecosystem created for students who are tired of average and are ready to push
                themselves towards greatness.
            </p>
            <p class="mt-2">
                NEXA is designed to give students one simple thing — <strong>clarity</strong>. Clarity in learning,
                clarity in performance, and clarity in growth. Whether you are preparing for an exam, improving your
                skills, or just challenging yourself, NEXA is built to stand by you at every step.
            </p>`
    }
]
return res.json({success:true,data:faq})
})

export default router