import express from "express"
const router = express.Router()
router.get('/reset-password', (req, res) => {
    let token = req.query.token
    if(!token) return res.send("<h1>This page not avaliable right now!</h1>")
    try {
        let decoded = jwt.verify(token,JWT_ACCESS_KEY)
        let user = Storage.get(`users/${decoded.uid}`)
        if (user.sessionId == decoded.sessionId) {
            return res.json({ success: true, data: {}, statusCode: 200 })
        }
        return res.status(403).json({ success: false, error, message: "Other login detected,Session expire", statusCode: 403 })
    } catch (error) {
        return res.status(403).json({ success: false, error, message: "Invalid or expire token", statusCode: 403 })
    }
})

export default router