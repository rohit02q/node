import express from "express"
import jwt from "jsonwebtoken"
import Storage from "../../controller/storage.js";
import { generateAccessToken, generateRefreshToken } from "../../utility/jwt.js";
import { JWT_ACCESS_KEY, JWT_REFRESH_KEY } from "../../config/constant.js";
import { getId, getToken } from "../../utility/identity.js"
import { hashPassword, comparePassword, checkExists } from "../../utility/authHelp.js";
import passwordRoutes from "./passwordManager/password.js"
const router = express.Router()
router.use(express.json())
router.use(express.urlencoded({ extended: true }))
router.post('/signup', async (req, res) => {
    let data = req.body
    if (!data || !data.username || !data.phone || !data.email || !data.password) {
        return res.status(400).json({ success: false, message: "All required data not given" })
    }
    let isExists = await checkExists("all", data)
    if (isExists.exists) { return res.json({ success: false, message: "User already exists" }) }
    const uid = `USER${getId(16)}`
    const sessionId = getToken(8)
    try {
        let userData = {
            username: data.username,
            profile: "/assets/img/profile.jpg",
            fullname: data.fullname || "",
            phone: data.phone,
            email: data.email,
            password: await hashPassword(data.password),
            sessionId,
            blocked: false,
            verified: false,
            chatBan: false,
            canCreateTest: true,
            xp: 0,
            totalTests:"",
            role:"user",
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString()
        }
        let access_token = generateAccessToken(uid, { ...userData, sessionId })
        let refresh_token = generateRefreshToken(uid, { ...userData, sessionId })
        Storage.addUser(uid, userData)
        res.status(201).json({ success: true, data: { access_token, refresh_token } })
        return
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Server Error" })
    }
})

router.post('/login', async (req, res) => {
    try {
        let data = req.body
        const users = Storage.get('users') || {}
        for (let uid in users) {
            if (users[uid].username == data?.username) {
                let isvalidPassword = await comparePassword(data?.password, users[uid].password)
                if (isvalidPassword) {
                    let sessionId = getToken(8)
                    let access_token = generateAccessToken(uid, { ...users[uid], sessionId })
                    let refresh_token = generateRefreshToken(uid, { ...users[uid], sessionId })
                    await Storage.set(`users/${uid}/sessionId`, sessionId)
                    return res.status(200).json({ success: true, data: { access_token, refresh_token } })
                }
            }
        }
        return res.status(400).json({ success: false, message: "username or password is incorrect" })
    } catch (e) {
        return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Server Error" })
    }
})

router.post('/exists', async (req, res) => {
    let resp = await checkExists(req.query.type, req.body)
    return res.json(resp)
})
router.post('/verify-token', (req, res) => {
    let token = req.body?.token
    if (!token) {
        return res.status(400).json({ success: false, message: "Token required", statusCode: 401 })
    }
    try {
        let decoded = jwt.verify(token, JWT_ACCESS_KEY)
        let user = Storage.get(`users/${decoded.uid}`)
        if (user.sessionId == decoded.sessionId) {
            return res.json({ success: true, data: {}, statusCode: 200 })
        }
        return res.status(403).json({ success: false, error, message: "Other login detected,Session expire", statusCode: 403 })
    } catch (error) {
        return res.status(403).json({ success: false, error, message: "Invalid or expire token", statusCode: 403 })
    }
})
router.post('/refresh-token', async (req, res) => {
    let token = req.body?.token
    if (!token) {
        return res.status(400).json({ success: false, message: "Token required", statusCode: 401 })
    }
    try {
        let decoded = jwt.verify(token, JWT_REFRESH_KEY);
        let uid = decoded.uid
        let user = await Storage.get(`users/${uid}`)
        if (user.sessionId == decoded.sessionId) {
            let sessionId = getToken(8)
            await Storage.set(`users/${decoded.uid}/sessionId`, sessionId)
            let access_token = generateAccessToken(uid, { ...user, sessionId })
            let refresh_token = generateRefreshToken(uid, { ...user, sessionId })
            return res.json({ success: true, data: { access_token, refresh_token }, statusCode: 200 })
        }
        return res.status(403).json({ success: false, error, message: "Other login detected,Session expire", statusCode: 403 })
    } catch (error) {
        return res.status(403).json({ success: false, error, message: "Invalid or expire token", statusCode: 403 })
    }
})
router.use('/', passwordRoutes)
export default router