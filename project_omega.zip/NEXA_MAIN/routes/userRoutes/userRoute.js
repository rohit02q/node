import express from "express"
import Storage from "../../controller/storage.js";
import { hashPassword, comparePassword } from "../../utility/authHelp.js"
import {validateUsername} from "../../controller/validator/validateUsername.js"
const router = express.Router()
router.get('/self',async (req, res) => {
    const { uid, ...userData } = req.user
    const { sessionId, lastLogin, password, ...user } = userData
    return res.json({ success: true, data: { _id: uid, ...user } })
})
router.delete('/logout',async (req, res) => {
    const uid = req.user.uid
    await Storage.set(`users/${uid}/sessionId`, null)
    return res.json({ success: true, message: "Logout successfully" })
})
router.post('/update/profile',async (req, res) => {
    try {
        const data = req.body
        const user = req.user
        if (!data) return res.status(400).json({ success: false, message: "Incomplete Data" })
        let fullname = data.fullname || ""
        let phone = data.phone || ""
        if (fullname == user.fullname && phone == user.phone) return res.status(201).json({ success: true, message: "Profile updated successfully", data: {} })
        const {uid,...rest} = user
        await Storage.set(`users/${user.uid}`, { ...rest, fullname, phone })
        return res.status(201).json({ success: true, message: "Profile updated", data: {} })
    } catch (e) {
        return res.status(500).json({ success: false, message: "Profile not updated", error: { message: e.message, data: e } })
    }
})
router.post('/change-password',async (req, res) => {
    try {
        const data = req.body
        if (!data) return res.status(400).json({ success: false, message: "Incomplete Data" })
        const { currentPassword, newPassword } = data
        if (!currentPassword) return res.status(400).json({ success: false, message: "Current password is not given" })
        const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/
        if (!passwordRegex.test(newPassword)) {
            return res.status(400).json({ success: false, message: "Password must be at least 6 characters and contain letters and numbers" })
        }
        const isCorrectPassword = await comparePassword(currentPassword, req.user.password)
        if (!isCorrectPassword) return res.status(400).json({ success: false, message: "Current password is incorrect" })
        const newHashPassword = await hashPassword(newPassword)
        await Storage.set(`users/${req.user.uid}/password`, newHashPassword)
        return res.status(201).json({ success: true, message: "Password updated", data: {} })
    } catch (e) {
        return res.status(500).json({ success: false, message: "Password not updated", error: { message: e.message, data: e } })
    }
})
router.post('/change-username',async (req, res) => {
    try {
        const {username} = req.body
        const isUsernameValid = validateUsername(username)
        if(!isUsernameValid.ok) return res.status(400).json({success:false,message:isUsernameValid.msg})
        await Storage.set(`users/${req.user.uid}/username`,isUsernameValid.value)
        return res.status(201).json({ success: true, message: "Username changed"})
    } catch (e) {
        return res.status(500).json({ success: false, message: "Failed to change username", error: { message: e.message, data: e } })
    }
})
export default router