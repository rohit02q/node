export function canDoPublic(test) {
    if (test.title === "") {
        return { success: false, message: "Enter your test title." }
    }
    if (test.duration <= 0) {
        return { success: false, message: "Test duration should be greater than 1 minute" }
    }
    if (test.totalQuestions === 0) {
        return { success: false, message: "Create At Least One Question." }
    }
    const { questions } = test
    for (let q of Object.values(questions)) {
        if (q.text === "" && !q.image.hasImage) {
            return { success: false, message: "Questions text or Image is missing in some questions" }
        }
        if (q.positiveMarks === 0) {
            return { success: false, message: "Positive marks can't be zero in any questions" }
        }
        if (q.positiveMarks === 0) {
            return { success: false, message: "Positive marks can't be zero in any questions" }
        }
        if (q.answer === null || q.answer === undefined) {
            return { success: false, message: "Correct answer missing in some questions." }
        }
    }
    return { success: true }
}