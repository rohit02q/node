import { TEST_QUESTION_SCHEMA } from "../../controller/schema/schema.js"
import { validateSchema } from "../../controller/validator/validateSchema.js"
export function validateQuestionData(data) {
    const validation = validateSchema(data, TEST_QUESTION_SCHEMA)
    if (!validation.valid) return { valid: false, message: validation.message }
    if (data.options) {
        const options = data.options
        if (options.length > 10) return { valid: false, message: "Maximum ten options allowed " + options.length + " given" }
        for (let opt of data.options) {
            if (typeof opt !== 'string') return { valid: false, message: "All options must be type string." }
        }
        if (data.type === "mcq") {
            if (data.answer >= options.length) {
                return { valid: false, message: "Invalid Answer for this question." }
            }
        }
    }
    return { valid: true }
}