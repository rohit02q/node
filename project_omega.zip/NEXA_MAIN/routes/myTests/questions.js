import express from "express"
import Storage from "../../controller/storage.js"
import { validateQuestionData } from "./validateQuestion.js"
import { creatorVerify } from "../../middlewares/creatorVerify.js"
import { getToken } from "../../utility/identity.js"
const router = express.Router()
router.get('/:testId/questions', creatorVerify, async (req, res) => {
    try {
        let { questions } = req.test
        if (!questions) questions = {}
        Object.values(questions).forEach((q, index) => { q.index = index })
        return res.json({ success: true, data: questions })
    } catch (error) {
        return res.status(500).json({ success: false, error: String(error), message: "Server Error" })
    }
})
router.delete('/:testId/questions/:qId/delete', creatorVerify, async (req, res) => {
    try {
        const testId = req.params.testId
        const qId = req.params.qId
        await Storage.remove(`tests/${testId}/questions/${qId}`)
        await Storage.set(`tests/${testId}/totalQuestions`, req.test.totalQuestions - 1)
        return res.json({ success: true, message: "Question Deleted" })
    } catch (error) {
        return res.status(500).json({ success: false, error: String(error), message: "Server Error" })
    }
})
router.post('/:testId/questions/:qId/edit', creatorVerify, async (req, res) => {
    try {
        const testId = req.params.testId
        const qId = req.params.qId
        const data = req.body
        const validation = validateQuestionData(data)
        if (!validation.valid) return res.status(400).json({ success: false, message: validation.message })
        let pos = parseInt(data.positiveMarks) * Math.sign(data.positiveMarks) ?? 0
        let neg = parseInt(data.negativeMarks) * Math.sign(data.negativeMarks) ?? 0
        if (isNaN(pos)) pos = 0
        if (isNaN(neg)) neg = 0
        const updated = {
            type: data.type || "mcq",
            text: data.text || "",
            positiveMarks: pos,
            negativeMarks: neg,
            options: data.options || [],
            updatedAt: Date.now(),
            explanation: data.explanation || "",
            answer: data.answer ?? null
        }
        const allQ = await Storage.get(`tests/${testId}/questions`) || {}
        const previous = allQ[qId] || {}
        allQ[qId] = { ...previous, ...updated }
        await Storage.set(`tests/${testId}/questions`, allQ)
        return res.status(201).json({ success: true, message: "Question updated successfully" })
    } catch (error) {
        return res.status(500).json({ success: false, error: String(error), message: "Server Error" })
    }
})
router.post('/:testId/questions/add-new', creatorVerify, async (req, res) => {
    try {
        const testId = req.params.testId
        const data = req.body
        const validation = validateQuestionData(data)
        if (!validation.valid) return res.status(400).json({ success: false, message: validation.message })
        const qId = getToken(6)
        let pos = parseInt(data.positiveMarks) ?? 0
        let neg = parseInt(data.negativeMarks) * Math.sign(data.negativeMarks) ?? 0
        if (isNaN(pos)) pos = 0
        if (isNaN(neg)) neg = 0
        const newQuestion = {
            type: data.type || "mcq",
            text: data.text || "",
            explanation: "",
            positiveMarks: pos,
            negativeMarks: neg,
            options: [],
            image: {
                hasImage: false,
                imageUrl: null,
                updatedAt: Date.now()
            },
            createdAt: Date.now(),
            updatedAt: Date.now(),
            answer: null
        }
        await Storage.set(`tests/${testId}/totalMarks`, req.test.totalMarks + parseInt(data.positiveMarks) ?? 0)
        await new Promise(r => setTimeout(r, 400))
        await Storage.set(`tests/${testId}/totalQuestions`, req.test.totalQuestions + 1)
        await new Promise(r => setTimeout(r, 300))
        const allQ = await Storage.get(`tests/${testId}/questions`) || {}
        allQ[qId] = newQuestion
        await Storage.set(`tests/${testId}/questions`, allQ)
        return res.status(201).json({ success: true, data: { _id: qId, ...newQuestion }, message: "New question created" })
    } catch (error) {
        return res.status(500).json({ success: false, error: String(error), message: "Server Error" })
    }
})
export default router