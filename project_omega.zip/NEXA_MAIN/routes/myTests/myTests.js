import express from "express"
import questionsRoute from "./questions.js"
import resultSummary from "./resultSummary.js"
import Storage from "../../controller/storage.js"
import { getId } from "../../utility/identity.js"
import { creatorVerify } from "../../middlewares/creatorVerify.js"
import { comparePassword } from "../../utility/authHelp.js"
import { EDIT_TEST_SCHEMA } from "../../controller/schema/schema.js"
import { validateSchema } from "../../controller/validator/validateSchema.js"
import { canDoPublic } from "./canDoPublic.js"
const router = express.Router()
router.get('/test_setting_info', async (req, res) => {
  try {
    const test_setting_info = {
      shuffle: { name: "Shuffle Questions", text: 'Randomizes the order of questions for every user in every attempt. This helps reduce cheating and ensures fairness' },
      hideResult: { name: "Hide Result", text: 'Enable this to hide the result from students after submission. Only the creator will be able to view the result.' },
      solutions: { name: "Solutions Hidden", text: 'When enabled, users will be able to view correct answers and explanations after submitting the test.' },
      reattempt: { name: "Stop Reattempt", text: ' If enabled, users can attempt this test multiple times. Disable it to restrict the test to only one attempt per user.' },
      focusGuard: { name: "Focus Guard", text: 'Enable this feature if you want extra security durning exam this help to detect cheating and force auto submit. when user switch tab or minimize app it\'s show a warning message.' },
      blockedUsers: { name: "Blocked Users", text: 'Your test not show in Blocked users account.They can\'t attempt your test.' },
    }
    return res.json({ success: true, data: test_setting_info })
  } catch (error) {
    return res.status(500).json({ success: false, error, message: "Server Error" })
  }
})
router.get('/list-tests', async (req, res) => {
  try {
    const allTests = await Storage.get('tests')
    const myTests = []
    const allUsers = await Storage.get('users')
    const allUsersArr = Object.entries(allUsers).map(([id, u]) => ({ id, ...u }))
    Object.entries(allTests).forEach(async ([id, test]) => {
      if (test.creator === req.user.uid) {
        const blocked_users_uid = [...test.blockedUsers]
        const blockedUsers = []
        blocked_users_uid.forEach(usr => {
          const user = allUsersArr.find(u => u.id === usr)
          if (user) {
            blockedUsers.push(user.username)
          }
        })
        const { creator, ...rest } = test
        myTests.push({ _id: id, ...rest, blockedUsers })
      }
    })
    myTests.sort((a, b) => b.updatedAt - a.updatedAt)
    return res.json({ success: true, data: myTests })
  } catch (error) {
    return res.status(500).json({ success: false, error, message: "Server Error" })
  }
})
router.get('/:testId/load', creatorVerify, async (req, res) => {
  try {
    const { creator, ...test } = req.test
    const allUsers = await Storage.get('users')
    const allUsersArr = Object.entries(allUsers).map(([id, u]) => ({ id, ...u }))
    const blocked_users_uid = [...test.blockedUsers]
    const blockedUsers = []
    blocked_users_uid.forEach(usr => {
      const user = allUsersArr.find(u => u.id === usr)
      if (user) {
        blockedUsers.push(user.username)
      }
    })
    return res.json({ success: true, data: { ...test, blockedUsers } })
  } catch (error) {
    return res.status(500).json({ success: false, error, message: "Server Error" })
  }
})
router.post("/:testId/edit", creatorVerify, async (req, res) => {
  try {
    const testId = req.params.testId
    const incoming = req.body
    const test = req.test
    const validation = validateSchema(incoming, EDIT_TEST_SCHEMA);
    if (!validation.valid) return res.json({ success: false, message: validation.message });
    for (let u of incoming.blockedUsers) {
      if (typeof u !== "string" || u.length > 30)
        return res.json({
          success: false,
          message: "Invalid username inside blockedUsers",
        })
    }
    if (incoming.entryType === "locked" && !incoming.entryCode?.trim()) {
      return res.json({
        success: false,
        message: "Entry code required for locked test",
      })
    }
    const updated = { ...incoming }
    if (updated.isResultHidden && !updated.isSolutionsHidden && updated.isReattemptAllowed) {
      return res.status(400).json({ success: false, message: "If Result hidden then solutions must be hidden & reattempt not allowed." })
    }
    if (updated.entryType === "free") updated.entryCode = ""
    updated.duration = Math.floor(updated.duration)
    const allUsers = await Storage.get('users')
    const allUsersArr = Object.entries(allUsers).map(([id, u]) => ({ id, ...u }))
    const blockedUsers = [...updated.blockedUsers]
    const blocked_users_uid = []
    blockedUsers.forEach(usr => {
      const user = allUsersArr.find(u => u.username === usr)
      if (user) {
        blocked_users_uid.push(user.id)
        return
      }
    })
    const finalObj = {
      ...test,
      ...updated,
      blockedUsers: blocked_users_uid,
      updatedAt: Date.now(),
    }
    await Storage.set(`tests/${testId}`, finalObj);
    // Firestore:
    // await db.collection("tests").doc(testId).set(finalObj, { merge: true });
    return res.json({
      success: true,
      message: "Test updated",
    })
  } catch (err) {
    return res.status(500).json({
      success: false,
      error: err.message,
      message: "Server error",
    })
  }
})
router.post('/new', async (req, res) => {
  try {
    const uid = req.user.uid
    const { title } = req.body
    if (!title) return res.status(400).json({ success: false, message: "Test title required" })
    if (!req.user.canCreateTest) return res.status(403).json({ success: false, message: "You are not allowed to create test." })
    const testId = `TEST${getId(12)}`
    const newTest = {
      creator: uid,
      visibility: "private",
      title,
      entryType: "free",
      entryCode: "",
      blockedUsers: [],
      duration: 0,
      description: "",
      focusGuard: {
        enabled: false,
        maxAwayTime: 180000,
        maxTabSwitch: 5
      },
      isReattemptAllowed: true,
      maxReattemptLimit: 10,
      isSolutionsHidden: false,
      isResultHidden: false,
      shuffle: false,
      popularity: 0,
      totalQuestions: 0,
      totalMarks: 0,
      totalAttemptsCount: 0,
      totalUsersAttempted: 0,
      createdAt: Date.now(),
      updatedAt: Date.now()
    }
    if (req.user.totalTests === undefined) req.user.totalTests = 0
    await Storage.set(`users/${uid}/totalTests`, req.user.totalTests + 1)
    await Storage.set(`tests/${testId}`, newTest)
    const { creator, ...data } = newTest
    return res.status(201).json({ success: true, data: { _id: testId, ...data }, message: `New test created with title ${title}` })
  } catch (e) {
    return res.status(500).json({ success: false, error: { message: e.message, data: e }, message: "Server Error" })
  }
})
router.post('/:testId/change-visibility', creatorVerify, async (req, res) => {
  try {
    const testId = req.params.testId
    const test = req.test
    if (test.visibility === "private") {
      const canDo = canDoPublic(test)
      if (canDo.success) {
        await Storage.set(`tests/${testId}/visibility`, "public")
        if (test.totalAttemptsCount <= 0) {
          await Storage.set(`tests/${testId}/publishedAt`, Date.now())
        }
        return res.json({ success: true, message: "Your test published successfully" })
      } else {
        return res.status(400).json(canDo)
      }
    } else {
      await Storage.set(`tests/${testId}/visibility`, "private")
      return res.json({ success: true, message: "Tests visibility Switched to private" })
    }
  } catch (error) {
    return res.status(500).json({ success: false, error: String(error), message: "Server Error" })
  }
})
router.delete('/:testId/delete', creatorVerify, async (req, res) => {
  try {
    const testId = req.params.testId
    const test = req.test
    if (test.totalQuestions > 5 || test.totalAttemptsCount > 0) {
      const { password } = req.body
      if (!password) return res.status(400).json({ success: false, message: "Password Required" })
      const isCorrectPassword = await comparePassword(password, req.user.password)
      if (!isCorrectPassword) return res.status(400).json({ success: false, message: "Password is incorrect" })
    }
    await Storage.remove(`tests/${testId}`)
    await Storage.set(`users/${req.user.uid}/totalTests`, req.user.totalTests - 1)
    return res.json({ success: true, message: "Test Deleted" })
  } catch (error) {
    return res.status(500).json({ success: false, error: String(error), message: "Internal Server Error" })
  }
})
router.use('/', questionsRoute)
router.use('/', resultSummary)
export default router