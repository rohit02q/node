import express from "express"
import Storage from "../../controller/storage.js"
import { creatorVerify } from "../../middlewares/creatorVerify.js"
const router = express.Router()

router.get('/:testId/result-summary', creatorVerify, async (req, res) => {
    try {
        const testId = req.params.testId
        const attemptsSnap = await Storage.get(`attempts`) || {}
        const attempts = Object.entries(attemptsSnap).map(([id, doc]) => ({ id, ...doc })).filter(a => a.testId === testId)
        const groups = {}
        for (const a of attempts) {
            if (!groups[a.uid]) { groups[a.uid] = [] }
            groups[a.uid].push(a)
        }
        const results = []
        for (const uid in groups) {
            const arr = groups[uid]
            arr.sort((a, b) => b.startTime - a.startTime)
            const latest = arr[0]
            const user = await Storage.get(`users/${uid}`)
            results.push({
                _id: user.username,
                attemptCount: arr.length,
                user: {
                    username: user.username,
                    profile: user.profile,
                    name: user.name || ""
                },
                lastAttempt: {
                    attemptOn: latest.startTime,
                    submitOn: latest.submitTime,
                    _id: latest.id
                }
            })
        }
        // results.sort((a, b) => b.lastAttempt.createdAt - a.lastAttempt.createdAt)
        return res.json({ success: true, data: results })




    } catch (e) {
        return res.status(500).json({
            success: false,
            error: { message: e.message, data: String(e) },
            message: "Internal server error",
        })
    }
})
export default router