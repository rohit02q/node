console.time("Server Start In")
import express from 'express'
import path from "path"
import apiRoutes from "./routes/apiRoute.js"
import htmlRoutes from "./routes/htmlRoutes.js"
const app = express();
const PORT = process.env.PORT || 3000
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(express.static(path.join(import.meta.dirname, 'public')))
app.use('/api', apiRoutes)
app.use(htmlRoutes)
app.listen(PORT, () => { console.log('Live Server is Running on port', PORT) })
console.timeEnd("Server Start In")