export default function (params){
    if (!APP_STATE.isLoggedIn) {
        toast('Please login to access this page', 'error');
        navigate('/');
        return false;
    }
    return true;
};