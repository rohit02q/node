export default function (params){
    if (APP_STATE.isLoggedIn && APP_STATE.user.role.toLowerCase() === "admin") return true
       toast("#Request Blocked#", "error")
    navigate('/')
    return false
};