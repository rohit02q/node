export default function (params){
    if (APP_STATE.isLoggedIn) {
        toast('You are already logged in', 'normal');
        navigate('/');
        return false;
    }
    return true;
};