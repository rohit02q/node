export function TopNav() {
    let rightContent = null
    if (APP_STATE.isLoggedIn) {
        rightContent = ''
    } else {
        rightContent = `
    <div class="flex gap-2" >
    <button onclick="navigate('/login')" class="border-primary border px-4 py-1.5 bg-white text-primary rounded-lg text-sm font-medium">Sign Up</button>
        <button onclick="navigate('/login')" class="px-4 py-1.5 bg-primary text-white rounded-lg text-md font-medium">Login</button>
    </div> 
    `
    }
    return `
            <button id="menuBtn" class="w-10 h-10 flex items-center justify-center -ml-2" aria-label="Menu">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
        </button>
        <div class="flex items-center ml-2">
            <div class="w-8 h-8 rounded bg-primary flex items-center justify-center">
                <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path
                        d="M12 2L2 7v10c0 5.5 3.8 10.7 10 12 6.2-1.3 10-6.5 10-12V7l-10-5zm0 18c-4.4-1-7-4.8-7-9V8.3l7-3.9 7 3.9V11c0 4.2-2.6 8-7 9z" />
                </svg>
            </div>
            <span class="ml-2 font-semibold text-lg">Nexa</span>
        </div>
        <div class="flex-1"></div>
        ${rightContent}
        `
}

export function BottomNav() {
    const tabs = [
        {
            path: "/",
            name: "Home",
            icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3"></path>
      </svg>`
        },
        {
            path: "/explore",
            name: "Explore",
            icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <circle cx="11" cy="11" r="6" stroke-width="2"></circle>
            <path stroke-linecap="round" stroke-width="2" d="M20 20l-3-3"></path>
            <path stroke-linecap="round" stroke-width="2" d="M17 4l1 2 2 1-2 1-1 2-1-2-2-1 2-1z"></path>
          </svg>`
        },
        {
            path: "/create",
            name: "Create",
            icon: `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                    </svg>
`
        },
        {
            path: "/results",
            name: "Results",
            icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path stroke-width="2" d="M4 15l5-5 4 4 7-7"></path>
            <path d="M17 2h5v5" stroke-width="2"></path>
          </svg>`
        },
        {
            path: "/settings",
            name: "Settings",
            icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
      </svg>`
        }
    ]
    return tabs.map(t => (`
        <a href="${t.path}" class="tab-btn" data-tab="${t.name.toLowerCase()}" aria-label="${t.name}">
            ${t.icon}
            <span class="text-xs mt-1">${t.name}</span>
        </a>
    `)).join(' ')
}

export function SideMenu() {
    let menuProfile = null
    if (APP_STATE.isLoggedIn) {
        menuProfile = `
                 <div class="flex items-center pb-4 border-b mb-2" onclick="navigate('/profile')">
                 <div class="w-12 h-12 flex items-center justify-center cursor-pointer border rounded-full overflow-hidden">
                 <img class="object-fit" src="${APP_STATE.user.profile}" alt=${APP_STATE.user.name}-profile-photo" width="100%" height="100%">
                 </div>
                <div class="ml-3">
                    <div class="font-semibold">Hi, ${APP_STATE.user.fullname.split(' ')[0]}</div>
                    <div class="text-sm text-gray-500">View profile</div>
                </div>
            </div>
          `
    } else {
        menuProfile = `
            <div class="flex items-center pb-4 border-b mb-2" onclick = "navigate('/login')" >
                <div class="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center cursor-pointer">
                    <svg class="w-6 h-6 text-gray-500" fill="currentColor" viewBox="0 0 24 24">
                        <path
                            d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                    </svg>
                </div>
                <div class="ml-3 p-1">
                    <div class="font-semibold">Hi, User</div>
                    <div class="text-sm text-gray-500">Login to create & share tests</div>
                </div>
            </div>
            `
    }
    const navLinks = [
        {
            path: "/",
            name: "Home",
            icon: `<svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                    </svg>`
        },
        {
            path: "/tests",
            name: "My Tests",
            icon: `    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                        </path>
                    </svg>`
        },
        {
            path: "/create",
            name: "Create Test",
            icon: `<svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                    </svg>`
        },
        {
            path: "/results",
            name: "Results",
            icon: `      <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>`
        },
        {
            path: "/settings",
            name: "Settings",
            icon: `      <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>`
        },
        {
            path: "/notice",
            name: "Notice",
            icon: `<svg xmlns="http://www.w3.org/2000/svg" class="text-gray-800 w-5 h-5 mr-3" viewBox="0 0 448 512"><path fill="currentColor" d="M448 296c0 66.3-53.7 120-120 120l-8 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l8 0c30.9 0 56-25.1 56-56l0-8-64 0c-35.3 0-64-28.7-64-64l0-64c0-35.3 28.7-64 64-64l64 0c35.3 0 64 28.7 64 64l0 136zm-256 0c0 66.3-53.7 120-120 120l-8 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l8 0c30.9 0 56-25.1 56-56l0-8-64 0c-35.3 0-64-28.7-64-64l0-64c0-35.3 28.7-64 64-64l64 0c35.3 0 64 28.7 64 64l0 136z"/></svg>`
        },
        {
            path: "/social-links",
            name: "Social links",
            icon:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="w-5 h-5 mr-3"><path fill="currentColor" d="M419.5 96c-16.6 0-32.7 4.5-46.8 12.7-15.8-16-34.2-29.4-54.5-39.5 28.2-24 64.1-37.2 101.3-37.2 86.4 0 156.5 70 156.5 156.5 0 41.5-16.5 81.3-45.8 110.6l-71.1 71.1c-29.3 29.3-69.1 45.8-110.6 45.8-86.4 0-156.5-70-156.5-156.5 0-1.5 0-3 .1-4.5 .5-17.7 15.2-31.6 32.9-31.1s31.6 15.2 31.1 32.9c0 .9 0 1.8 0 2.6 0 51.1 41.4 92.5 92.5 92.5 24.5 0 48-9.7 65.4-27.1l71.1-71.1c17.3-17.3 27.1-40.9 27.1-65.4 0-51.1-41.4-92.5-92.5-92.5zM275.2 173.3c-1.9-.8-3.8-1.9-5.5-3.1-12.6-6.5-27-10.2-42.1-10.2-24.5 0-48 9.7-65.4 27.1L91.1 258.2c-17.3 17.3-27.1 40.9-27.1 65.4 0 51.1 41.4 92.5 92.5 92.5 16.5 0 32.6-4.4 46.7-12.6 15.8 16 34.2 29.4 54.6 39.5-28.2 23.9-64 37.2-101.3 37.2-86.4 0-156.5-70-156.5-156.5 0-41.5 16.5-81.3 45.8-110.6l71.1-71.1c29.3-29.3 69.1-45.8 110.6-45.8 86.6 0 156.5 70.6 156.5 156.9 0 1.3 0 2.6 0 3.9-.4 17.7-15.1 31.6-32.8 31.2s-31.6-15.1-31.2-32.8c0-.8 0-1.5 0-2.3 0-33.7-18-63.3-44.8-79.6z"/></svg>`
        }
    ]
    return `
       <div class="p-6">
          ${menuProfile}
            <nav class="space-y-1 border-b">
               ${navLinks.map(l => {
        return ` <a href="${l.path}" class="flex items-center px-3 py-2.5 rounded-lg hover:bg-gray-50">
                ${l.icon}
                  ${l.name}
                </a>`
    }).join(' ')}
    </nav>
      ${APP_STATE.isLoggedIn ? `
        ${APP_STATE.user.role.toLowerCase() === "admin" ?
                `<a href="/admin" class="flex items-center px-3 py-2.5 rounded-lg hover:bg-gray-50 text-blue-600">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" class="w-5 h-5 mr-3"><path fill="currentColor" d="M256.5 8a120 120 0 1 1 0 240 120 120 0 1 1 0-240zM226.7 304l59.4 0 1.5 0c-12.9 26.8-7.8 58.2 11.5 79.5-20.2 22.3-24.8 55.8-9.4 83.4l22.5 40.4c.9 1.6 1.9 3.2 2.9 4.7l-237 0c-16.4 0-29.7-13.3-29.7-29.7 0-98.5 79.8-178.3 178.3-178.3zm205.9-56.4c0-13.3 10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 6.1c0 18.9 24.1 32.8 40.5 23.4l5-2.9c11.6-6.7 26.5-2.6 33 9.1l22.4 40.2c6.2 11.2 2.6 25.2-8.2 32l-4.7 2.9c-16.2 10.1-16.2 39.9 0 50.1l4.6 2.9c10.8 6.8 14.5 20.8 8.3 32L607 483.8c-6.5 11.7-21.4 15.9-33 9.1l-4.9-2.9c-16.4-9.5-40.5 4.5-40.5 23.4l0 6.1c0 13.3-10.7 24-24 24l-48 0c-13.3 0-24-10.7-24-24l0-5.9c0-19-24.2-33-40.7-23.5l-4.8 2.8c-11.6 6.7-26.4 2.6-33-9.1l-22.6-40.4c-6.2-11.2-2.6-25.3 8.3-32.1l4.4-2.7c16.3-10.1 16.3-40.1 0-50.2l-4.5-2.8c-10.9-6.8-14.5-20.9-8.3-32.1l22.5-40.3c6.5-11.7 21.4-15.8 32.9-9.1l4.8 2.8c16.5 9.5 40.7-4.5 40.7-23.5l0-5.9zm99.9 136.2a52 52 0 1 0 -104 0 52 52 0 1 0 104 0z"/></svg>
                    Admin
                </a>`: ''}
                 <a href="/logout" class="border-b flex items-center px-3 py-2.5 rounded-lg hover:bg-gray-50 text-red-600">
                <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
                    Logout
                </a>
        ` : ""}
        <div class="pt-2">
         <p class="text-gray-500">Made with <span class="text-red-600">&hearts;</span> in Bihar</p>
        </div>
    `
}
