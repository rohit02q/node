// ! This is faltu stuffs.
//! I dont need this i remove this later 
//!  useless bekar hai ye part have to delete

const MOCK_DB = {
    tests: [
        {
            id: 'test_1',
            title: 'Introduction to JavaScript',
            subject: 'Programming',
            visibility: 'public',
            questionCount: 25,
            duration: 30,
            maxMarks: 100,
            isLocked: false,
            color: '#3b82f6',
            createdBy: 'user_2'
        },
        {
            id: 'test_2',
            title: 'Advanced React Patterns',
            subject: 'Web Dev',
            visibility: 'locked',
            questionCount: 18,
            duration: 45,
            maxMarks: 75,
            isLocked: true,
            color: '#8b5cf6',
            createdBy: 'user_3'
        },
        {
            id: 'test_3',
            title: 'Mathematics - Calculus I',
            subject: 'Mathematics',
            visibility: 'users',
            questionCount: 30,
            duration: 60,
            maxMarks: 150,
            isLocked: false,
            color: '#10b981',
            createdBy: 'user_1'
        },
        {
            id: 'test_4',
            title: 'Physics: Mechanics',
            subject: 'Physics',
            visibility: 'public',
            questionCount: 20,
            duration: 40,
            maxMarks: 100,
            isLocked: false,
            color: '#f59e0b',
            createdBy: 'user_4'
        },
        {
            id: 'test_5',
            title: 'English Grammar Basics',
            subject: 'English',
            visibility: 'public',
            questionCount: 15,
            duration: 20,
            maxMarks: 50,
            isLocked: false,
            color: '#ec4899',
            createdBy: 'user_2'
        },
        {
            id: 'test_6',
            title: 'Data Structures & Algorithms',
            subject: 'Computer Science',
            visibility: 'locked',
            questionCount: 35,
            duration: 90,
            maxMarks: 200,
            isLocked: true,
            color: '#06b6d4',
            createdBy: 'user_5'
        },
        {
            id: 'test_7',
            title: 'World History: Ancient Civilizations',
            subject: 'History',
            visibility: 'users',
            questionCount: 22,
            duration: 35,
            maxMarks: 80,
            isLocked: false,
            color: '#ef4444',
            createdBy: 'user_1'
        },
        {
            id: 'test_8',
            title: 'Chemistry: Organic Compounds',
            subject: 'Chemistry',
            visibility: 'public',
            questionCount: 28,
            duration: 50,
            maxMarks: 120,
            isLocked: false,
            color: '#14b8a6',
            createdBy: 'user_6'
        }
    ]
}

// Magic Seacrch Icon
// `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor">
//             <circle cx="11" cy="11" r="6" stroke-width="2"></circle>
//             <path stroke-linecap="round" stroke-width="2" d="M20 20l-3-3"></path>
//             <path stroke-linecap="round" stroke-width="2" d="M17 4l1 2 2 1-2 1-1 2-1-2-2-1 2-1z"></path>
//           </svg>`


const API = {
    async getTests(filter = 'all') {
        await delay(300);
        if (filter === 'all') return MOCK_DB.tests;
        return MOCK_DB.tests.filter(t => t.visibility === filter);
    },
    async searchTests(query) {
        await delay(200);
        return MOCK_DB.tests.filter(t =>
            t.title.toLowerCase().includes(query.toLowerCase()) ||
            t.subject.toLowerCase().includes(query.toLowerCase())
        );
    },

    async getAttempts(userId) {
        await delay(300);
        return MOCK_DB.attempts.filter(a => a.userId === userId);
    },

    async startAttempt(testId) {
        await delay(500);
        return { attemptId: `attempt_${Date.now()}`, started: true };
    },

    async getTestDetails(testId) {
        await delay(200);
        return MOCK_DB.tests.find(t => t.id === testId);
    }
};

// ============================================
// UTILITY FUNCTIONS
// ============================================

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function getInitials(name) {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
}

function saveToCache(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
        console.error('Cache save failed:', e);
    }
}

function loadFromCache(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (e) {
        console.error('Cache load failed:', e);
        return null;
    }
}

// ============================================
// ACTION HANDLERS
// ============================================

function handleCreateClick() {
    if (!APP_STATE.isLoggedIn) {
        navigate('/login');
    } else {
        navigate('/create');
    }
}

async function handleStartTest(testId) {
    if (!APP_STATE.isLoggedIn) {
        navigate('/login');
        return;
    }

    toast('Starting test...', 'normal');

    try {
        const result = await API.startAttempt(testId);
        toast('Test started successfully!', 'success');
        // Here you would navigate to the test player
        // For demo, just show a message
        setTimeout(() => {
            toast('Test player would load here', 'normal');
        }, 1000);
    } catch (e) {
        toast('Failed to start test', 'error');
    }
}
function handleReattempt(testId) {
    openDrawer(`
        <div class="text-center">
            <h3 class="text-xl font-semibold mb-3">Reattempt Test?</h3>
            <p class="text-gray-600 mb-6">Your previous score will be replaced with the new attempt.</p>
            <div class="space-y-2">
                <button class="btn-primary w-full" onclick="confirmReattempt('${testId}')">Yes, Reattempt</button>
                <button class="btn-secondary w-full" onclick="closeDrawer()">Cancel</button>
            </div>
        </div>
    `, '40vh');
}

function confirmReattempt(testId) {
    closeDrawer();
    handleStartTest(testId);
}
function handleEditTestSubmit(event, testId) {
    event.preventDefault();
    toast('Test updated successfully!', 'success');
    navigate('/create');
}

function editProfilePicture() {
    toast('Profile picture upload coming soon!', 'normal');
}


export function init(){
    window.handleStartTest = handleStartTest;
    window.handleReattempt = handleReattempt;
    window.confirmReattempt = confirmReattempt;
    window.handleEditTestSubmit = handleEditTestSubmit;
    window.handleCreateClick = handleCreateClick;
    window.editProfilePicture = editProfilePicture;
    window.MOCK_DB = MOCK_DB
    window.API = API
    window.getInitials = getInitials
}