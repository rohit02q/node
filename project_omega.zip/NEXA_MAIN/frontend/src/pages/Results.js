export async function Results() {
    if (!APP_STATE.isLoggedIn) {
        return `
        <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <h3>Login Required</h3>
                <p>Please login to view your test results</p>
             <button class="btn-primary mt-4" onclick="navigate('/login')">Login</button>
            </div>
        `
    }
    return `
        <div class="p-4 flex flex-col gap-4 h-full w-full">
            <h2 class="font-semibold text-xl">Your Results</h2>
            <div class="filter-chips border-b pb-4">
                <div class="filter-chip test-summary-filter" data-filter="all">All</div>
                <div class="filter-chip test-summary-filter" data-filter="completed">Completed</div>
                <div class="filter-chip test-summary-filter" data-filter="resume">Resume</div>
            </div>
            <div id="summaryList" class="flex-1 overflow-y-auto pt-3 hideScroll space-y-4">
            ${'<div class="skeleton h-24 mb-3 rounded-lg border border-gray-400"></div>'.repeat(5)}
            </div>
        </div>
    `;
}
export async function init(_, box) {
    if (!APP_STATE.isLoggedIn) return
    function emptyState(title, text) {
        return `
              <div class="empty-state">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                        </path>
                     </svg>
                    <h3>${title}</h3>
                    <p>${text}</p>
                    </div>
        `
    }
    let allSummary;
    const summaryList = document.getElementById("summaryList")
    function renderSummaryCard(filter) {
        if (allSummary.length === 0) {
            return summaryList.innerHTML = emptyState("No Results Yet", "Take your first test to see results here")
        }
        let summary;
        if (filter == 'all') { summary = allSummary }
        else { summary = allSummary.filter(t => t.lastAttempt.status === filter) }
        if (summary.length == 0) {
            return summaryList.innerHTML = emptyState("No Tests Yet", `There is no any ${filter} test`)
        }
        summaryList.innerHTML = summary.map(test => {
            let actionBtn = test.lastAttempt.status === "completed" ? `<div class="cursor-pointer flex flex-col justify-center items-center gap-[1px]"  onclick="navigate('/results/${test._id}')">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-8 h-8 py-1 px-2 text-white bg-orange-400 rounded-full">>
                       <path fill="currentColor" d="M256 64c-56.8 0-107.9 24.7-143.1 64l47.1 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 192c-17.7 0-32-14.3-32-32L0 32C0 14.3 14.3 0 32 0S64 14.3 64 32l0 54.7C110.9 33.6 179.5 0 256 0 397.4 0 512 114.6 512 256S397.4 512 256 512c-87 0-163.9-43.4-210.1-109.7-10.1-14.5-6.6-34.4 7.9-44.6s34.4-6.6 44.6 7.9c34.8 49.8 92.4 82.3 157.6 82.3 106 0 192-86 192-192S362 64 256 64z"/>
                     </svg>
                            <span class="text-xs font-semibold">
                                Reattempt
                            </span>
                        </div>` : `<div class="cursor-pointer flex flex-col justify-center items-center gap-[1px]" onclick="navigate('/tests/${test._id}')">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                class="w-8 h-8 py-1 px-2 text-white bg-pink-500 rounded-full">
                                <path fill="currentColor"
                                    d="M502.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L402.7 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l370.7 0-105.4 105.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z" />
                            </svg>
                            <span class="text-xs font-semibold">
                                Resume
                            </span>
                        </div>`

            return `
                  <div class="bg-card rounded-lg border p-4">
                  <div class="inline-flex items-center gap-2 mt-1 ${test.testCreator.verified ? 'cursor-pointer " onclick="showVerifyInfo()"' : '"'}>
                  <img 
    src="${test.testCreator.profile}" 
    class="w-6 h-6 rounded-full border" 
    alt="creator"
    />
  <span class="${test.testCreator.verified ? 'text-blue-600' : 'text-secondary'} font-medium">
    ${test.testCreator.username}
    </span>
  ${test.testCreator.verified
                    ? '<svg stroke="currentColor" id="verifyIcon" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="text-blue-500 w-4 h-4" xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0z"></path><path d="M23 12l-2.44-2.79.34-3.69-3.61-.82-1.89-3.2L12 2.96 8.6 1.5 6.71 4.69 3.1 5.5l.34 3.7L1 12l2.44 2.79-.34 3.7 3.61.82L8.6 22.5l3.4-1.47 3.4 1.46 1.89-3.19 3.61-.82-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81 1.48-1.48 2.32 2.33 5.85-5.87 1.48 1.48-7.33 7.35z"></path></svg>'
                    : ''
                }
</div>
<div class="font-semibold">${test.title}</div>
                    <div class="flex mt-1">
                        <div class="flex-1">
                            <div class="flex gap-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                    class="w-4 h-4 text-indigo-400">
                                    <path fill="currentColor"
                                        d="M133.8 36.3c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 158 47 153L7 113C-2.3 103.6-2.3 88.4 7 79S31.6 69.7 41 79l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zm0 160c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 318 47 313L7 273c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zM224 96c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zm0 160c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zM160 416c0-17.7 14.3-32 32-32l288 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-288 0c-17.7 0-32-14.3-32-32zM64 376a40 40 0 1 1 0 80 40 40 0 1 1 0-80z" />
                                </svg>
                                <span class="text-gray-900 text-sm">
                                    ${test.totalQuestions} Questions • ${test.totalMarks} Marks • ${test.duration} mins
                                </span>
                            </div>
                            <div class="flex gap-1 items-center">
                               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4 text-indigo-400">>
                       <path fill="currentColor" d="M256 64c-56.8 0-107.9 24.7-143.1 64l47.1 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 192c-17.7 0-32-14.3-32-32L0 32C0 14.3 14.3 0 32 0S64 14.3 64 32l0 54.7C110.9 33.6 179.5 0 256 0 397.4 0 512 114.6 512 256S397.4 512 256 512c-87 0-163.9-43.4-210.1-109.7-10.1-14.5-6.6-34.4 7.9-44.6s34.4-6.6 44.6 7.9c34.8 49.8 92.4 82.3 157.6 82.3 106 0 192-86 192-192S362 64 256 64z"/>
                     </svg>
                                <span class="text-gray-900 text-sm">
                                Total Attempt: ${test.attemptCount}
                           </span>
                            </div>
                            <div class="flex gap-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"
                                    class="w-4 h-4 text-indigo-400">
                                    <path fill="currentColor"
                                        d="M128 0c17.7 0 32 14.3 32 32l0 32 128 0 0-32c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-32c0-17.7 14.3-32 32-32zM64 240l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm128 0l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM64 368l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zm112 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16z" />
                                </svg>
                                <span class="text-gray-900 text-sm">
                                    ${new Date(test.lastAttempt.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: "2-digit", minute: "2-digit", hour12: true })}
                                </span>
                            </div>
                        </div> ${actionBtn}
                    </div>
                </div>
                    `
        }).join('')
    }
    const query = new URLSearchParams(location.search)
    let filter = query.get('status') || ""
    if (filter.toLocaleLowerCase() !== "completed" && filter.toLocaleLowerCase() !== "resume") { filter = "all" }
    document.querySelector(`.test-summary-filter[data-filter=${filter}]`).classList.add('active')
    const filterChips = document.querySelectorAll('.test-summary-filter');
    filterChips.forEach(chip => {
        box.addEvent(chip, 'click', () => {
            filterChips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            if (filter == chip.dataset.filter) return
            filter = chip.dataset.filter
            history.replaceState({}, "", "?status=" + filter)
            renderSummaryCard(filter)
        });
    });
    let cachedSummary = cache.get('testSummary')
    if (!cachedSummary) {
        const resp = await fetchData('/tests/summary')
        if (!resp || !resp?.success) {
            return emptyState('Something went worng', resp?.message || "Failed to load results")
        }
        allSummary = resp.data
        cache.set('testSummary', allSummary, 2 * 60 * 1000)
    } else {
        allSummary = cachedSummary
    }
    renderSummaryCard(filter)
}