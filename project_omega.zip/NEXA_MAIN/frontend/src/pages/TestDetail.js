export async function TestDetail(params) {
    const testId = params.testId
    const resp = await fetchData(`/tests/${testId}/details`)
    if (!resp || !resp?.success) return resp?.message || "test nahi mila is id se"
    const test = resp.data
    APP_STATE.current_test_details = test
    const creator = test.testCreator
    function actionBtn() {
        if (test.entryType.toLowerCase() !== "free") {
            return `
            <div class="space-y-4">
              <div>
                         <input
                           id="test_entryCode"
                           class="w-full mt-1 px-3 py-3 border-2 font-medium border-gray-400 rounded-xl outline-none focus:border-primary"
                           placeholder="Enter entry code"
                           autocomplete="off"
                           spellcheck = "false" 
                         />
                     </div>
                    <button class="bg-primary px-4 font-medium py-3 rounded-lg text-white w-full" id="startTestBtn">
                      Start Test
                    </button>
                <div>
                `
        } else {
            return `<button class="btn-primary w-full" id="startTestBtn">
                        Start Test
                    </button>`
        }
    }
    return `
        <div class="flex items-center gap-3 fixed inset-0 h-fit z-[2] bg-white px-4 py-3 border-b">
        <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="history.back()">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
      </button>
        <div class="flex items-center gap-2 cursor-pointer"${test.testCreator.verified ? 'onclick="showVerifyInfo()"' : ''}>
                  <img 
                  src="${test.testCreator.profile}" 
                  class="w-8 h-8 rounded-full border" 
                  alt="creator"
                  />
        <span class="${test.testCreator.verified ? 'text-blue-600' : 'text-secondary'} text-lg font-medium">
             ${test.testCreator.username}
            </span>
        ${test.testCreator.verified
            ? '<svg stroke="currentColor" id="verifyIcon" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="text-blue-500 w-4 h-4" xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0z"></path><path d="M23 12l-2.44-2.79.34-3.69-3.61-.82-1.89-3.2L12 2.96 8.6 1.5 6.71 4.69 3.1 5.5l.34 3.7L1 12l2.44 2.79-.34 3.7 3.61.82L8.6 22.5l3.4-1.47 3.4 1.46 1.89-3.19 3.61-.82-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81 1.48-1.48 2.32 2.33 5.85-5.87 1.48 1.48-7.33 7.35z"></path></svg>'
            : ''
        }
</div>
       </div>
        <div class="p-6 pt-20">
            <h3 class="text-2xl font-semibold text-center mb-6">${test.title}</h3>
            <div class="bg-gray-50 rounded-2xl p-4 mb-6">
                <div class="grid grid-cols-2 gap-4">
                    <div class="flex flex-col justify-end items-center">
                        <div class="text-2xl font-bold text-primary">${test.totalQuestions}</div>
                        <div class="text-sm text-gray-500 font-medium">Questions</div>
                    </div>
                    <div class="flex flex-col justify-end items-center">
                        <div class="text-2xl font-bold text-primary">${test.duration}</div>
                        <div class="text-sm text-gray-500 font-medium">Minutes</div>
                    </div>
                    <div class="flex flex-col justify-end items-center">
                        <div class="text-2xl font-bold text-primary">${test.totalMarks}</div>
                        <div class="text-sm text-gray-500 font-medium">Marks</div>
                    </div>
                    <div class="flex flex-col justify-end items-center">
                        <div class="font-semibold text-sm ${test.entryType.toLowerCase() === "free" ? 'bg-green-100  text-green-700' : 'bg-orange-100 text-orange-700'} py-1 px-2 rounded-lg">${test.entryType.toUpperCase()}</div>
                        <div class="text-sm text-gray-500 font-medium">Entry Type</div>
                    </div>
                </div>
            </div>
            
            <div class="space-y-3">
          ${actionBtn()}
                <button class="btn-secondary w-full" onclick="navigate('/results/${testId}')">View Result</button>
            </div>
            <div class="mt-6 pt-6 border-t border-gray-300 font-medium">
                ${test.description?.replaceAll(/[\n\r]/g, "<br>") || `
                <h4 class="font-semibold mb-3">Test Instructions</h4>
                <ul class="text-sm text-gray-600 space-y-2">
                    <li>• Read each question carefully before answering</li>
                    <li>• You can navigate between questions freely</li>
                    <li>• Your progress is automatically saved</li>
                    <li>• Submit before time runs out to record your score</li>
                </ul>
                    `}
            </div>
        </div>
    `;
}

export async function init(params, box) {
    const testId = params.testId
    const test = APP_STATE.current_test_details
    delete APP_STATE.current_test_details
    const codeInput = document.getElementById("test_entryCode")
    document.getElementById('modalTopBar').classList.add('hidden')
    box.addEvent(document.getElementById("startTestBtn"), "click", async () => {
        if (test.entryType === "free") {
            const attempt_url = `/tests/${params.testId}/attempt?type=Resume&startTime=${Date.now()}`
            navigate(attempt_url)
        } else {
            const res = await fetchData(`/tests/${testId}/start-test-token`, 'post', { code: codeInput.value })
            if (!res || !res.success) {
                toast(res.message || "Something went wrong", "error");
                codeInput.value = ""
                return
            }
            const token = res.data.token
            const query = new URLSearchParams({
                type: "Resume",
                startTime: Date.now(),
                token
            })
            const attempt_url = `/tests/${params.testId}/attempt?${query.toString()}`
            navigate(attempt_url)
        }
    })
}