export async function Home(params) {
    let banners;
    if (!cache.has('banners')) {
        banners = await fetchData('/app/banners') || []
        cache.set("banners", banners, 30 * 60 * 1000)
    } else {
        banners = cache.get("banners")
    }
    return `
<div class="p-4">
    <div class="carousel-container aspect-video rounded-xl overflow-hidden relative" id="carousel">
        ${banners.map((slide, i) => `
            <div 
                class="carousel-slide w-full h-full ${i === 0 ? 'active' : ''} cursor-pointer relative group"
                data-index="${i}"
                data-action="${slide.actionUrl || ''}"
            >
                ${slide.contentType === "html"
            ? `
                    <div class="min-h-full flex items-center justify-center bg-gradient-to-br from-indigo-600 to-purple-600 text-white text-xl font-bold">
                        ${slide.html}
                    </div>`
            : `
                    <img src="${slide.imageUrl}" class="w-full object-cover h-full" loading="lazy"
                         alt="banner-${i}">
                    `
        }
            </div>
        `).join('')}
    </div>

    <div class="carousel-dots mt-3 flex justify-center gap-2">
        ${banners.map((_, i) => `
            <div class="carousel-dot ${i === 0 ? 'active' : ''}" data-index="${i}"></div>
        `).join('')}
    </div>

    <style>
        .carousel-slide {
            display: none;
        }
        .carousel-slide.active {
            display: block;
        }
        .carousel-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #cbd5e1;
            cursor: pointer;
        }
        .carousel-dot.active {
            background: #4f46e5;
            transform: scale(1.2);
        }
    </style>
</div>
<div class="p-4">
            <h2 class="font-bold text-gray-900 mb-5 text-lg mt-2">Quick Actions</h2>
            <div class="quick-actions">
                <div class="quick-action-card" onclick="navigate('/results?status=resume')">
                    <div class="quick-action-icon">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div class="quick-action-label">Resume Tests</div>
                </div>
                <div class="quick-action-card"  onclick="navigate('/create?create_box=true')">
                    <div class="quick-action-icon">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                    </div>
                    <div class="quick-action-label">Create Test</div>
                </div>
                <div class="quick-action-card" onclick="navigate('/results')">
                    <div class="quick-action-icon">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/>
                        </svg>
                    </div>
                    <div class="quick-action-label">Leaderboard</div>
                </div>
            </div>
        </div>
    `
}
export function init(_, box) {
    function initCarousel() {
        let currentIndex = 0;
        let slideInterval = null;
        const slides = document.querySelectorAll('.carousel-slide');
        const dots = document.querySelectorAll('.carousel-dot');
        function showSlide(index) {
            slides.forEach(s => s.classList.remove('active'));
            dots.forEach(d => d.classList.remove('active'));
            slides[index].classList.add('active');
            dots[index].classList.add('active');
            currentIndex = index;
        }
        function automateSlide() {
            if (slideInterval) return;
            slideInterval = box.setInterval(() => {
                currentIndex = (currentIndex + 1) % slides.length;
                showSlide(currentIndex);
            }, 3000);
        }
        dots.forEach((dot, i) => {
            box.addEvent(dot, 'click', () => {
                clearInterval(slideInterval);
                slideInterval = null;
                showSlide(i);
                automateSlide();
            });
        });
        slides.forEach(slide => {
            box.addEvent(slide, "click", () => {
                const path = slide.getAttribute("data-action");
                if (!path || path === "") return
                navigate(path);
            });
        });
        automateSlide();
    }
    initCarousel()
}