function formatDate(dateStr) {
    const date = new Date(dateStr);
    const now = new Date();
    const diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}
export async function ResultDetail(params) {
    const attempt = MOCK_DB.attempts.find(a => a.id === params.id);
    if (!attempt) {
        return '<div class="w-full h-full flex justify-center items-center text-red-900 text-xl font-semibold">Attempt Not Found</div>'
    }
    const test = MOCK_DB.tests.find(t => t.id === attempt.testId);
    return `
        <div class="p-6">
            <div class="text-center mb-6">
                <div class="text-6xl font-bold text-primary mb-2">${attempt.score}</div>
                <div class="text-gray-500">out of ${attempt.maxScore}</div>
                <div class="mt-4 inline-block px-4 py-2 bg-gray-100 rounded-lg">
                    Rank: <span class="font-bold">#${attempt.rank}</span>
                </div>
            </div>
            
            <div class="bg-gray-50 rounded-2xl p-4 mb-6">
                <h4 class="font-semibold mb-2">${test.title}</h4>
                <div class="text-sm text-gray-500">
                    Attempted on ${formatDate(attempt.date)}
                </div>
            </div>
            
            <div class="space-y-3">
                <div class="flex justify-between items-center p-3 bg-white rounded-lg">
                    <span class="text-gray-600">Percentage</span>
                    <span class="font-semibold">${Math.round((attempt.score / attempt.maxScore) * 100)}%</span>
                </div>
                <div class="flex justify-between items-center p-3 bg-white rounded-lg">
                    <span class="text-gray-600">Questions</span>
                    <span class="font-semibold">${test.questionCount}</span>
                </div>
                <div class="flex justify-between items-center p-3 bg-white rounded-lg">
                    <span class="text-gray-600">Duration</span>
                    <span class="font-semibold">${test.duration} min</span>
                </div>
            </div>
            
            <button class="btn-primary w-full mt-6" onclick="navigate('/results')">Back to Results</button>
        </div>
    `;
}
