export async function Questions(params) {
  const test_title = new URLSearchParams(location.search).get('test_title') || params.testId
  return `
  <div class="bg-white min-h-screen pb-24 pt-[10rem]">
    <div class="w-full fixed inset-0 h-fit z-[2]">
    <div class="flex items-center gap-3 w-full bg-white px-4 py-3 border-b">
        <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="navigate('/tests/${params.testId}/dashboard')">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
      </button>
        <div class="flex-1">
          <div class="font-semibold text-secondary text-lg">Questions</div>
          <div class="text-sm line-clamp-1 pr-2 text-gray-500">${test_title}</div>
        </div> 
      <button id="add_question_btn" class="bg-primary text-white px-3 py-2 rounded-lg flex items-center gap-1">
        <svg class="w-5 h-5 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg> Add
      </button>
      </div>
       <button class="btn-primary fixed bottom-12 shadow-xl shadow-gray-400/80 right-4 mt-4 px-4 py-3 text-sm" id="preview_qs">Preview All Questions</button>
      <div class="px-5 py-4 bg-white border-b pb-4">
           <div class="filter-chips">
                <div class="filter-chip questions_type_filter flex items-center gap-1" data-filter="all">All<span></span></div>
                <div class="filter-chip questions_type_filter flex items-center gap-1" data-filter="mcq">MCQ's<span></span></div>
                <div class="filter-chip questions_type_filter flex items-center gap-1" data-filter="numeric">Numerics<span></span></div>
            </div>
             </div>
      </div>
    <!-- QUESTION LIST -->
    <div id="questions_list" class="space-y-3">
        <div class="text-center mt-48">
                <div class="inline-block animate-spin rounded-full h-12 w-12 loader"></div>
            </div>
    </div>

  </div>
  `
}

export async function init(params, box) {
  document.getElementById('modalTopBar').classList.add('hidden')
  const questionsList = document.getElementById('questions_list')
  const testId = params.testId
  let currentFilter = 'all'
  let questions = null
  if (!cache.has('test_' + testId + '_q')) {
    let resp = await fetchData(`/my-tests/${testId}/questions`)
    if (!resp || !resp.success) { toast(resp?.message || "Failed to load questions", 'error'); history.back(); return }
    cache.set(`test_${testId}_q`, resp.data, 15 * 60 * 1000)
    questions = resp.data
  } else {
    questions = cache.get('test_' + testId + '_q')
  }
  window.questions = questions
  function setFilterTab() {
    const query = new URLSearchParams(location.search)
    currentFilter = query.get('q_type') || ""
    const validTypes = ['all', 'mcq', 'numeric']
    if (!validTypes.includes(currentFilter.toLowerCase())) { currentFilter = "all" }
    document.querySelector(`.questions_type_filter[data-filter=${currentFilter.toLowerCase()}]`).classList.add('active')
    const filterChips = document.querySelectorAll('.questions_type_filter')
    filterChips.forEach((chip, i) => {
      let q_count_span = chip.querySelector('span')
      q_count_span.innerText = i === 0 ? getSortedQuestions().length : (i === 1 ? getSortedQuestions().filter(q => q.type === 'mcq').length : getSortedQuestions().filter(q => q.type !== 'mcq').length)
      box.addEvent(chip, 'click', () => {
        filterChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        if (currentFilter == chip.dataset.filter) return
        currentFilter = chip.dataset.filter
        query.set('q_type', currentFilter)
        history.replaceState({}, "", "?" + query.toString())
        renderQuestions()
      })
    })
  }
  setFilterTab()
  renderQuestions()
  document.getElementById('add_question_btn').onclick = async () => {
    let last_q_format = null
    try {
      last_q_format = JSON.parse(localStorage.getItem('last_question_format') || '{}')
    } catch { last_q_format = {} }
    const newQuestionPayload = {
      type: last_q_format.type,
      text: "Q" + (Object.keys(questions).length + 1),
      positiveMarks: last_q_format.positiveMarks,
      negativeMarks: last_q_format.negativeMarks
    }
    const resp = await fetchData(`/my-tests/${testId}/questions/add-new`, "post", newQuestionPayload)
    if (!resp || !resp.success) { toast(resp?.message || "Failed to add new questions", 'error'); return }
    const { _id, ...new_qe } = resp.data
    const new_q_index = Object.keys(questions).length
    questions[_id] = { index: new_q_index, ...new_qe }
    cache.set(`test_${testId}_q`, questions, 15 * 60 * 1000)
    setTimeout(() => {
      navigate(`/tests/${testId}/questions/${_id}/edit`)
    }, 300)
  }
  function renderQuestions() {
    const sorted = getSortedQuestions()
    if (sorted.length === 0) {
      questionsList.innerHTML = `
      <div class="empty-state">
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                        </path>
                        </svg>
                     <h3>No Questions Yet.</h3>
                   <p class="text-secondary">Tap <strong>+ Add</strong> to add new question.</p>
                    </div>
                    `
      return
    }
    const filteredQuestions = currentFilter === 'all'
      ? sorted
      : sorted.filter(q => q.type.toLowerCase() === currentFilter.toLowerCase())
    if (filteredQuestions.length === 0) {
      questionsList.innerHTML = `
            <div class="empty-state">
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                        </path>
                        </svg>
                   <p class="text-secondary">There is no any <strong>${currentFilter.toUpperCase()}</strong> questions.</p>
                    </div>
        `
      return
    }
    questionsList.innerHTML = filteredQuestions.map(q => `
  <div class="bg-white pt-1 pb-3 px-5 border-b-2" data-id="${q.id}">
      <div class="bg-white space-y-3">
            <div class="flex items-center gap-2">
                <div class="text-center text-sm font-semibold w-6 h-6 bg-gray-700 text-[#fbfbfb] rounded-full">${q.index + 1}</div>
                <div class="text-sm px-2 py-1 text-gray-700 border rounded-lg">Marks: <span class="font-semibold text-green-600">${"+" + q.positiveMarks}</span><span class="text-red-600 ml-1 font-semibold">${q.negativeMarks === 0 ? q.negativeMarks : "-" + q.negativeMarks}</span></div>
                <div class="text-sm px-2 py-1 text-gray-700 border rounded-lg">Type: ${q.type === "mcq" ? "MCQ" : "Numeric"}</div>
                <div class="flex-1 flex justify-end">
                <svg onclick="navigate('/tests/${testId}/questions/${q.id}/edit${location.search}')" class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path d="M14.0514 3.73889L15.4576 2.33265C16.0678 1.72245 17.0572 1.72245 17.6674 2.33265C18.2775 2.94284 18.2775 3.93216 17.6674 4.54235L8.81849 13.3912C8.37792 13.8318 7.83453 14.1556 7.23741 14.3335L5 15L5.66648 12.7626C5.84435 12.1655 6.1682 11.6221 6.60877 11.1815L14.0514 3.73889ZM14.0514 3.73889L16.25 5.93749M15 11.6667V15.625C15 16.6605 14.1605 17.5 13.125 17.5H4.375C3.33947 17.5 2.5 16.6605 2.5 15.625V6.87499C2.5 5.83946 3.33947 4.99999 4.375 4.99999H8.33333" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
                </div>
            </div>
            <div>
                <div class="text-secondary text-sm">${q.text.replace(/\r?\n/g, "<br>")}</div>
                ${q.image?.hasImage ?
        `<div class="relative rounded-md overflow-hidden">
                     <img src='${q.image.imageUrl}' class="w-full aspect-video object-cover" alt="Question_Image" loading="lazy">
                     <span onclick="fullScreenImage('${q.image.imageUrl}')" class="absolute bottom-2 right-2 p-2 w-8 h-8 rounded-md bg-white/40 text-gray-800">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M32 32C14.3 32 0 46.3 0 64l0 96c0 17.7 14.3 32 32 32s32-14.3 32-32l0-64 64 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 32zM64 352c0-17.7-14.3-32-32-32S0 334.3 0 352l0 96c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0 0-64zM320 32c-17.7 0-32 14.3-32 32s14.3 32 32 32l64 0 0 64c0 17.7 14.3 32 32 32s32-14.3 32-32l0-96c0-17.7-14.3-32-32-32l-96 0zM448 352c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 64-64 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l96 0c17.7 0 32-14.3 32-32l0-96z"/></svg>
                     </span>
            </div>
                `: ""}
            </div>
        </div>
    </div>
    `).join('')
  }
  box.addEvent(document.getElementById("preview_qs"), "click", () => {
    const html = `
               <div class="w-full fixed inset-0 h-fit z-[2]">
     <div class="flex items-center gap-3 w-full bg-white px-4 py-5 border-b">
        <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="display.close()">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
      </button>
        <h3 class="font-semibold text-secondary text-lg">Questions Preview</h3>
      </div>
      </div>
          <div class="bg-white pt-20 pb-12 space-y-3 overflow-y-auto h-full w-full">
           ${getSortedQuestions().map(q => `
    <div class="bg-white pt-1 pb-3 px-5 border-b-2" data-id="${q.id}">
      <div class="bg-white space-y-3">
            <div class="flex items-center gap-2">
                <div class="text-center text-sm font-semibold w-6 h-6 bg-gray-700 text-[#fbfbfb] rounded-full">${q.index + 1}</div>
                <div class="text-sm px-2 py-1 text-gray-700 border rounded-lg">Marks: <span class="font-semibold text-green-600">${"+" + q.positiveMarks}</span><span class="text-red-600 ml-1 font-semibold">${q.negativeMarks === 0 ? q.negativeMarks : "-" + q.negativeMarks}</span></div>
                <div class="text-sm px-2 py-1 text-gray-700 border rounded-lg">Type: ${q.type === "mcq" ? "MCQ" : "Numeric"}</div>
                <div class="text-sm px-2 py-1 text-gray-700 border rounded-lg font-medium" onclick="navigate('/tests/${testId}/questions/${q.id}/edit${location.search}')" >Edit</div>
            </div>
            <div class="space-y-1">
                <div class="text-secondary text-sm">${q.text.replace(/\r?\n/g, "<br>")}</div>
                ${q.image?.hasImage ?
       `<div class="relative rounded-md overflow-hidden">
                     <img src='${q.image.imageUrl}' class="w-full aspect-video object-cover" alt="Question_Image" loading="lazy">
                     <span onclick="fullScreenImage('${q.image.imageUrl}')" class="absolute bottom-2 right-2 p-2 w-8 h-8 rounded-md bg-white/40 text-gray-800">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M32 32C14.3 32 0 46.3 0 64l0 96c0 17.7 14.3 32 32 32s32-14.3 32-32l0-64 64 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 32zM64 352c0-17.7-14.3-32-32-32S0 334.3 0 352l0 96c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0 0-64zM320 32c-17.7 0-32 14.3-32 32s14.3 32 32 32l64 0 0 64c0 17.7 14.3 32 32 32s32-14.3 32-32l0-96c0-17.7-14.3-32-32-32l-96 0zM448 352c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 64-64 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l96 0c17.7 0 32-14.3 32-32l0-96z"/></svg>
                     </span>
            </div>
                `: ""}
                <div>
                ${q.type === "mcq" ? `
                ${q.options.map((o, i) => `
                  ${o ? `
                  <div ${q.answer == i ? 'class="text-green-600 font-medium"' : ""}>(${String.fromCharCode(65 + i)}) ${o.replace(/\r?\n/g, "<br>")}</div>
                  `: ""}`).join("")}` : `<div class="text-green-600 font-medium">Answer: ${q.answer}</div>`}
                </div>
                <div>
                <h4 class="font-medium">Explanation: </h4>
                <p class="text-secondary text-sm">${q.explanation.replace(/\r?\n/g, "<br>")}</p>
                </div>
            </div>
        </div>
    </div>
    `).join('')}
        <p class="text-red-600 text-center w-full font-medium">${'-'.repeat(10)} ${getSortedQuestions().length ? "End of Questions" : "No Questions Yet"} ${'-'.repeat(10)}</p>
        </div>
    `
    display.open(html)
  })

  function getSortedQuestions() {
    return Object.entries(questions).map(([id, q]) => ({ id: id, ...q })).sort((a, b) => a.index - b.index)
  }
  //     Full Image System
  function fullScreenImage(image) {
    display.open(`
            <div class="relative p-4 flex items-center justify-center w-full h-full" style="touch-action:pinch-zoom;">
            <div class="absolute top-6 right-4 w-10 h-10 p-2 flex items-center justify-center bg-white/50 rounded-full" onclick="display.close()">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M55.1 73.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L147.2 256 9.9 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192.5 301.3 329.9 438.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.8 256 375.1 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192.5 210.7 55.1 73.4z"/></svg>
            </div>
            <img src="${image}" class="rounded-lg" alt="Question_Image_ERR_NOT_LOAD">
            </div>
            `)
  }
  box.var("fullScreenImage", fullScreenImage)
}
