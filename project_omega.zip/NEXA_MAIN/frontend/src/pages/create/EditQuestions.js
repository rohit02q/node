export async function EditQuestions(params) {
  const testId = params.testId
  const qId = params.qId
  return `
    <div class="px-5 bg-white min-h-full pb-28 pt-20">
      <div class="flex items-center gap-3 fixed inset-0 h-fit z-[2] bg-white px-4 py-3 border-b">
        <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="navigate('/tests/${testId}/questions${location.search}')">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
      </button>
        <div class="flex-1">
          <div class="font-semibold text-secondary">Edit Question</div>
          <div class="text-sm text-gray-500">${qId}</div>
        </div>
        <button id="qe_save_btn" class="btn-primary py-2 px-4">Save</button>
      
      </div>
      <div id="qe_wrap" class="space-y-4 bg-white">
        <div>
          <label class="text-sm font-medium text-secondary">Question Text</label>
            <textarea
             id="qe_text"
             type="text"
             class="hideScroll w-full mt-1 p-3 border rounded-lg outline-none focus:border-primary"
             placeholder="Type or paste your question here..." 
             autocomplete="off"
             rows="6"
             spellcheck = "false" 
             ></textarea>
        </div>
        <div class="w-full aspect-video border-2 border-dashed border-gray-400 rounded-lg flex flex-col items-center justify-center">
       <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-20 h-20 text-gray-500/50"><path fill="currentColor" d="M64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zm64 80a48 48 0 1 1 0 96 48 48 0 1 1 0-96zM272 224c8.4 0 16.1 4.4 20.5 11.5l88 144c4.5 7.4 4.7 16.7 .5 24.3S368.7 416 360 416L88 416c-8.9 0-17.2-5-21.3-12.9s-3.5-17.5 1.6-24.8l56-80c4.5-6.4 11.8-10.2 19.7-10.2s15.2 3.8 19.7 10.2l26.4 37.8 61.4-100.5c4.4-7.1 12.1-11.5 20.5-11.5z"/></svg>
       <p class="text-sm font-medium text-primary/80" id="upload_img">Upload Question Image</p>
       </div>
        <div>
    <label class="text-sm text-secondary font-medium">Question Type</label>
    <div
      id="qe_type_selector"
      class="mt-1 flex justify-between items-center border rounded-xl px-4 py-3 cursor-pointer hover:bg-gray-50"
    >
    <input type="hidden" id="qe_type">
      <span class="font-medium text-secondary" id="qe_type_view">MCQ</span>
      <svg class="w-4 h-4 rotate-[90deg]" fill="black" viewBox="0 0 24 24">
        <path
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="2"
          d="M9 5l7 7-7 7 Z"
        />
      </svg>
    </div>
          </div>
        <div id="qe_options_wrap" class="mt-2">
          <div class="text-sm font-medium">Options</div>
          <div id="qe_options" class="mt-2 space-y-2"></div>
            <div class="flex gap-2 mt-2">
            <button id="qe_add_opt" class="flex-1 py-2 rounded-lg border">Add option</button>
            <button id="qe_remove_opt" class="flex-1 py-2 rounded-lg border">Remove</button>
          </div>
          <div class="w-full mt-4">
          <div class="text-sm font-medium text-green-600">Mark Correct Option</div>
          <div class="grid grid-cols-4 text-center gap-x-2 gap-y-3 mt-3" id="correct_opt_box"></div>
          </div>
          </div>
          <div class="w-full pt-2 hidden" id="input_container">
          <div class="w-full h-[3rem] border rounded-sm relative border-green-600">
                   <label class="bg-white absolute top-[-12px] left-[20px] font-semibold text-sm text-green-600">Correct
                    Answer</label>
                <input id="qe_answer" placeholder="Type correct answer..." autocomplete="off" spellcheck = "false" type="number" class="text-secondary font-semibold bg-transparent w-full h-full px-4 focus:outline-none">
            </div>
            </div>
          <div class="grid grid-cols-2 gap-2 mt-3">
          <div class="space-y-1.5">
          <label class="text-sm text-green-600 font-medium">Positive Marks</label>
          <input id="qe_marks_pos"
           type="number"
           class="w-full mt-1 p-3 border rounded-lg outline-none focus:border-primary"
           autocomplete="off"
           spellcheck = "false"
           placeholder="eg. 4"/>
          </div>
          <div class="space-y-1.5">
          <label class="text-sm font-medium text-red-600">Negative Marks</label>
          <input id="qe_marks_neg"
          type="number"
          class="w-full mt-1 p-3 border rounded-lg outline-none focus:border-primary"
          autocomplete="off"
          spellcheck = "false"
          placeholder="eg. -1"/>
        </div>
        </div>
        <div>
          <label class="text-sm font-medium text-secondary">Solution Explanation</label>
            <textarea id="qe_expl" type="text" class="hideScroll w-full mt-1 p-3 border rounded-lg outline-none focus:border-primary" placeholder="Explain Solution (Optional) ..." autocomplete="off" rows="6" spellcheck="false"></textarea>
        </div>
          <button id="qe_delete_btn" class="w-full py-3 rounded-lg border-2 border-red-600 bg-red-50/50 font-medium text-red-600">Delete</button>
      </div>
    </div>
  `
}

export async function init(params, box) {
  const testId = params.testId
  const qId = params.qId
  let lastMarkedOpt = null
  let question = null
  let lastSavedPayload = null
  const getEle = (id) => document.getElementById(id)
  getEle('modalTopBar').classList.add('hidden')
  const textEl = getEle('qe_text')
  const typeEl = getEle('qe_type')
  const qeTypeBtn = getEle("qe_type_selector")
  const qeTypeView = getEle("qe_type_view")
  const ansEl = getEle('qe_answer')
  const optionsWrap = getEle('qe_options_wrap')
  const optionsList = getEle('qe_options')
  const correctOptBox = getEle('correct_opt_box')
  const saveBtn = getEle('qe_save_btn')
  const saveBottom = getEle('qe_save_bottom')
  const addOpt = getEle('qe_add_opt')
  const removeOpt = getEle('qe_remove_opt')
  const deleteBtn = getEle('qe_delete_btn')
  const posMarks = getEle('qe_marks_pos')
  const negMarks = getEle('qe_marks_neg')
  const qeExpl = getEle('qe_expl')
  box.addEvent(qeTypeBtn, "click", () => {
    const html = `
    <div class="py-4 border-b">
      <h3 class="text-lg font-semibold text-secondary">Select Question Type</h3>
    </div>
    <label class="flex items-center justify-between p-3 cursor-pointer border-b hover:bg-gray-50">
      <span>MCQ</span>
      <input type="radio" name="q_type" value="MCQ" class="accent-primary form-radio h-4 w-4" />
    </label>
    <label class="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50">
      <span>Numeric</span>
      <input type="radio" name="q_type" value="Numeric" class="accent-primary form-radio h-4 w-4" />
    </label>
  `
    openDrawer(html)
    box.setTimeout(() => {
      const radios = document.querySelectorAll('[name="q_type"]')
      radios.forEach(radio => {
        if (radio.value.toLowerCase() === typeEl.value) {
          radio.checked = true
        }
        box.addEvent(radio, "change", () => {
          const val = radio.value
          const val_lower = val.toLowerCase()
          qeTypeView.innerText = val
          typeEl.value = val_lower
          if (val_lower === "numeric") {
            optionsWrap.classList.add("hidden")
            getEle("input_container").classList.remove("hidden")
          } else {
            getEle("input_container").classList.add("hidden")
            optionsWrap.classList.remove("hidden")
          }
          closeDrawer()
        })
      })
    }, 50)
  })
  async function fetchQuestions() {
    let resp = await fetchData(`/my-tests/${testId}/questions`)
    if (!resp || !resp.success) { toast(resp?.message || "Failed to load questions", 'error'); history.back(); return }
    cache.set(`test_${testId}_q`, resp.data, 15 * 60 * 1000)
    question = resp.data[qId] || []
  }
  if (!cache.has('test_' + testId + '_q')) {
    await fetchQuestions()
  } else {
    question = cache.get(`test_${testId}_q`)[qId] || []
    if (question.length === 0) await fetchQuestions()
  }
  if (question.length === 0) {
    toast('Question not found', 'error');
    navigate(`/tests/${testId}/questions`)
    return
  }
  function renderOptions(opts, type = 'mcq') {
    if (type === 'numeric') {
      optionsWrap.classList.add('hidden')
      getEle("input_container").classList.remove("hidden")
      return
    }
    opts = opts.length ? opts : ['', '', '', '']
    optionsList.innerHTML = opts.map((o, idx) => `
       <div>
            <textarea
            data-idx="${idx}"
             type="text"
             class="hideScroll w-full mt-1 p-3 border rounded-lg outline-none focus:border-primary"
             placeholder="Option ${idx + 1}"
             autocomplete="off"
             rows="2"
             spellcheck = "false" 
             >${o}</textarea>
        </div>
    `).join('')
    correctOptBox.innerHTML = opts.map((_, idx) => `
    <span data-idx="${idx}" class="py-2 rounded-xl font-medium border ${lastMarkedOpt === idx ? "border-green-600 bg-green-50 correct_opt" : ""}">${String.fromCharCode(65 + idx)}</span>
    `).join('')
  }
  function getPayload() {
    const type = typeEl.value
    const text = textEl.value.trim()
    const pos = parseInt(posMarks.value) || 0
    const neg = parseInt(negMarks.value) * Math.sign(negMarks.value) || 0
    let options = []
    let answer;
    if (type === 'mcq') {
      const opts = optionsWrap.querySelectorAll('textarea[data-idx]')
      options = Array.from(opts).map(i => i.value.trim())
      answer = Number(correctOptBox.querySelector(".correct_opt")?.dataset.idx) ?? undefined
    } else {
      answer = Number(ansEl.value.trim()) ?? undefined
    }
    if (isNaN(answer)) answer = undefined
    const explanation = qe_expl.value.trim()
    const payload = {
      type, text, positiveMarks: pos, negativeMarks: neg, options, answer, explanation
    }
    return payload
  }
  function initAll() {
    textEl.value = question.text || ''
    qe_type_view.innerText = question.type === "mcq" ? "MCQ" : "Numeric"
    typeEl.value = question.type || 'mcq'
    ansEl.value = question.type === 'numeric' ? question.answer ?? '' : ''
    posMarks.value = question.positiveMarks ?? ""
    negMarks.value = question.negativeMarks ?? ""
    qeExpl.value = question.explanation || ""
    lastMarkedOpt = question.answer
    renderOptions(question.options || [], question.type)
    lastSavedPayload = getPayload()
    box.addEvent(addOpt, 'click', () => {
      const inputs = optionsWrap.querySelectorAll('textarea[data-idx]')
      if (inputs.length >= 10) return toast('Maximum ten options allowed')
      const vals = Array.from(inputs).map(i => i.value)
      vals.push('')
      renderOptions(vals, 'mcq')
    })
    box.addEvent(removeOpt, 'click', () => {
      const inputs = optionsWrap.querySelectorAll('textarea[data-idx]')
      if (inputs.length <= 1) return toast('Need at least one option')
        const vals = Array.from(inputs).map(i => i.value)
      vals.pop()
      renderOptions(vals, 'mcq')
    })
    box.addEvent(getEle("upload_img"), "click", () => {
      toast("Comming Soon.")
    })
    box.addEvent(correctOptBox, "click", (e) => {
      if (e.target.tagName !== "SPAN") return
      const all_opts_span = correctOptBox.querySelectorAll("SPAN")
      all_opts_span.forEach((o, i) => {
        o.className = "py-2 rounded-xl font-medium border"
        if (o === e.target)
          lastMarkedOpt = i
        e.target.className = "py-2 rounded-xl font-medium border bg-green-50 border-green-600 correct_opt"
      })
    })
    box.addEvent(saveBtn, 'click', () => { saveQuestion(false) })
    box.addEvent(deleteBtn, 'click', deleteQ)
  }
  async function deleteQ() {
    popUp.show(`
          <div class="flex flex-col items-center">
         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" class="w-24 h-24 text-red-600"><path fill="currentColor" d="M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 550.1 544 536 544L104 544C89.9 544 76.8 536.6 69.6 524.5C62.4 512.4 62.1 497.4 68.8 485L284.8 85C291.8 72.1 305.3 64 320 64zM320 416C302.3 416 288 430.3 288 448C288 465.7 302.3 480 320 480C337.7 480 352 465.7 352 448C352 430.3 337.7 416 320 416zM320 224C301.8 224 287.3 239.5 288.6 257.7L296 361.7C296.9 374.2 307.4 384 319.9 384C332.5 384 342.9 374.3 343.8 361.7L351.2 257.7C352.5 239.5 338.1 224 319.8 224z"/></svg>
           <h3 class="text-xl font-semibold pb-2">Delete Question</h3>
<p class="text-center">
Are you sure you want to delete question you can\'t recover this again
 </p>
 <div class="flex w-full mt-6 gap-3">
     <button class="flex-1 py-3 rounded-lg border-2 border-black bg-gray-50 font-medium" onclick="popUp.hide()">Cancel</button>
     <button id="delete_qe" class="flex-1 py-3 rounded-lg border-2 border-red-600 bg-red-50/50 font-medium text-red-600">Delete</button>
        </div>
      `)
    setTimeout(() => {
      box.addEvent(document.getElementById("delete_qe"), "click", async () => {
        const resp = await fetchData(`/my-tests/${testId}/questions/${qId}/delete`, "DELETE", {})
        if (!resp || !resp.success) { toast("Failed to delete question", "error"); popUp.hide(); return; }
        popUp.hide()
        const allQuestions = cache.get(`test_${testId}_q`)
        delete allQuestions[qId]
        cache.set(`test_${testId}_q`, allQuestions, 15 * 60 * 1000)
        toast("Question Deleted", "success");
        navigate(`/tests/${testId}/questions${location.search}`)
      })
    }, 80)
  }
  function deepEqual(a, b) {
    if (a === b) return true
    if (typeof a !== "object" || typeof b !== "object" || !a || !b)
      return false
    const aKeys = Object.keys(a)
    const bKeys = Object.keys(b)
    if (aKeys.length !== bKeys.length) return false
    for (let k of aKeys) {
      if (!bKeys.includes(k)) return false
      if (!deepEqual(a[k], b[k])) return false
    }
    return true
  }
  async function saveQuestion(auto = true) {
    const payload = getPayload()
    if (deepEqual(payload, lastSavedPayload)) {
      if (!auto) toast('Edits saved', 'success'); return
    }
    const resp = await fetchData(`/my-tests/${testId}/questions/${qId}/edit`, "post", payload)
    if (!resp || !resp.success) { if (!auto) { toast(resp?.message || 'Failed to edit question', 'error') }; return; }
    localStorage.setItem("last_question_format", JSON.stringify({
      type: payload.type, positiveMarks: payload.positiveMarks, negativeMarks: payload.negativeMarks
    }))
    const allQuestions = cache.get(`test_${testId}_q`)
    allQuestions[qId] = { ...allQuestions[qId], ...payload }
    cache.set(`test_${testId}_q`, allQuestions, 15 * 60 * 1000)
    cache.delete('myAllTests')
    lastSavedPayload = { ...payload }
    if (!auto) toast('Edits saved', 'success')
  }
  initAll()
  box.addEvent(window, 'beforeunload', saveQuestion)
  box.addEvent(window, 'app_page_change', saveQuestion)
}
