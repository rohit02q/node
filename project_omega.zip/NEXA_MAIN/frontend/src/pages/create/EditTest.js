export async function EditTest(params) {
  const id = params.testId
  function toggleBtn(id, checked = false) {
    return `<div class="relative inline-flex items-center ${id}_toggle_btn">
        <input type="checkbox" class="sr-only peer" id="${id}" ${checked ? 'checked' : ''}>
          <label for="${id}" class="cursor-pointer w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary">
          </label>
      </div>`
  }
  function settingsInfoIcon(key) {
    return `<div class="w-6 h-6 p-1 border-2 flex items-center justify-center rounded-full">
          <svg xmlns="http://www.w3.org/2000/svg" test_setting_info_key="${key}"  class="cursor-pointer text-secondary/80 rounded-full w-4 h-3" viewBox="0 0 320 512">
          <path fill="currentColor" d="M64 160c0-53 43-96 96-96s96 43 96 96c0 42.7-27.9 78.9-66.5 91.4-28.4 9.2-61.5 35.3-61.5 76.6l0 24c0 17.7 14.3 32 32 32s32-14.3 32-32l0-24c0-1.7 .6-4.1 3.5-7.3 3-3.3 7.9-6.5 13.7-8.4 64.3-20.7 110.8-81 110.8-152.3 0-88.4-71.6-160-160-160S0 71.6 0 160c0 17.7 14.3 32 32 32s32-14.3 32-32zm96 352c22.1 0 40-17.9 40-40s-17.9-40-40-40-40 17.9-40 40 17.9 40 40 40z"/></svg></div>`
  }
  return `
    <div class="min-h-fit overflow-y-auto pb-4 bg-gray-50">
      <div class="flex items-center gap-3 fixed inset-0 h-fit z-[2] bg-white px-4 py-3 border-b">
        <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="navigate('/tests/${id}/dashboard')">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
      </button>
      <div class="flex-1">
      <div class="font-semibold text-secondary">Edit Test</div>
        </div>
        <button id="save_top_btn" class="btn-primary py-2 px-4">Save</button>
      </div>
      <div class="pt-16 space-y-4">
        <!-- META -->
<div class="bg-white p-5 shadow space-y-4">
    <div>
      <div class="font-semibold text-secondary text-xl">Test Meta</div>
      <div class="w-10 h-1 bg-primary mt-1 rounded-full"></div>
    </div>
    <div>
    <label class="text-sm text-gray-600 font-medium">Test Title</label>
    <textarea
      id="meta_title"
      type="text"
      class="hideScroll w-full mt-1 p-3 border rounded-lg outline-none focus:border-primary"
      placeholder="Enter test title" 
      autocomplete="off"
      spellcheck = "false" 
    ></textarea>
  </div>
    <div>
    <label class="text-sm text-gray-600 font-medium">Description</label>
    <textarea
      id="meta_description"
      type="text"
      class="hideScroll w-full mt-1 p-3 border rounded-lg outline-none focus:border-primary"
      placeholder="Write about your test (optinal)..." 
      rows="4"
      autocomplete="off"
      spellcheck = "false" 
    ></textarea>
  </div>
  <div>
    <label class="text-sm text-gray-600 font-medium">Test Duration (In minutes)</label>
    <input
      id="meta_duration"
      type="number"
      class="w-full mt-1 p-3 border rounded-lg outline-none focus:border-primary"
      placeholder="eg. 120 for 2hrs"
      autocomplete="off"
      spellcheck = "false"
    >
  </div>
  <div>
    <label class="text-sm text-gray-600 font-medium">Entry Type</label>
    <div
      id="entry_type_selector"
      class="mt-1 flex justify-between items-center border rounded-xl px-4 py-3 cursor-pointer hover:bg-gray-50"
    >
      <span class="font-medium text-secondary" id="entry_type_view">FREE</span>
      <svg class="w-4 h-4 rotate-[90deg]" fill="black" viewBox="0 0 24 24">
        <path
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="2"
          d="M9 5l7 7-7 7 Z"
        />
      </svg>
    </div>
  </div>
  <div id="entry_code_wrap" class="hidden">
    <label class="text-sm text-gray-600">Entry Code</label>
    <input
      id="meta_entryCode"
      class="w-full mt-1 px-3 py-3 border rounded-xl outline-none focus:border-primary"
      placeholder="Enter entry code"
      autocomplete="off"
      spellcheck = "false" 
    />
  </div>
</div>
<input type="hidden" id="meta_entryType">
    <!-- SETTINGS -->
  <div class="bg-white p-5 shadow space-y-5">
  <div>
    <div class="font-semibold text-secondary text-xl">Settings</div>
    <div class="text-sm text-gray-500">Control result & attempt behavior</div>
    <div class="w-10 h-1 bg-primary mt-2 rounded-full"></div>
  </div>
  
  <!-- Shuffle -->
  <div class="flex items-center gap-2 border-b pb-4">
  ${settingsInfoIcon("shuffle")} 
  <label class="flex-1 flex items-center justify-between">
      <div>
        <span class="font-medium">Shuffle Questions</span>
      </div>
      ${toggleBtn('s_shuffle')}
    </label>
  </div>
  <!-- Hide Result -->
  <div class="flex items-center gap-2 border-b pb-4">
   ${settingsInfoIcon("hideResult")}  <label class="flex flex-1 items-center justify-between">
      <div>
        <span class="font-medium">Hide Result</span>
      </div>
      ${toggleBtn('s_resultHidden')}
    </label>
  </div>
  <!-- Solutions -->
  <div class="flex items-center gap-2 border-b pb-4">
 ${settingsInfoIcon("solutions")}<label class="flex-1 flex items-center justify-between">
      <div>
      <span class="font-medium">Hide Solutions</span>
      </div>
      ${toggleBtn('s_solutions')}
    </label>
  </div>
    <!-- Reattempt -->
  <div class="flex items-center gap-2 border-b pb-4">
 ${settingsInfoIcon("reattempt")}    <label class="flex-1 flex items-center justify-between">
      <div>
        <span class="font-medium">Stop Reattempt</span>
      </div>
      ${toggleBtn('s_reattempt')}
    </label>
  </div>
  </div>
        <!-- ADVANCED -->
        <div class="bg-white p-5 shadow">
         <div class="space-y-2">
            <div>
              <div class="font-semibold text-secondary text-xl">Advanced</div>
              <div class="text-sm text-gray-500">Focus guard & blocked users</div>
            </div>
             <div class="w-10 h-1 bg-primary mb-6 rounded-full"></div>
          </div>
          <div class="mt-4">
          <div class="flex items-center gap-2 border-b pb-4">
${settingsInfoIcon("focusGuard")}   <label class="flex-1 flex items-center justify-between">
    <div>
      <span class="font-medium">Focus Guard</span>
    </div>
    ${toggleBtn('fg_enabled')}
  </label>
</div>
            <div id="fg_controls" class="pl-3 border-l-4 border-l-primary/50 mt-2 hidden pb-4 space-y-6">
             <div>
    <label class="texsecondary font-medium">Max Tab Switch</label>
    <input id="fg_maxTabs" type="number" class="w-full mt-1 px-3 py-3 border rounded-lg outline-none focus:border-primary" placeholder="eg. 5" autocomplete="off" spellcheck="false">
<p class="text-sm text-gray-700 mt-1">This is number of chance or warning. If user switch tab or minimize app more than entered number then test is auto submitted.</p>
    </div>
            <div>
    <label class="text-secondary font-medium">Max Away Time (In minutes)</label>
    <input id="fg_maxAway" type="number" class="w-full mt-1 px-3 py-3 border rounded-lg outline-none focus:border-primary" placeholder="Max away time" autocomplete="off" spellcheck="false">
    <p class="text-sm text-gray-700 mt-1">If User away from test (Minimize app or switch tab) more than entered time then test is auto submitted howeever user switch tab just one time. it's not on max tab switch.</p>
    </div>
         </div>
            <div class="flex items-center gap-2 pb-4 mt-6">
${settingsInfoIcon("blockedUsers")}   <label class="flex-1 flex items-center justify-between">
    <div>
      <span class="font-medium">Blocked Users</span>
    </div>
  </label>
</div>
<div class="min-h-24 flex flex-col border rounded-lg">
<div class="flex py-2 px-3">
  <input
      id="block_user_input"
      type="text"
      class="flex-1 bg-transparent outline-none pr-1 placeholder-gray-400 font-medium"
      placeholder="Enter Username" 
      autocomplete="off"
      spellcheck = "false" 
      >
      <button id="block_user_btn" class="text-white rounded-lg px-3 py-1 bg-red-600/90 font-medium" >Add</button>
</div>
<div class="flex-1 flex flex-wrap gap-3 p-3" id="blocked_users_list"></div>
</div>
        </div>
      </div>
      </div>
    </div>
    <div class="w-full space-y-4 p-5 bg-white shadow">
    <button id="visibility_btn" class="py-3 w-full rounded-lg bg-blue-50/50 text-blue-600 border border-blue-600 font-medium">Change Visibility</button>
      <button id="delete_test_btn" class="w-full py-3 rounded-lg bg-red-50/50 border-red-600 border text-red-600 font-medium">Delete Test</button>
    </div>
  `
}
export function init(params, box) {
  const getEle = (id) => document.getElementById(id)
  getEle('modalTopBar').classList.add('hidden')
  const entryBtn = getEle("entry_type_selector")
  const entryView = getEle("entry_type_view")
  const entryInput = getEle("meta_entryType")
  const entryCodeWrap = getEle("entry_code_wrap")
  let lastSavedPayload = null;
  box.addEvent(entryBtn, "click", () => {
    const html = `
    <div class="py-4 border-b">
      <h3 class="text-lg font-semibold">Select Entry Type</h3>
    </div>
    <label class="flex items-center justify-between p-3 cursor-pointer border-b hover:bg-gray-50">
      <span>FREE</span>
      <input type="radio" name="entry" value="FREE" class="accent-primary form-radio h-4 w-4" />
    </label>
    <label class="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50">
      <span>LOCKED</span>
      <input type="radio" name="entry" value="LOCKED" class="accent-primary form-radio h-4 w-4" />
    </label>
  `
    openDrawer(html)
    setTimeout(() => {
      const radios = document.querySelectorAll('[name="entry"]')
      radios.forEach(radio => {
        if (radio.value === entryInput.value) {
          radio.checked = true
        }
        box.addEvent(radio, "change", () => {
          const val = radio.value
          entryInput.value = val
          entryView.innerText = val
          if (val === "LOCKED") {
            entryCodeWrap.classList.remove("hidden")
          } else {
            entryCodeWrap.classList.add("hidden")
            getEle("meta_entryCode").value = ""
          }
          closeDrawer()
        })
      })
    }, 50)
  })
  const s_resultHidden = getEle("s_resultHidden")
  const s_solutions = getEle("s_solutions")
  const s_reattempt = getEle("s_reattempt")
  box.addEvent(getEle('fg_enabled'), 'change', (e) => { const show = e.target.checked; controlFG(show) })
  function controlFG(isShow) { getEle('fg_controls').classList.toggle('hidden', !isShow) }
  function onHideResultToggle() {
    const s_solutions_toggle_btn = document.querySelector('.s_solutions_toggle_btn')
    const s_reattempt_toggle_btn = document.querySelector('.s_reattempt_toggle_btn')
    const btn_opacity = 'opacity-60'
    if (s_resultHidden.checked) {
      s_solutions.disabled = true
      s_reattempt.disabled = true
      s_solutions_toggle_btn.classList.add(btn_opacity)
      s_reattempt_toggle_btn.classList.add(btn_opacity)
      s_solutions.checked = true
      s_reattempt.checked = true
    } else {
      s_solutions.disabled = false
      s_reattempt.disabled = false
      s_solutions.checked = lastSavedPayload.isSolutionsHidden
      s_reattempt.checked = !lastSavedPayload.isReattemptAllowed
      s_solutions_toggle_btn.classList.remove(btn_opacity)
      s_reattempt_toggle_btn.classList.remove(btn_opacity)
    }
  }
  box.addEvent(s_resultHidden, 'change', onHideResultToggle)
  async function loadInfo() {
    if (!cache.has('test_setting_info')) {
      const resp = await fetchData('/my-tests/test_setting_info')
      const data = resp?.data || {}
      cache.set('test_setting_info', data, 60 * 60 * 1000)
      return data
    }
    return cache.get('test_setting_info')
  }
  document.querySelectorAll('[test_setting_info_key]').forEach(i => {
    box.addEvent(i, "click", async () => {
      const test_setting_info = await loadInfo()
      const _info = test_setting_info[i.getAttribute('test_setting_info_key')] || {}
      openDrawer(`
       <div class="text-center flex flex-col items-center">           
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="text-primary/70 w-16 h-16"><path fill="currentColor" d="M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-192a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm0-192c-18.2 0-32.7 15.5-31.4 33.7l7.4 104c.9 12.6 11.4 22.3 23.9 22.3 12.6 0 23-9.7 23.9-22.3l7.4-104c1.3-18.2-13.1-33.7-31.4-33.7z"></path></svg>   
  <h3 class="text-xl font-semibold py-2">${_info.name || ""}</h3>
            <p class="text-secondary mb-1">${_info.text || "Failed to load informaton!"}</p>
        </div>
        `)
    })
  })
  let blocked_users = []
  function removeFromBlockedUsers(username) {
    blocked_users.splice(blocked_users.indexOf(username), 1)
    appendBlockedUsersList()
  }
  function appendBlockedUsersList() {
    const list_ele = getEle('blocked_users_list')
    list_ele.innerHTML = ""
    blocked_users.forEach(user => {
      const new_block_user_label = document.createElement('div')
      const user_remove_btn = document.createElement('span')
      user_remove_btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" class="cursor-pointer w-4 h-4"><path fill="currentColor" d="M55.1 73.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L147.2 256 9.9 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192.5 301.3 329.9 438.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.8 256 375.1 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192.5 210.7 55.1 73.4z"/></svg>'
      new_block_user_label.className = 'bg-red-50/60 h-fit border-red-500 border px-3 rounded-2xl py-1 flex gap-2 items-center font-medium text-red-500'
      new_block_user_label.innerHTML = user
      box.addEvent(user_remove_btn, "click", () => { removeFromBlockedUsers(user) })
      new_block_user_label.append(user_remove_btn)
      list_ele.append(new_block_user_label)
    })
  }
  const block_user_input = getEle('block_user_input')
  const block_user_btn = getEle("block_user_btn")
  box.addEvent(block_user_input, 'keydown', (e) => {
    if (e.key == "Enter") block_user_btn.click()
  })
  box.addEvent(block_user_btn, 'click', () => {
    const new_username = String(block_user_input.value).trim().toLowerCase()
    if (!new_username) return
    if (new_username.length < 4 || new_username.length > 30 || !/^[a-z0-9._]+$/.test(new_username)) {
      toast('username look\'s not valid', "error")
      return
    }
    if (blocked_users.includes(new_username)) { toast('username already blocked'); return }
    blocked_users.push(new_username)
    appendBlockedUsersList()
    block_user_input.value = ''
  })
  const testId = params.testId
  let test = null
  let autosaveInterval = null
  async function loadTest() {
    async function loadByFetch() {
      if (!cache.has(`test_${testId}`)) {
        const resp = await fetchData(`/my-tests/${testId}/load`)
        if (!resp || !resp.success) { toast(resp?.message || "Failed to load test", 'error'); navigate('/create'); return }
        test = resp.data
        cache.set(`test_${testId}`, resp.data, 30 * 60 * 1000)
      } else {
        test = cache.get(`test_${testId}`)
      }
    }
    if (!cache.has('myAllTests')) { await loadByFetch() }
    else {
      const myAllTests = cache.get('myAllTests')
      test = myAllTests.find(t => t._id === testId)
      if (!test) await loadByFetch()
    }
    if (!test) return
    renderAll()
    startAutosave()
  }
  function getPayload() {
    const newPayload = {
      title: getEle('meta_title').value || "",
      description: getEle("meta_description").value || "",
      entryType: getEle('meta_entryType').value.toLowerCase(),
      entryCode: getEle('meta_entryCode').value || "",
      blockedUsers: [...blocked_users],
      duration: Number(getEle('meta_duration').value) || 0,
      focusGuard: {
        enabled: !!getEle('fg_enabled').checked,
        maxAwayTime: Number(getEle('fg_maxAway').value) || 0,
        maxTabSwitch: Number(getEle('fg_maxTabs').value) || 0
      },
      isReattemptAllowed: !getEle('s_reattempt').checked,
      isSolutionsHidden: !!getEle('s_solutions').checked,
      isResultHidden: !!getEle('s_resultHidden').checked,
      shuffle: !!getEle('s_shuffle').checked
    }
    return newPayload
  }
  function renderAll() {
    getEle('meta_title').value = test.title || ''
    getEle("meta_description").value = test.description || ''
    getEle('meta_duration').value = test.duration || ''
    getEle('meta_entryType').value = test.entryType.toUpperCase()
    getEle('meta_entryCode').value = test.entryCode ?? ''
    getEle('s_reattempt').checked = !test.isReattemptAllowed
    getEle('s_solutions').checked = test.isSolutionsHidden
    getEle('s_resultHidden').checked = test.isResultHidden
    getEle('s_shuffle').checked = test.shuffle
    getEle('fg_enabled').checked = test.focusGuard.enabled
    getEle('fg_maxAway').value = test.focusGuard.maxAwayTime || ''
    getEle('fg_maxTabs').value = test.focusGuard.maxTabSwitch || ''
    entryView.textContent = test.entryType.toUpperCase()
    if (test.entryType === "free") {
      entryCodeWrap.classList.add("hidden")
      getEle("meta_entryCode").value = test.entryCode
    } else {
      entryCodeWrap.classList.remove("hidden")
    }
    blocked_users = [...test.blockedUsers]
    lastSavedPayload = getPayload()
    appendBlockedUsersList()
    onHideResultToggle()
    controlFG(getEle('fg_enabled').checked)
  }
  function startAutosave() {
    if (autosaveInterval) clearInterval(autosaveInterval)
    autosaveInterval = box.setInterval(() => {
      saveTest(true)
    }, 90 * 1000)
  }
  function deepEqual(a, b) {
    if (a === b) return true
    if (typeof a !== "object" || typeof b !== "object" || !a || !b)
      return false
    const aKeys = Object.keys(a)
    const bKeys = Object.keys(b)
    if (aKeys.length !== bKeys.length) return false
    for (let k of aKeys) {
      if (!bKeys.includes(k)) return false
      if (!deepEqual(a[k], b[k])) return false
    }
    return true
  }
  async function saveTest(auto = true) {
    const payload = getPayload()
    if (deepEqual(payload, lastSavedPayload)) {
      if (!auto) toast('Edits saved', 'success')
      return
    }
    const resp = await fetchData(`/my-tests/${testId}/edit`, 'post', payload)
    if (!resp || !resp.success) { if (!auto) { toast(resp?.message || 'Failed to edit test', 'error') }; return; }
    cache.delete('myAllTests')
    cache.set(`test_${testId}`, { ...test, ...payload }, 30 * 60 * 1000)
    lastSavedPayload = { ...payload }
    if (!auto) toast('Edits saved', 'success')
  }
  box.addEvent(getEle('delete_test_btn'), 'click', deleteTestModal)
  box.addEvent(getEle('visibility_btn'), 'click', changeVisibility)
  box.addEvent(getEle('save_top_btn'), 'click', () => { saveTest(false) })
  loadTest()
  box.addEvent(window, 'beforeunload', saveTest)
  function changeVisibility() {
    const vpr = test.visibility === "private"
    popUp.show(`
      <div class="flex flex-col items-center pb-6">
      <div class="w-full flex justify-between items-center py-2">
      <h3 class="text-xl font-semibold">Change Visibility</h3>
      <svg onclick="popUp.hide()" viewBox=" 0 0 24 24" fill="none" stroke="black" class="w-6 h-6 mt-[5px]"><path stroke="currentColor" d="M6 6 L18 18 M6 18 L18 6" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path></svg>
      </div>
      <div class="w-full font-medium">Switch To <span class="text-primary"> ${vpr ? "Public" : "Private"}</spna></div>
      <div class="border p-3 rounded-lg mt-2 w-full">
        <span class="font-medium text-gray-800">Note : (English)</span>
        <div class="text-gray-600 font-medium">
        ${!vpr ? `
          Once the test is made private, no new users will be able to access it. But users who have already attempted the test can still view their results, but reattempt and solutions will no longer be available.
          ` : `
          Once the test is published and at least one user attempt it,major changes will be locked. You won't be able to add or delete questions or change correct answers or change marks.
          Only minor details can be edited later.
          `}
        </div>
      </div>
      <div class="border p-3 rounded-lg mt-2 w-full">
        <span class="font-medium text-gray-800">Note : (Hinglish)</span>
        <div class="text-gray-600 font-medium">
        ${!vpr ? `
          Test private karne ke baad koi naya user test access nahi kar paayega. Lekin jinhone pahle attempt kiya hai wo sirf apna result dekh sakenge. Reattempt aur solutions available nahi rahenge.
          ` : `
          Test public hone ke baad jaise hi koi ek bhi user attempt karega, major changes lock ho jaayenge. Questions add/delete ya answers change nahi kar paoge marks bhi change nahi hoga. Sirf chhoti-moti details me edit ho sakti hain.
          `}
        </div>
      </div>
      <div class="w-full p-2">
      <input id="v_test_condition" type="checkbox" class="accent-primary">
      <label for="v_test_condition" class="font-medium">I understand and agree to these conditions</label>
      </div>
 <p id="v_test_msg" class="${vpr ? "" : "hidden"} w-full text-sm py-2 mt-4 px-2 border-l-4 rounded bg-red-50 border-red-400 text-red-700">
   Make sure all test details and questions are properly set.
 </p>
       <button id="chnage_test_v" class="hidden w-full mt-6 py-3 rounded-lg border-2 font-medium ${vpr ? "bg-green-50/50 border-green-600 text-green-600" : "bg-orange-50/50 border-orange-600 text-orange-600"}">${vpr ? "Public" : "Private"}</button>
        `)
    box.setTimeout(() => {
      const v_change_btn = getEle("chnage_test_v")
      const error_text = getEle('v_test_msg')
      box.addEvent(getEle("v_test_condition"), "change", async (e) => {
        if (e.target.checked) {
          v_change_btn.classList.remove("hidden")
        }
        else {
          v_change_btn.classList.add("hidden")
        }
      })
      box.addEvent(v_change_btn, "click", async (e) => {
        const resp = await fetchData(`/my-tests/${testId}/change-visibility`, 'post')
        if (!resp || !resp.success) {
          toast("Make sure everything ok in test and every Questions  ", 'error')
          error_text.innerText = resp?.message || "Failed to change visibility"
          return
        }
        cache.delete('myAllTests')
        cache.delete(`test_${testId}`)
        cache.delete(`test_${testId}_q`)
        toast(resp.message, "success")
        navigate(`/tests/${testId}/dashboard`)
      })
    }, 80)
  }
  function deleteTestModal() {
    popUp.show(`
            <div class="flex flex-col items-center">
           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" class="w-24 h-24 text-red-600"><path fill="currentColor" d="M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 550.1 544 536 544L104 544C89.9 544 76.8 536.6 69.6 524.5C62.4 512.4 62.1 497.4 68.8 485L284.8 85C291.8 72.1 305.3 64 320 64zM320 416C302.3 416 288 430.3 288 448C288 465.7 302.3 480 320 480C337.7 480 352 465.7 352 448C352 430.3 337.7 416 320 416zM320 224C301.8 224 287.3 239.5 288.6 257.7L296 361.7C296.9 374.2 307.4 384 319.9 384C332.5 384 342.9 374.3 343.8 361.7L351.2 257.7C352.5 239.5 338.1 224 319.8 224z"/></svg>
             <h3 class="text-xl font-semibold pb-2">Delete Test</h3>
        <p class="text-center">
        Are you sure you want to delete test note that you can\'t recover this again you will lost all data
      </p>
      ${test.totalQuestions > 5 || test.totalAttemptsCount > 0 ? `
        <div>
        <label class="text-sm text-gray-600">Confirm by password.</label>
        <input
        id="del_final_code"
        class="w-full mt-1 px-3 py-3 border rounded-xl font-medium text-red-600 outline-none focus:border-red-600"
        placeholder="Enter Password"
        autocomplete="off"
        spellcheck = "false" 
        />
        </div>
        `: ""}
      <div class="flex w-full mt-6 gap-3">
       <button class="flex-1 py-3 rounded-lg border-2 border-black bg-gray-50 font-medium" onclick="popUp.hide()">Cancel</button>
       <button id="del_test" class="flex-1 py-3 rounded-lg border-2 border-red-600 bg-red-50/50 font-medium text-red-600">Delete</button>
          </div>
        `)
    box.setTimeout(() => {
      box.addEvent(getEle("del_test"), "click", async () => {
        let password = null
        if (test.totalQuestions >= 5 || test.totalAttemptsCount > 0) {
          password = getEle('del_final_code')?.value
          if (!password) {
            toast("Enter Password", "error");
            return
          }
        }
        const resp = await fetchData(`/my-tests/${testId}/delete`, "DELETE", { password })
        if (!resp || !resp.success) { popUp.hide(); toast(resp?.message || "Failed to delete test", "error"); return; }
        popUp.hide()
        cache.delete('myAllTests')
        cache.delete(`test_${testId}`)
        toast("Test Deleted", "success");
        navigate(`/create`)
      })
    }, 80)

  }
}


