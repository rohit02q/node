export async function Results(params) {
  return `
    <div class="min-h-full overflow-y-auto bg-white">
    <!--- Nav --->
      <div class="flex items-center gap-3 fixed inset-0 h-fit z-[2] bg-white px-4 py-4 border-b">
        <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="navigate('/tests/${params.testId}/dashboard')">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
         </button>
        <div class="flex-1">
          <div class="font-semibold text-secondary">Attempts & Results</div>
        </div>
      </div>
      <!--main content -->
      <div class="pt-16 pb-6 px-4 flex flex-col h-screen gap-4 w-full" id="results_main_content">
      <div class="px-4 pt-4">
      <div class="skeleton h-40 rounded-lg"></div>
      <div class="space-y-4 mt-6">
      <div class="skeleton h-16 rounded-lg"></div>
      <div class="skeleton h-16 rounded-lg"></div>
      <div class="skeleton h-16 rounded-lg"></div>
      </div>
      </div>
      </div>
    </div>
  `
}
export async function init(params, box) {
  const testId = params.testId
  const getEle = id => document.getElementById(id)
  getEle('modalTopBar').classList.add('hidden')
  let currentSortBy = "new"
  async function loadData() {
    const cachedSummary = cache.get(`test_${testId}_result_summary`)
    if (!cachedSummary) {
      const resp = await fetchData(`/my-tests/${testId}/result-summary`)
      if (!resp || !resp?.success) {
        toast(resp?.message || "Failed to load", "error")
        navigate("/")
        return
      }
      cache.set(`test_${testId}_result_summary`, resp.data, 2 * 60 * 1000)
      renderHtml(resp.data)
    } else {
      renderHtml(cachedSummary)
    }
  }
  function renderHtml(data) {
    const results = data
    getEle("results_main_content").innerHTML = `
        <div class="border bg-card rounded-lg p-2">
        <div class="text-lg font-semibold text-secondary">Total users : 45</div>
        <div class="text-lg font-semibold text-secondary">Total attempts : 109</div>
        </div>

        <div class="flex items-center gap-3 border-t pt-2">
            <label class="text-secondary text-lg font-medium font-medium">Sort By</label>
            <div id="sort_by_selector" class="flex-1 mt-1 flex justify-between items-center border rounded-xl px-4 py-3 cursor-pointer hover:bg-gray-50">
               <span class="font-medium text-secondary" id="sort_by_view">Newest</span>
               <svg class="w-4 h-4 rotate-[90deg]" fill="black" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7 Z"></path>
               </svg>
            </div>
        </div>

        <div class="flex-1 border-t pt-2 w-full overflow-y-auto">






<div class="pt-3 space-y-4">
${results.map(test => {
      return `
                  <div class="bg-card rounded-lg border p-4">
                  <div class="inline-flex items-center gap-2 mt-1"}>
                  <img 
    src="${test.user.profile}" 
    class="w-6 h-6 rounded-full border" 
    alt="creator"
    />
  <span class="text-secondary font-medium">
    ${test.user.username}
    </span>
</div>
                    <div class="flex mt-1">
                        <div class="flex-1">
                            <div class="flex gap-1 items-center">
                               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4 text-indigo-400">>
                       <path fill="currentColor" d="M256 64c-56.8 0-107.9 24.7-143.1 64l47.1 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 192c-17.7 0-32-14.3-32-32L0 32C0 14.3 14.3 0 32 0S64 14.3 64 32l0 54.7C110.9 33.6 179.5 0 256 0 397.4 0 512 114.6 512 256S397.4 512 256 512c-87 0-163.9-43.4-210.1-109.7-10.1-14.5-6.6-34.4 7.9-44.6s34.4-6.6 44.6 7.9c34.8 49.8 92.4 82.3 157.6 82.3 106 0 192-86 192-192S362 64 256 64z"/>
                     </svg>
                                <span class="text-gray-900 text-sm">
                                Total Attempt: ${test.attemptCount}
                           </span>
                            </div>
                            <div class="flex gap-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"
                                    class="w-4 h-4 text-indigo-400">
                                    <path fill="currentColor"
                                        d="M128 0c17.7 0 32 14.3 32 32l0 32 128 0 0-32c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-32c0-17.7 14.3-32 32-32zM64 240l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm128 0l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM64 368l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zm112 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16z" />
                                </svg>
                                <span class="text-gray-900 text-sm">
                                   Attempted on: ${new Date(test.lastAttempt.attemptOn).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: "2-digit", minute: "2-digit", hour12: true })}
                                </span>
                            </div>
                            <div class="flex gap-1 items-center">
                              <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-indigo-400" viewBox="0 0 512 512"><path fill="currentColor" d="M256 0a256 256 0 1 1 0 512 256 256 0 1 1 0-512zM232 120l0 136c0 8 4 15.5 10.7 20l96 64c11 7.4 25.9 4.4 33.3-6.7s4.4-25.9-6.7-33.3L280 243.2 280 120c0-13.3-10.7-24-24-24s-24 10.7-24 24z"></path></svg>
                                <span class="text-gray-900 text-sm">
                                   Submitted on: ${new Date(test.lastAttempt.submitOn).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: "2-digit", minute: "2-digit", hour12: true })}
                                </span>
                            </div>
                        </div> 
                        <div class="cursor-pointer flex flex-col justify-center items-center gap-[1px]" onclick="navigate('/')">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                class="w-8 h-8 py-1 px-2 text-white bg-primary rounded-full">
                                <path fill="currentColor"
                                    d="M502.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L402.7 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l370.7 0-105.4 105.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z" />
                            </svg>
                            <span class="text-xs font-semibold">
                                View Result
                            </span>
                        </div>
                    </div>
                </div>
                    `
    }).join('')}
                    </div>

























        </div>
        `
    initSortByBtn()

  }
  function initSortByBtn() {
    const sort_by_selector = getEle("sort_by_selector")
    const sort_by_view = getEle("sort_by_view")
    box.addEvent(getEle('sort_by_selector'), "click", () => {
      const html = `
    <div class="py-4 border-b">
      <h3 class="text-lg font-semibold">Sort By</h3>
    </div>
    <label class="flex items-center justify-between p-3 cursor-pointer border-b hover:bg-gray-50">
      <span>Newest</span>
      <input type="radio" name="sortBy" value="new" data-text="Newest" class="accent-primary form-radio h-4 w-4" />
    </label>
    <label class="flex items-center justify-between p-3 cursor-pointer border-b hover:bg-gray-50">
      <span>Oldest</span>
      <input type="radio" name="sortBy" value="old" data-text="Oldest" class="accent-primary form-radio h-4 w-4" />
    </label>
    <label class="flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50">
      <span>Number of Reattempt</span>
      <input type="radio" name="sortBy" value="reattempt" data-text="Number of Reattempt" class="accent-primary form-radio h-4 w-4" />
    </label>
  `
      openDrawer(html)
      setTimeout(() => {
        const radios = document.querySelectorAll('[name="sortBy"]')
        radios.forEach(radio => {
          if (radio.value === currentSortBy) {
            radio.checked = true
          }
          box.addEvent(radio, "change", () => {
            const val = radio.value
            currentSortBy = val
            sort_by_view.innerText = radio.dataset.text
            if (val === "LOCKED") {
            } else {
            }
            closeDrawer()
          })
        })
      }, 50)
    })
  }
  loadData()
}
