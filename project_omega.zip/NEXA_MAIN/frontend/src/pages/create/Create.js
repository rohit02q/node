export async function Create(params) {
    if (!APP_STATE.isLoggedIn) {
        return `
 <div class="empty-state">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M36.4 353.2c4.1-14.6 11.8-27.9 22.6-38.7l181.2-181.2 33.9-33.9c16.6 16.6 51.3 51.3 104 104l33.9 33.9-33.9 33.9-181.2 181.2c-10.7 10.7-24.1 18.5-38.7 22.6L30.4 510.6c-8.3 2.3-17.3 0-23.4-6.2S-1.4 489.3 .9 481L36.4 353.2zm55.6-3.7c-4.4 4.7-7.6 10.4-9.3 16.6l-24.1 86.9 86.9-24.1c6.4-1.8 12.2-5.1 17-9.7L91.9 349.5zm354-146.1c-16.6-16.6-51.3-51.3-104-104L308 65.5C334.5 39 349.4 24.1 352.9 20.6 366.4 7 384.8-.6 404-.6S441.6 7 455.1 20.6l35.7 35.7C504.4 69.9 512 88.3 512 107.4s-7.6 37.6-21.2 51.1c-3.5 3.5-18.4 18.4-44.9 44.9z"/></svg>
            <h3>Login Required</h3>
            <p>Please login to create and manage tests</p>
            <button class="btn-primary mt-4" onclick="navigate('/login')">Login</button>
        </div>
    `
    }
    return `
    <div class="p-4 min-h-full bg-white flex flex-col gap-4">
        <div>
          <button id="create_new_btn" class="btn-primary w-full flex items-center justify-center gap-2">
          <svg class="w-6 h-6 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>   
          Create New Test
          </button>
        </div>
        <div class="border-b pb-3">
        <h2 class="text-secondary text-xl bg-white font-bold">Your Tests</h2>
        <p class="text-sm text-gray-500">Edit & Manage Your tests here</p>
        </div>
        <div id="my_tests_list" class="space-y-3 pt-2">
          ${'<div class="skeleton h-24 rounded-lg"></div>'.repeat(4)}
        </div>
      </div>
  `
}
export async function init(_, box) {
    if (!APP_STATE.isLoggedIn) return
    const createBtn = document.getElementById('create_new_btn')
    function openCreateModal() {
        popUp.show(`
      <div class="p-4">
      <div class="flex justify-between items-center w-full mb-4">
      <h3 class="text-secondary text-xl bg-white font-semibold">Create New Test</h3>
        <svg onclick="popUp.hide()"  viewBox=" 0 0 24 24" fill="none" stroke="black" class="w-6 h-6"><path stroke="currentColor" d="M6 6 L18 18 M6 18 L18 6" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path></svg>
      </div>
        <p class="text-sm text-gray-600 mb-6">Give your test a title. You can edit all details later.</p>
        <textarea id="new_test_title" placeholder="Test title (eg. Math Test - 01)" class="hideScroll w-full p-3 rounded-lg outline-[1px] outline outline-primary" autocomplete="off" spellcheck = "false" ></textarea>
       <p id="create_error_msg" class="hidden text-sm py-2 mt-4 px-2 border-l-4 rounded bg-red-50 border-red-400 text-red-700"></p>
        <div class="flex gap-2 mt-4">
         <button id="do_create" class="flex-1 btn-primary px-2">Create & Next</button>
        </div>  
      </div>
    `)
        setTimeout(() => {
            box.addEvent(document.getElementById('do_create'), 'click', async () => {
                const title = document.getElementById('new_test_title').value.trim()
                const error = document.getElementById('create_error_msg')
                if (!title) {
                    error.classList.remove("hidden")
                    error.innerText = "Test title required"
                    return
                }
                const resp = await fetchData('/my-tests/new', "post", { title })
                box.setTimeout(() => {
                    if (!resp || !resp.success) {
                        error.classList.remove("hidden")
                        error.innerText = resp?.message || "Failed to create test"
                        return
                    }
                    APP_STATE.user.totalTests = APP_STATE.user.totalTests + 1
                    cache.set('myAllTests', [...cache.get('myAllTests') || [], resp.data], 10 * 60 * 1000)
                    navigate(`/tests/${resp.data._id}/edit`)
                }, 300)
            })
        }, 80)
    }
    box.addEvent(createBtn, 'click', openCreateModal)
    const listEl = document.getElementById('my_tests_list')
    async function loadMyTests() {
        let tests = []
        if (!cache.has('myAllTests')) {
            const resp = await fetchData('/my-tests/list-tests')
            if (!resp || !resp.success) { toast('Failed to load tests', 'error'); return; }
            tests = resp?.data || []
            cache.set("myAllTests", resp.data, 30 * 60 * 1000)
        } else {
            tests = cache.get('myAllTests')
        }
        if (!tests || tests.length === 0) {
            listEl.innerHTML = `
       <div class="empty-state">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                        </path>
                     </svg>
                   <p class="text-secondary">No tests yet. Tap <strong>Create New Test</strong> to get started.</p>
                    </div>
                    `
            return
        }
        listEl.innerHTML = tests.map(t => {
            const statusClass = t.visibility === 'private' ? 'bg-orange-100/50 text-orange-600' : 'bg-green-100/50 text-green-600'
            const typeClass = t.entryType === 'free' ? 'bg-blue-100/50 text-blue-600' : 'bg-pink-100/50 text-pink-600'
            const marks = Object.values(t.questions || {}).reduce((sum, q) => sum + q.positiveMarks, 0)
            return `
            <div class="bg-card rounded-lg border p-4">
                  <div class="inline-flex items-center justify-between w-full my-1">
                  <span class="${statusClass} px-2 py-1 font-medium text-xs rounded-md" style="letter-spacing:0.7px">${t.visibility.toUpperCase()}</span>
                  <span class="${typeClass} px-2 py-1 font-medium text-xs rounded-md" style="letter-spacing:0.7px">${t.entryType.toUpperCase()}</span>
                  </div>
               <div class="font-semibold">${t.title || "Untitled Test"}</div>
                    <div class="flex mt-1">
                        <div class="flex-1">
                            <div class="flex gap-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4 text-indigo-400">
                                    <path fill="currentColor" d="M133.8 36.3c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 158 47 153L7 113C-2.3 103.6-2.3 88.4 7 79S31.6 69.7 41 79l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zm0 160c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 318 47 313L7 273c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zM224 96c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zm0 160c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zM160 416c0-17.7 14.3-32 32-32l288 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-288 0c-17.7 0-32-14.3-32-32zM64 376a40 40 0 1 1 0 80 40 40 0 1 1 0-80z"></path>
                                </svg>
                                <span class="text-gray-900 text-sm">
                                    ${t.totalQuestions} Questions • ${marks} Marks • ${t.duration} mins
                                </span>
                            </div>
                            <div class="flex gap-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-4 h-4 text-indigo-400">
                                    <path fill="currentColor" d="M128 0c17.7 0 32 14.3 32 32l0 32 128 0 0-32c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-32c0-17.7 14.3-32 32-32zM64 240l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm128 0l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM64 368l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zm112 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16z"></path>
                                </svg>
                               <span class="text-gray-900 text-sm">
                                  Created on: ${new Date(t.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: "2-digit", minute: "2-digit", hour12: true })}
                                </span>
                            </div>
                        </div> <div class="cursor-pointer flex flex-col justify-center items-center gap-[1px]" onclick="navigate('/tests/${t._id}/dashboard')">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-8 h-8 py-1 px-2 text-white bg-primary rounded-full">
                                <path fill="currentColor" d="M502.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L402.7 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l370.7 0-105.4 105.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z"></path>
                            </svg>
                            <span class="text-xs font-semibold">
                                View
                            </span>
                        </div>
                    </div>
                </div>
            `
        }).join('')
    }
    await loadMyTests()
}