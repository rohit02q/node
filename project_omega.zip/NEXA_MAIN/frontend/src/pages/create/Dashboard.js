export async function Dashboard(params) {
  return `
    <div class="min-h-fit overflow-y-auto bg-white">
    <!--- Nav --->
      <div class="flex items-center gap-3 fixed inset-0 h-fit z-[2] bg-white px-4 py-3 border-b">
        <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="navigate('/create')">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
         </button>
        <div class="flex-1">
          <div class="font-semibold text-secondary">Dashboard</div>
          <div class="text-sm text-gray-600" id="test_id">${params.testId}
          <svg fill="none" class="inline w-5 h-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"
          viewBox="0 0 28 28">
          <rect x="12" y="2.5" width="11" height="13" rx="2" ry="2"></rect>
          <rect x="7" y="7" width="11" height="13" rx="2" ry="2" fill="#fff"></rect>
          </svg>
          </div>
        </div>
      </div>
      <!--main content -->
      <div class="pt-16 pb-6" id="dashboard_main_content">
      <div class="px-4 pt-4">
      <div class="skeleton h-40 rounded-lg"></div>
      <div class="space-y-4 mt-6">
      <div class="skeleton h-16 rounded-lg"></div>
      <div class="skeleton h-16 rounded-lg"></div>
      <div class="skeleton h-16 rounded-lg"></div>
      </div>
      </div>
      </div>
    </div>
  `
}
export async function init(params, box) {
  const testId = params.testId
  const getEle = id => document.getElementById(id)
  getEle('modalTopBar').classList.add('hidden')
  let test = null;
  async function loadTest() {
    async function loadByFetch() {
      if (!cache.has(`test_${testId}`)) {
        const resp = await fetchData(`/my-tests/${testId}/load`)
        if (!resp || !resp.success) { toast(resp?.message || "Failed to load test", 'error'); navigate('/create'); return }
        test = resp.data
        cache.set(`test_${testId}`, resp.data, 45 * 60 * 1000)
      } else {
        test = cache.get(`test_${testId}`)
      }
    }
    if (!cache.has('myAllTests')) { await loadByFetch() }
    else {
      const myAllTests = cache.get('myAllTests')
      test = myAllTests.find(t => t._id === testId)
      if (!test) await loadByFetch()
    }
  }
  function initAll() {
    if (!test) return
    const isAttemptDashboardEnabled = test.totalAttemptsCount > 0 || test.visibility === 'public'
    const statusClass = test.visibility === 'private' ? 'bg-orange-100/50 text-orange-600' : 'bg-green-100/50 text-green-600'
    const typeClass = test.entryType === 'free' ? 'bg-blue-100/50 text-blue-600' : 'bg-pink-100/50 text-pink-600'
    getEle("dashboard_main_content").innerHTML = `
              <div class="p-4">
              <div class="flex flex-col w-full h-auto px-4 pt-4 pb-6 rounded-xl border bg-card">
                  <div class="inline-flex items-center justify-between w-full my-1">
                  <span class="${statusClass} px-2 py-1 font-medium text-xs rounded-md" style="letter-spacing:0.7px">${test.visibility.toUpperCase()}</span>
                  <span class="${typeClass} px-2 py-1 font-medium text-xs rounded-md" style="letter-spacing:0.7px">${test.entryType.toUpperCase()}</span>
                 </div>
                                <div class="mb-2 font-semibold">${test.title || "Untitled Test"}</div>
                              <div class="flex gap-1 items-center mb-1">
                                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4 text-indigo-400">
                                              <path fill="currentColor" d="M133.8 36.3c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 158 47 153L7 113C-2.3 103.6-2.3 88.4 7 79S31.6 69.7 41 79l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zm0 160c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 318 47 313L7 273c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zM224 96c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zm0 160c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zM160 416c0-17.7 14.3-32 32-32l288 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-288 0c-17.7 0-32-14.3-32-32zM64 376a40 40 0 1 1 0 80 40 40 0 1 1 0-80z"></path>
                                          </svg>
                                          <span class="text-gray-900 text-sm font-medium"> ${test.totalQuestions} Questions • ${test.totalMarks} Marks • ${test.duration} mins</span>
                                      </div>
                               <div class="flex gap-1 items-center mb-1">
                                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-4 h-4 text-indigo-400">
                                              <path fill="currentColor" d="M128 0c17.7 0 32 14.3 32 32l0 32 128 0 0-32c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-32c0-17.7 14.3-32 32-32zM64 240l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm128 0l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM64 368l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zm112 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16z"></path>
                                          </svg>
                                          <span class="text-gray-900 text-sm font-medium">Created on: ${new Date(test.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: "2-digit", minute: "2-digit", hour12: true })}</span>
                                          </div>
                               <div class="flex gap-1 items-center">
                                      <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-indigo-400" viewBox="0 0 512 512"><path fill="currentColor" d="M256 0a256 256 0 1 1 0 512 256 256 0 1 1 0-512zM232 120l0 136c0 8 4 15.5 10.7 20l96 64c11 7.4 25.9 4.4 33.3-6.7s4.4-25.9-6.7-33.3L280 243.2 280 120c0-13.3-10.7-24-24-24s-24 10.7-24 24z"></path></svg>
                                          <span class="text-gray-900 attempt-time text-sm font-medium">Last Edit: ${new Date(test.updatedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: "2-digit", minute: "2-digit", hour12: true })}</span></div>   
                                </div>
                      </div>
              </div>  
              <div class="p-4 space-y-3">
                   <div class="bg-gradient-to-r to-white from-indigo-50 border rounded-lg p-4">
                    <div onclick="navigate('/tests/${testId}/edit')" class="flex items-center justify-between">
                    <div class="flex gap-2 items-center">
                  <svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z">
                                </path>
                            </svg>
                            <span class="font-medium">Edit Test</span>
                        </div>
                        <svg class="w-5 h-5 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </div>
                   </div>
                   <div class="bg-gradient-to-r to-white from-indigo-50 border rounded-lg p-4">
                   <div onclick="navigate('/tests/${testId}/questions?${(new URLSearchParams({ test_title: test.title })).toString()}')" class="flex items-center justify-between">
                         <div class="flex gap-2 items-center">
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-5 h-5 text-gray-700">
                    <path fill="currentColor" d="M133.8 36.3c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 158 47 153L7 113C-2.3 103.6-2.3 88.4 7 79S31.6 69.7 41 79l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zm0 160c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 318 47 313L7 273c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zM224 96c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zm0 160c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zM160 416c0-17.7 14.3-32 32-32l288 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-288 0c-17.7 0-32-14.3-32-32zM64 376a40 40 0 1 1 0 80 40 40 0 1 1 0-80z"></path>
                  </svg>
                   <span class="font-medium">Manage Questions</span>
                   </div>
                   <svg class="w-5 h-5 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </div>
                   </div>
   ${isAttemptDashboardEnabled ? `
                   <div class="bg-gradient-to-r to-white from-indigo-50 border rounded-lg p-4" onclick="navigate('/tests/${testId}/results')">
                    <div  class="flex items-center justify-between">
                  <div class="flex gap-2 items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-5 h-5 text-gray-700"><path fill="currentColor" d="M64 64c0-17.7-14.3-32-32-32S0 46.3 0 64L0 400c0 44.2 35.8 80 80 80l400 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L80 416c-8.8 0-16-7.2-16-16L64 64zm406.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L320 210.7 262.6 153.4c-12.5-12.5-32.8-12.5-45.3 0l-96 96c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l73.4-73.4 57.4 57.4c12.5 12.5 32.8 12.5 45.3 0l128-128z"/></svg>  
                    <span class="font-medium">Attempts & Results</span>
                    </div>
                        <svg class="w-5 h-5 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </div>
                   </div>  ` : ""}
    ${test.visibility === 'public' ? `
          <div class="bg-gradient-to-r to-white from-gray-50 p-4 border rounded-lg">
                <div class="flex items-center mb-4 gap-2">
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="w-5 h-5 text-gray-700"><path fill="currentColor" d="M384.5 24l0 72-64 0c-79.5 0-144 64.5-144 144 0 93.4 82.8 134.8 100.6 142.6 2.2 1 4.6 1.4 7.1 1.4l2.5 0c9.8 0 17.8-8 17.8-17.8 0-8.3-5.9-15.5-12.8-20.3-8.9-6.2-19.2-18.2-19.2-40.5 0-45 36.5-81.5 81.5-81.5l30.5 0 0 72c0 9.7 5.8 18.5 14.8 22.2s19.3 1.7 26.2-5.2l136-136c9.4-9.4 9.4-24.6 0-33.9L425.5 7c-6.9-6.9-17.2-8.9-26.2-5.2S384.5 14.3 384.5 24zm-272 72c-44.2 0-80 35.8-80 80l0 256c0 44.2 35.8 80 80 80l256 0c44.2 0 80-35.8 80-80l0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32c0 8.8-7.2 16-16 16l-256 0c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l16 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-16 0z"/></svg>
                   <h3 class="font-semibold text-lg">Share Test</h3>
                </div>
                <div class="flex gap-2 pr-2 py-1 bg-white items-center border border-secondary rounded justify-between">
                <div class="p-2 bg-transparent text-blue-600 text-sm line-clamp-1" onclick="navigate('/tests/${testId}')">${location.origin}/tests/${testId}</div>
                 <div id="test_link_copy">
                  <svg fill="none" class="text-gray-700 inline w-8 h-8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"
                 viewBox="0 0 28 28">
                 <rect x="12" y="4.5" width="11" height="13" rx="2" ry="2"></rect>
                 <rect x="7" y="9" width="11" height="13" rx="2" ry="2" fill="#fff"></rect>
                 </svg>
                </div>
                </div>
           </div> ` : ""}
    </div>
    `
    box.addEvent(getEle("test_id"), "click", () => {
      navigator.clipboard.writeText(testId)
      toast("Test ID copied to clipboard")
    })
    if (test.visibility === 'public') {
      box.addEvent(getEle("test_link_copy"), "click", () => {
        navigator.clipboard.writeText(`${location.origin}/tests/${testId}?link_type=share`)
        toast("Link copied to clipboard")
      })
    }
  }
  loadTest().then(initAll)
}