export async function Attempt() {
    const oldLink = document.getElementById("attempt_test_css")
    if (!oldLink) {
        const link = document.createElement("link")
        link.rel = "stylesheet"
        link.id = "attempt_test_css"
        link.href = "/styles/AttemptTest.css"
        document.head.appendChild(link)
    }
    return `
    <!-- =============  Page Loader ============-->
    <div class="loaderPage w-full h-full bg-white fixed insext-0 z-[50] flex flex-col justify-center items-center gap-4">
        <span class="text-[3rem] rounded-full bg-orange-50 p-4">📝</span>
        <p id="test_loader" class="text-xl font-medium text-primary">Preparing Your Test...</p>
    </div>
    <section class="flex flex-col w-full h-full">
        <div class="test_nav w-full h-fit bg-white p-4 shadow-md">
            <div class="flex items-center justify-between">
                <div class="flex font-medium text-xl gap-1 items-center text-[#1e1e1e]">
                    <svg class="w-8 h-8" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M9.0498 3.47485C9.89355 3.47485 10.7293 3.64122 11.5088 3.96411L11.7979 4.09204C12.4636 4.40703 13.0708 4.83481 13.5928 5.35669L13.8115 5.58618C14.306 6.13199 14.7039 6.75976 14.9863 7.44165C15.309 8.22092 15.4746 9.05621 15.4746 9.89966C15.4746 10.6379 15.3477 11.3701 15.0996 12.0637L14.9863 12.3586C14.6634 13.1382 14.1894 13.847 13.5928 14.4436C13.0708 14.9655 12.4636 15.3933 11.7979 15.7083L11.5088 15.8362C10.7293 16.1591 9.89354 16.3254 9.0498 16.3254C7.34595 16.3254 5.71169 15.6484 4.50684 14.4436C3.30191 13.2387 2.625 11.6037 2.625 9.89966C2.6251 8.19578 3.30201 6.56152 4.50684 5.35669C5.7117 4.15188 7.34591 3.47491 9.0498 3.47485ZM9.0498 4.62524C8.44378 4.62527 7.84285 4.72921 7.27344 4.93286L7.03125 5.02661C6.4712 5.2586 5.95604 5.58525 5.50781 5.99146L5.32031 6.17017C4.89175 6.59872 4.5399 7.09711 4.28125 7.6438L4.17676 7.8811C3.91171 8.52098 3.77544 9.20707 3.77539 9.89966C3.77539 10.5924 3.91166 11.2792 4.17676 11.9192C4.44185 12.559 4.83061 13.1404 5.32031 13.6301L5.50781 13.8088C5.95604 14.215 6.47122 14.5417 7.03125 14.7737L7.27344 14.8665C7.84292 15.0702 8.4437 15.175 9.0498 15.175C10.4488 15.175 11.791 14.6194 12.7803 13.6301L12.96 13.4407C13.8363 12.473 14.3252 11.2114 14.3252 9.89966C14.3251 8.50087 13.7693 7.15931 12.7803 6.17017C11.791 5.18091 10.4488 4.62524 9.0498 4.62524ZM9.0498 5.27466C9.2023 5.27466 9.3492 5.33577 9.45703 5.4436L9.52832 5.53149C9.5907 5.62516 9.62496 5.73566 9.625 5.84985V10.3499C9.625 10.4643 9.5909 10.5754 9.52832 10.6692L9.45703 10.7571C9.3492 10.8649 9.2023 10.925 9.0498 10.925C8.93561 10.925 8.82511 10.8907 8.73145 10.8284L8.64355 10.7571C8.53572 10.6492 8.47461 10.5024 8.47461 10.3499V5.84985C8.47466 5.69743 8.53577 5.55139 8.64355 5.4436L8.73145 5.37134C8.82507 5.30904 8.93569 5.2747 9.0498 5.27466ZM13.9346 3.28638C13.9719 3.29419 14.0088 3.30544 14.0439 3.32056L14.1436 3.37524C14.1748 3.39684 14.2039 3.42199 14.2305 3.44946L14.2539 3.47388L15.5 4.71899L15.5732 4.80591C15.5948 4.83718 15.6138 4.87043 15.6289 4.90552L15.6631 5.01392C15.6709 5.05108 15.6754 5.08903 15.6758 5.1272L15.665 5.24048L15.6328 5.34985C15.6039 5.42052 15.5608 5.48532 15.5068 5.53931C15.453 5.59311 15.3888 5.63543 15.3184 5.66431C15.283 5.67876 15.2463 5.69034 15.209 5.69751L15.0957 5.70728C15.0577 5.70694 15.0195 5.70332 14.9824 5.69556L14.873 5.6604C14.8038 5.63057 14.7411 5.58748 14.6885 5.53345L13.416 4.26099V4.26001C13.3892 4.23391 13.3649 4.20569 13.3438 4.17505L13.2881 4.07544C13.2731 4.04046 13.2617 4.00411 13.2539 3.96704L13.2422 3.85376C13.2415 3.77748 13.2553 3.70172 13.2842 3.6311L13.3379 3.53052C13.3589 3.49892 13.3832 3.4696 13.4102 3.44263C13.4641 3.38872 13.5281 3.34556 13.5986 3.31665C13.6692 3.28779 13.7451 3.27308 13.8213 3.27368L13.9346 3.28638ZM10.8496 1.67505C11.0021 1.67505 11.149 1.73525 11.2568 1.84302L11.3281 1.93091C11.3907 2.02473 11.4248 2.13578 11.4248 2.25024C11.4248 2.36447 11.3905 2.47492 11.3281 2.5686L11.2568 2.65649C11.149 2.76433 11.0021 2.82544 10.8496 2.82544H7.25C7.13559 2.82544 7.02446 2.79132 6.93066 2.72876L6.84375 2.65649C6.73596 2.54871 6.67486 2.40267 6.6748 2.25024C6.6748 2.09774 6.73592 1.95085 6.84375 1.84302L6.93066 1.77173C7.02449 1.70909 7.13552 1.67505 7.25 1.67505H10.8496Z"
                            fill="#414347" stroke="#414347" stroke-width="0.25"></path>
                    </svg>
                    <span class="test_timer">00 : 00</span>
                </div>
                <div class="flex items-center gap-2">
                    <button class="openSubmitPage btn-primary rounded-md px-3 py-2">Submit</button>
                    <label for="gridViewBtn">
                        <svg width="42" height="44" viewBox="0 0 31 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M9.5 12C10.3284 12 11 11.3284 11 10.5C11 9.67157 10.3284 9 9.5 9C8.67157 9 8 9.67157 8 10.5C8 11.3284 8.67157 12 9.5 12Z"
                                fill="#0E0F23"></path>
                            <path
                                d="M15.5 12C16.3284 12 17 11.3284 17 10.5C17 9.67157 16.3284 9 15.5 9C14.6716 9 14 9.67157 14 10.5C14 11.3284 14.6716 12 15.5 12Z"
                                fill="#0E0F23"></path>
                            <path
                                d="M21.5 12C22.3284 12 23 11.3284 23 10.5C23 9.67157 22.3284 9 21.5 9C20.6716 9 20 9.67157 20 10.5C20 11.3284 20.6716 12 21.5 12Z"
                                fill="#0E0F23"></path>
                            <path
                                d="M9.5 18C10.3284 18 11 17.3284 11 16.5C11 15.6716 10.3284 15 9.5 15C8.67157 15 8 15.6716 8 16.5C8 17.3284 8.67157 18 9.5 18Z"
                                fill="#0E0F23"></path>
                            <path
                                d="M15.5 18C16.3284 18 17 17.3284 17 16.5C17 15.6716 16.3284 15 15.5 15C14.6716 15 14 15.6716 14 16.5C14 17.3284 14.6716 18 15.5 18Z"
                                fill="#0E0F23"></path>
                            <path
                                d="M21.5 18C22.3284 18 23 17.3284 23 16.5C23 15.6716 22.3284 15 21.5 15C20.6716 15 20 15.6716 20 16.5C20 17.3284 20.6716 18 21.5 18Z"
                                fill="#0E0F23"></path>
                            <path
                                d="M9.5 24C10.3284 24 11 23.3284 11 22.5C11 21.6716 10.3284 21 9.5 21C8.67157 21 8 21.6716 8 22.5C8 23.3284 8.67157 24 9.5 24Z"
                                fill="#0E0F23"></path>
                            <path
                                d="M15.5 24C16.3284 24 17 23.3284 17 22.5C17 21.6716 16.3284 21 15.5 21C14.6716 21 14 21.6716 14 22.5C14 23.3284 14.6716 24 15.5 24Z"
                                fill="#0E0F23"></path>
                            <path
                                d="M21.5 24C22.3284 24 23 23.3284 23 22.5C23 21.6716 22.3284 21 21.5 21C20.6716 21 20 21.6716 20 22.5C20 23.3284 20.6716 24 21.5 24Z"
                                fill="#0E0F23"></path>
                        </svg>
                    </label>
                </div>
            </div>
        </div>
        <!-- !   Submit Page System  -->
        <input type="checkbox" id="Submit-checkbox">
        <div class="submit-page flex">
            <div class="flex-1 p-4 space-y-4 overflow-y-auto">
                <h2 id="attemptTestTitle" class="line-clamp-2 text-lg font-semibold pr-1">Physics Advance Test 01 </h2>
                <div class="space-y-4">
                <div class="flex justify-between items-center">
                    <h3 class="font-bold text-xl text-secondary">Test Summary</h3>
                 <div class="bg-[#fbfbfb] border border-secondary px-2.5 py-1 rounded-full flex font-medium text-sm gap-1 items-center text-[#1e1e1e]">
                    <svg class="w-6 h-6" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M9.0498 3.47485C9.89355 3.47485 10.7293 3.64122 11.5088 3.96411L11.7979 4.09204C12.4636 4.40703 13.0708 4.83481 13.5928 5.35669L13.8115 5.58618C14.306 6.13199 14.7039 6.75976 14.9863 7.44165C15.309 8.22092 15.4746 9.05621 15.4746 9.89966C15.4746 10.6379 15.3477 11.3701 15.0996 12.0637L14.9863 12.3586C14.6634 13.1382 14.1894 13.847 13.5928 14.4436C13.0708 14.9655 12.4636 15.3933 11.7979 15.7083L11.5088 15.8362C10.7293 16.1591 9.89354 16.3254 9.0498 16.3254C7.34595 16.3254 5.71169 15.6484 4.50684 14.4436C3.30191 13.2387 2.625 11.6037 2.625 9.89966C2.6251 8.19578 3.30201 6.56152 4.50684 5.35669C5.7117 4.15188 7.34591 3.47491 9.0498 3.47485ZM9.0498 4.62524C8.44378 4.62527 7.84285 4.72921 7.27344 4.93286L7.03125 5.02661C6.4712 5.2586 5.95604 5.58525 5.50781 5.99146L5.32031 6.17017C4.89175 6.59872 4.5399 7.09711 4.28125 7.6438L4.17676 7.8811C3.91171 8.52098 3.77544 9.20707 3.77539 9.89966C3.77539 10.5924 3.91166 11.2792 4.17676 11.9192C4.44185 12.559 4.83061 13.1404 5.32031 13.6301L5.50781 13.8088C5.95604 14.215 6.47122 14.5417 7.03125 14.7737L7.27344 14.8665C7.84292 15.0702 8.4437 15.175 9.0498 15.175C10.4488 15.175 11.791 14.6194 12.7803 13.6301L12.96 13.4407C13.8363 12.473 14.3252 11.2114 14.3252 9.89966C14.3251 8.50087 13.7693 7.15931 12.7803 6.17017C11.791 5.18091 10.4488 4.62524 9.0498 4.62524ZM9.0498 5.27466C9.2023 5.27466 9.3492 5.33577 9.45703 5.4436L9.52832 5.53149C9.5907 5.62516 9.62496 5.73566 9.625 5.84985V10.3499C9.625 10.4643 9.5909 10.5754 9.52832 10.6692L9.45703 10.7571C9.3492 10.8649 9.2023 10.925 9.0498 10.925C8.93561 10.925 8.82511 10.8907 8.73145 10.8284L8.64355 10.7571C8.53572 10.6492 8.47461 10.5024 8.47461 10.3499V5.84985C8.47466 5.69743 8.53577 5.55139 8.64355 5.4436L8.73145 5.37134C8.82507 5.30904 8.93569 5.2747 9.0498 5.27466ZM13.9346 3.28638C13.9719 3.29419 14.0088 3.30544 14.0439 3.32056L14.1436 3.37524C14.1748 3.39684 14.2039 3.42199 14.2305 3.44946L14.2539 3.47388L15.5 4.71899L15.5732 4.80591C15.5948 4.83718 15.6138 4.87043 15.6289 4.90552L15.6631 5.01392C15.6709 5.05108 15.6754 5.08903 15.6758 5.1272L15.665 5.24048L15.6328 5.34985C15.6039 5.42052 15.5608 5.48532 15.5068 5.53931C15.453 5.59311 15.3888 5.63543 15.3184 5.66431C15.283 5.67876 15.2463 5.69034 15.209 5.69751L15.0957 5.70728C15.0577 5.70694 15.0195 5.70332 14.9824 5.69556L14.873 5.6604C14.8038 5.63057 14.7411 5.58748 14.6885 5.53345L13.416 4.26099V4.26001C13.3892 4.23391 13.3649 4.20569 13.3438 4.17505L13.2881 4.07544C13.2731 4.04046 13.2617 4.00411 13.2539 3.96704L13.2422 3.85376C13.2415 3.77748 13.2553 3.70172 13.2842 3.6311L13.3379 3.53052C13.3589 3.49892 13.3832 3.4696 13.4102 3.44263C13.4641 3.38872 13.5281 3.34556 13.5986 3.31665C13.6692 3.28779 13.7451 3.27308 13.8213 3.27368L13.9346 3.28638ZM10.8496 1.67505C11.0021 1.67505 11.149 1.73525 11.2568 1.84302L11.3281 1.93091C11.3907 2.02473 11.4248 2.13578 11.4248 2.25024C11.4248 2.36447 11.3905 2.47492 11.3281 2.5686L11.2568 2.65649C11.149 2.76433 11.0021 2.82544 10.8496 2.82544H7.25C7.13559 2.82544 7.02446 2.79132 6.93066 2.72876L6.84375 2.65649C6.73596 2.54871 6.67486 2.40267 6.6748 2.25024C6.6748 2.09774 6.73592 1.95085 6.84375 1.84302L6.93066 1.77173C7.02449 1.70909 7.13552 1.67505 7.25 1.67505H10.8496Z"
                            fill="#414347" stroke="#414347" stroke-width="0.25"></path>
                    </svg>
                    <span class="test_timer">00 : 00</span>
                </div>
                </div>
                    <div class="boxDiv">
                        <div class="status-type">
                            <p>Total Questions</p>
                        </div>
                        <div class="count" id="totalQ">0</div>
                    </div>
                    <div class="boxDiv">
                        <div class="status-type">
                            <div class="circle circle1"></div>
                            <p>Answered</p>
                        </div>
                        <div class="count" id="Answered2"></div>
                    </div>
                    <div class="boxDiv">
                        <div class="status-type">
                            <div class="circle circle2"></div>
                            <p>Not Answered</p>
                        </div>
                        <div class="count" id="NotAnswersed2"></div>
                    </div>
                    <div class="boxDiv">
                        <div class="status-type">
                            <div class="circle circle5"></div>
                            <p>Not Visited</p>
                        </div>
                        <div class="count" id="visit2"></div>
                    </div>
                    <div class="boxDiv">
                        <div class="status-type">
                            <div class="circle circle3"></div>
                            <p>Marked for Review</p>
                        </div>
                        <div class="count" id="MarkforReview2"></div>
                    </div>
                    <div class="boxDiv">
                        <div class="status-type">
                            <div class="circle circle4"></div>
                            <p>Answered & Marked for Review</p>
                        </div>
                        <div class="count" id="aAndm2"></div>
                    </div>
                </div>
            </div>
            <div class="flex w-full h-fit p-4 gap-3 border-t-2">
              <button id="resumeTest" class="flex-1 btn-secondary rounded-md">Resume</button>
              <button id="goToSubmit" class="flex-1 btn-primary rounded-md">Submit</button>
            </div>
        </div>

        <!--  Grid Check Box System -->
        <input type="checkbox" id="gridViewBtn">
        <div class="grid-view">
       <div class="flex items-center gap-1 h-fit bg-white p-4 shadow-md">
        <label class="w-fit h-fit flex items-center justify-center" for="gridViewBtn">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
      </label>
      <div class="flex-1">
       <div class="font-semibold text-secondary text-xl">Grid View</div>
        </div>  
        <div class="flex font-medium text-xl gap-1 items-center text-[#1e1e1e]">
          <svg class="w-8 h-8" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
           <path d="M9.0498 3.47485C9.89355 3.47485 10.7293 3.64122 11.5088 3.96411L11.7979 4.09204C12.4636 4.40703 13.0708 4.83481 13.5928 5.35669L13.8115 5.58618C14.306 6.13199 14.7039 6.75976 14.9863 7.44165C15.309 8.22092 15.4746 9.05621 15.4746 9.89966C15.4746 10.6379 15.3477 11.3701 15.0996 12.0637L14.9863 12.3586C14.6634 13.1382 14.1894 13.847 13.5928 14.4436C13.0708 14.9655 12.4636 15.3933 11.7979 15.7083L11.5088 15.8362C10.7293 16.1591 9.89354 16.3254 9.0498 16.3254C7.34595 16.3254 5.71169 15.6484 4.50684 14.4436C3.30191 13.2387 2.625 11.6037 2.625 9.89966C2.6251 8.19578 3.30201 6.56152 4.50684 5.35669C5.7117 4.15188 7.34591 3.47491 9.0498 3.47485ZM9.0498 4.62524C8.44378 4.62527 7.84285 4.72921 7.27344 4.93286L7.03125 5.02661C6.4712 5.2586 5.95604 5.58525 5.50781 5.99146L5.32031 6.17017C4.89175 6.59872 4.5399 7.09711 4.28125 7.6438L4.17676 7.8811C3.91171 8.52098 3.77544 9.20707 3.77539 9.89966C3.77539 10.5924 3.91166 11.2792 4.17676 11.9192C4.44185 12.559 4.83061 13.1404 5.32031 13.6301L5.50781 13.8088C5.95604 14.215 6.47122 14.5417 7.03125 14.7737L7.27344 14.8665C7.84292 15.0702 8.4437 15.175 9.0498 15.175C10.4488 15.175 11.791 14.6194 12.7803 13.6301L12.96 13.4407C13.8363 12.473 14.3252 11.2114 14.3252 9.89966C14.3251 8.50087 13.7693 7.15931 12.7803 6.17017C11.791 5.18091 10.4488 4.62524 9.0498 4.62524ZM9.0498 5.27466C9.2023 5.27466 9.3492 5.33577 9.45703 5.4436L9.52832 5.53149C9.5907 5.62516 9.62496 5.73566 9.625 5.84985V10.3499C9.625 10.4643 9.5909 10.5754 9.52832 10.6692L9.45703 10.7571C9.3492 10.8649 9.2023 10.925 9.0498 10.925C8.93561 10.925 8.82511 10.8907 8.73145 10.8284L8.64355 10.7571C8.53572 10.6492 8.47461 10.5024 8.47461 10.3499V5.84985C8.47466 5.69743 8.53577 5.55139 8.64355 5.4436L8.73145 5.37134C8.82507 5.30904 8.93569 5.2747 9.0498 5.27466ZM13.9346 3.28638C13.9719 3.29419 14.0088 3.30544 14.0439 3.32056L14.1436 3.37524C14.1748 3.39684 14.2039 3.42199 14.2305 3.44946L14.2539 3.47388L15.5 4.71899L15.5732 4.80591C15.5948 4.83718 15.6138 4.87043 15.6289 4.90552L15.6631 5.01392C15.6709 5.05108 15.6754 5.08903 15.6758 5.1272L15.665 5.24048L15.6328 5.34985C15.6039 5.42052 15.5608 5.48532 15.5068 5.53931C15.453 5.59311 15.3888 5.63543 15.3184 5.66431C15.283 5.67876 15.2463 5.69034 15.209 5.69751L15.0957 5.70728C15.0577 5.70694 15.0195 5.70332 14.9824 5.69556L14.873 5.6604C14.8038 5.63057 14.7411 5.58748 14.6885 5.53345L13.416 4.26099V4.26001C13.3892 4.23391 13.3649 4.20569 13.3438 4.17505L13.2881 4.07544C13.2731 4.04046 13.2617 4.00411 13.2539 3.96704L13.2422 3.85376C13.2415 3.77748 13.2553 3.70172 13.2842 3.6311L13.3379 3.53052C13.3589 3.49892 13.3832 3.4696 13.4102 3.44263C13.4641 3.38872 13.5281 3.34556 13.5986 3.31665C13.6692 3.28779 13.7451 3.27308 13.8213 3.27368L13.9346 3.28638ZM10.8496 1.67505C11.0021 1.67505 11.149 1.73525 11.2568 1.84302L11.3281 1.93091C11.3907 2.02473 11.4248 2.13578 11.4248 2.25024C11.4248 2.36447 11.3905 2.47492 11.3281 2.5686L11.2568 2.65649C11.149 2.76433 11.0021 2.82544 10.8496 2.82544H7.25C7.13559 2.82544 7.02446 2.79132 6.93066 2.72876L6.84375 2.65649C6.73596 2.54871 6.67486 2.40267 6.6748 2.25024C6.6748 2.09774 6.73592 1.95085 6.84375 1.84302L6.93066 1.77173C7.02449 1.70909 7.13552 1.67505 7.25 1.67505H10.8496Z"
            fill="#414347" stroke="#414347" stroke-width="0.25"></path>
        </svg>
        <span class="test_timer">00 : 00</span>
        </div>
      </div>
            <div class="overflow-y-auto flex-1 p-6 space-y-4">
                <div class="p-4 w-full h-fit space-y-4 border shadow-sm rounded-md">
                    <div class="status-box">
                        <div class="count" id="visit">0</div>
                        <p>Not Visited</p>
                    </div>
                    <div class="status-box">
                        <div class="count" id="NotAnswersed">0</div>
                        <p>Not Answered</p>
                    </div>
                    <div class="status-box">
                        <div class="count" id="Answered">0</div>
                        <p>Answered</p>
                    </div>
                    <div class="status-box">
                        <div class="count" id="MarkforReview">0</div>
                        <p>Mark for Review</p>
                    </div>
                    <div class="status-box">
                        <div class="count" id="aAndm">0</div>
                        <p>Answered & Marked for Review</p>
                    </div>
                </div>
             <div id="QueBoxes" class="w-full py-4 grid grid-cols-[repeat(auto-fit,minmax(3rem,1fr))] gap-4 relative" style="place-items: center;">
                    <!-- All Boxes Show here by JavaScript -->
                </div>
            </div>
            <div class="flex w-full h-fit p-4 gap-3 border-t-2">
                <button id="goToLeave" class="flex-1 btn-secondary rounded-md">Exit</button>
                <button class="openSubmitPage flex-1 btn-primary rounded-md">Submit</button>
            </div>
        </div>
        <main class="flex-1 pt-3 overflow-hidden">
            <div class="max-w-[50rem] h-full overflow-y-auto p-6 pt-3 bg-white space-y-3" id="que_display_area">
            <div class="space-y-3">
                    <div class="flex items-center gap-3">
                        <div id="que_number" class="bg-[#454545] rounded-full w-8 aspect-square flex items-center justify-center text-lg font-semibold text-[#fbfbfb]">1</div>
                        <div id="que_marks" class="text-secondary bg-[#fbfbfb] rounded-md border border-[#b8b8b8] font-medium px-2.5 py-1">Marks: <span class="text-green-600 font-semibold">+4</span> <span class="text-red-600 font-semibold">-1</span></div>
                        <div id= "que_type" class="text-secondary bg-[#fbfbfb] rounded-md border border-[#b8b8b8] font-medium px-2.5 py-1">Type: MCQ</div>
                    </div>
                    <div id="question_loader" class="w-full h-36 flex items-center justify-center">
                         <div class="inline-block animate-spin rounded-full h-12 w-12 loader"></div>
                    </div>
                    <div class="question_frame space-y-2 hidden" id="q_main_area">
                        <p id="question_text" class="font-medium"></p>
                        <div id="queImg_box" class="relative rounded-md overflow-hidden">
                            <img src='' class="w-full aspect-video object-cover" alt="Question_Image" id="queImage">
                            <span id="fullImg_icon" class="absolute bottom-2 right-2 p-2 w-8 h-8 rounded-md bg-white/40 text-gray-800">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M32 32C14.3 32 0 46.3 0 64l0 96c0 17.7 14.3 32 32 32s32-14.3 32-32l0-64 64 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 32zM64 352c0-17.7-14.3-32-32-32S0 334.3 0 352l0 96c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0 0-64zM320 32c-17.7 0-32 14.3-32 32s14.3 32 32 32l64 0 0 64c0 17.7 14.3 32 32 32s32-14.3 32-32l0-96c0-17.7-14.3-32-32-32l-96 0zM448 352c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 64-64 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l96 0c17.7 0 32-14.3 32-32l0-96z"/></svg>
                            </span>
                         </div>
                         <div id="textOptions"></div>
                     </div>
                </div>
                <div class="flex gap-2 justify-center items-center font-medium text-lg">
                    <label for="reviewCheckbox" id="markText">Mark for Review</label>
                    <input type="checkbox" id="reviewCheckbox" class="accent-primary">
                </div>
            <div class="inputAns flex flex-col w-full gap-[1px] pt-4">
                <div class="w-full h-[3rem] border rounded-sm relative border-[#454545]">
                    <label class="bg-white absolute top-[-12px] left-[20px] font-semibold text-sm text-primary">Your Answer</label>
                    <input id="answerInput" placeholder="Type Your Answer..." autocomplete="off" spellcheck = "false" type="number" class="text-secondary font-semibold bg-transparent w-full h-full px-4 focus:outline-none">
                </div>
                  <p class="font-medium text-[#373737] text-sm">*Only Numeric Value</p>
           </div>
                <div class="optionsSection space-y-4"></div>
                </div>
            </main>
            <div class="flex w-full h-fit justify-between items-center p-4 gap-3 border-t-2">
                <button id="preQueBtn" class="w-fit btn-secondary rounded-md px-3 py-2">Previous</button>
                <button id="nextQueBtn" class="w-fit btn-primary rounded-md px-3 py-2">Save & Next</button>
             </div>
    </section>
    <div id="toastBottom" class="hidden" style="transform: translateX(-50%);width:max-content;"></div>
`
}
export function init(params, box) {
    const getEle = id => document.getElementById(id)
    const qs = query => document.querySelector(query)
    const qsAll = query => document.querySelectorAll(query)
    getEle('modalTopBar').classList.add('hidden')
    let loader_text = getEle('test_loader')
    let loaderInterval;
    let dot = 0
    loaderInterval = box.setInterval(() => {
        let dots = (dot + 1) % 4
        dot++
        loader_text.innerText = `Preparing Your Test${'.'.repeat(dots)}`
    }, 500)
    const stopLoader = () => {
        box.setTimeout(() => {
            clearInterval(loaderInterval)
            qs('.loaderPage').style.display = 'none';
        }, 1000)
    }
    //* Document Elements
    const timerText = qsAll('.test_timer')
    const question_loader = getEle('question_loader')
    const que_main_area = getEle('q_main_area')
    const que_display_area = getEle('que_display_area')
    const questionText = getEle('question_text')
    const queNumber = getEle("que_number")
    const Q_marks = getEle('que_marks')
    const Q_type = getEle('que_type')
    const Q_boxes = getEle('QueBoxes')
    const Q_Img = getEle('queImg_box')
    const queImage = getEle("queImage")
    const reviewBtn = getEle('reviewCheckbox')
    const markText = getEle("markText")
    const answerInputDiv = qs('.inputAns')
    const answerInput = getEle('answerInput')
    const textOptions = getEle('textOptions')
    const option_selection_box = qs('.optionsSection')
    //* Variables
    const testId = params.testId;
    let testMeta;
    let attemptId
    let totalQuestions;
    let duration;
    let timeGap;
    let notVisitedQuestions;
    let currentIndex = 0;
    let timeSpent = {}
    let focusGuard = {}
    let awayTime = 0
    let tabSwitchCount = 0
    let questionStartTime = null
    let isQuestionShown = false
    let questionIds = []
    let userAnswers = {}
    let questionsCache = {}
    let answersList = []
    let reviewList = []
    let answeredAndMarkedList = []
    let syncInterval = null
    let SYNC_INTERVAL_TIME;
    function currentQuestionId() { return questionIds[currentIndex] }
    const displayMessage = (tittle, description, type = "ok") => {
        display.open(`
            <div class="bg-[#fbfbfb] flex flex-col justify-center items-center rounded-lg w-full h-full gap-2 p-6">
                <h3 class="text-4xl font-semibold text-center leading-[1.5]">${tittle}</h3>
                <p class="text-center text-lg font-medium">${description}</p>
                <button class="mt-2 btn-primary" onclick="${type == "back" ? "history.back()" : (type == 'submit' ? `location.replace('/results/${testId}')` : "display.close()")}">
                 ${type == "back" ? "BACK" : (type == 'submit' ? " View Result " : "Okay")}
                 </button>
            </div>
            `)
    }
    const startTest = async () => {
        const res = await fetchData(`/tests/${testId}/start-test${location.search}`)
        if (!res || !res.success) {
            displayMessage(res?.type || "❌ <br>Error", res?.message || "Something went wrong", res?.submitted == true ? "submit" : "back");
            return
        }
        setAllVariables(res.data)
        initializeTest()
    }
    function setAllVariables(data) {
        timeGap = Date.now() - data.serverTime
        testMeta = data.testMeta
        document.title = testMeta.title
        attemptId = data.attemptId
        SYNC_INTERVAL_TIME = data.attemptSyncInterval
        questionIds = data.questionIds
        userAnswers = data.userAnswers
        timeSpent = data.timeSpent
        focusGuard = data.focusGuard
        awayTime = data.awayTime
        tabSwitchCount = data.tabSwitchCount
    }
    const initializeTest = () => {
        totalQuestions = questionIds.length
        duration = (testMeta.duration) * 60; // In Seconds
        notVisitedQuestions = totalQuestions;
        questionIds.forEach((id, index) => {
            if (userAnswers[id]?.value != null) {
                answersList.push(index)
            }
        })
        for (let i = 0; i < totalQuestions; i++) {
            let box = document.createElement('div')
            box.className = 'box';
            if (answersList.includes(i)) { box.classList.add('visited') }
            box.id = `box-${i}`;
            box.innerHTML = i + 1;
            Q_boxes.append(box);
        }
        updateBoxColor()
        renderQuestion(currentIndex)
        startSyncInterval()
        timer()
        stopLoader()
    }

    async function loadQuestion(index) {
        const questionId = questionIds[index]
        if (questionsCache[questionId]) return questionsCache[questionId]
        const resp = await fetchData(`/attempts/${attemptId}/questions/${questionId}`)
        if (!resp || !resp.success) {
            toastBottom(resp?.message || "Fail to load question")
            return null
        }
        questionsCache[questionId] = resp.data
        return resp.data
    }
    async function preloadQuestion(index) {
        if (index == totalQuestions - 1) return
        await loadQuestion(index + 1)
        if (index == 0) return
        await loadQuestion(index - 1)
    }
    function showQueLoader() {
        question_loader.classList.remove("hidden")
        que_main_area.classList.add("hidden")
    }
    function hideQueLoader() {
        question_loader.classList.add("hidden")
        que_main_area.classList.remove("hidden")
    }
    const renderQuestion = async (qIndex) => {
        queNumber.innerHTML = qIndex + 1
        showQueLoader()
        questionText.innerHTML = ""
        // Remove previous question data
        Q_Img.classList.add('hidden')
        textOptions.innerHTML = ""
        answerInputDiv.style.display = 'none'
        option_selection_box.classList.add("hidden")
        let newQuestion = await loadQuestion(qIndex)
        if (!newQuestion) return
        let { text, options, positiveMarks, negativeMarks, type, image } = newQuestion;
        questionText.innerHTML = text.replaceAll(/[\n\r]/g, "<br>")
        if (image.hasImage) {
            queImage.src = image.imageUrl
            Q_Img.classList.remove('hidden')
        }
        if (type == "mcq") {
            option_selection_box.classList.remove('hidden')
            showOptions(options)
        }
        else {
            answerInput.value = ""
            answerInputDiv.style.display = 'flex'
        }
        Q_type.innerHTML = `Type: ${type == "mcq" ? "MCQ" : "Numeric"}`
        Q_marks.innerHTML = `Marks: <span class="text-green-600 font-semibold">+${positiveMarks}</span> <span class="text-red-600 font-semibold">${parseInt(-negativeMarks)}</span>`
        showOldSelectedAnswer()
        hideQueLoader()
        que_display_area.scrollTop = 0
        questionStartTime = Date.now()
        isQuestionShown = true
        Q_box_border()
        preloadQuestion(qIndex)
    }
    function showOptions(options) {
        textOptions.innerHTML = options.map((o, i) => {
            return o ? `
                  <div class="font-medium">${String.fromCharCode(65 + i)}) ${o.replace(/\r?\n/g, "<br>")}</div>
                  `: ""
        }).join("")
        option_selection_box.innerHTML = options.map((_, i) => {
            return `    <div class="option" data-option="${i}">
                        <p>${i + 1}</p>
                        <span>${String.fromCharCode(65 + i)}</span>
                    </div>`
        }).join("")
    }
    const updateBoxColor = () => {
        getEle('Answered').innerText = answersList.length;
        getEle('MarkforReview').innerText = reviewList.length;
        getEle('aAndm').innerText = answeredAndMarkedList.length;
        getEle('NotAnswersed').innerText = totalQuestions - (notVisitedQuestions + answersList.length + reviewList.length + answeredAndMarkedList.length);
        const boxes = Q_boxes.querySelectorAll('.box')
        boxes.forEach((e, i) => {
            e.classList.remove('answered');
            e.classList.remove('marked');
            e.classList.remove('ansAndMarked');
            if (answersList.includes(i)) {
                e.classList.add('answered')
            }
            else if (reviewList.includes(i)) {
                e.classList.add('marked')
            }
            else if (answeredAndMarkedList.includes(i)) {
                e.classList.add('ansAndMarked')
            }
        })
        change_box_color()
    }

    const updateAnswersList = (s) => {
        if (s == 1) {
            if (!answersList.includes(currentIndex)) {
                if (reviewList.includes(currentIndex)) {
                    answeredAndMarkedList.push(currentIndex)
                    let i = reviewList.indexOf(currentIndex)
                    reviewList.splice(i, 1)
                }
                else if (!answeredAndMarkedList.includes(currentIndex)) {
                    answersList.push(currentIndex)
                }
            }
        }
        else if (s == 0) {
            if (answeredAndMarkedList.includes(currentIndex)) {
                reviewList.push(currentIndex)
                let i = answeredAndMarkedList.indexOf(currentIndex)
                answeredAndMarkedList.splice(i, 1)
            }
            else {
                let i = answersList.indexOf(currentIndex)
                answersList.splice(i, 1)
            }
        }
        updateBoxColor()
    }

    box.addEvent(reviewBtn, 'change', () => {
        if (!reviewBtn.checked) {
            markText.innerText = "Mark for Review"
            if (answeredAndMarkedList.includes(currentIndex)) {
                answersList.push(currentIndex)
                let i = answeredAndMarkedList.indexOf(currentIndex)
                answeredAndMarkedList.splice(i, 1)
            }
            else {
                let i = reviewList.indexOf(currentIndex)
                reviewList.splice(i, 1)
            }
        }
        else {
            markText.innerText = "Marked for Review";
            toastBottom('Marked for Review')
            if (answersList.includes(currentIndex)) {
                answeredAndMarkedList.push(currentIndex);
                let i = answersList.indexOf(currentIndex)
                answersList.splice(i, 1)
            }
            else {
                reviewList.push(currentIndex)
            }
        }
        updateBoxColor()
    })

    function timer() {
        const endTime = testMeta.endTime;
        const timerInterval = box.setInterval(() => {
            const now = Date.now() + timeGap;
            const remaining = Math.floor((endTime - now) / 1000); // in Seconds
            if (remaining <= 0) {
                clearInterval(timerInterval);
                timerText.forEach(t => t.innerHTML = "00:00");
                submitTest('timeout');
                displayMessage('⌛<br>Opp\'s Times Up', "The allotted time has ended and your test has been <b> auto-submitted <b> ", "submit")
                return;
            }
            if (remaining < 600) {
                timerText.forEach(t => {
                    t.style.color = 'rgb(185,28,28)' // Red color
                })
            }
            let hrs = Math.floor(remaining / 3600);
            let mins = Math.floor((remaining % 3600) / 60);
            let secs = remaining % 60;
            let display;
            if (hrs > 0) {
                hrs = hrs < 10 ? `0${hrs}` : hrs;
                mins = mins < 10 ? `0${mins}` : mins;
                secs = secs < 10 ? `0${secs}` : secs;
                display = `${hrs}:${mins}:${secs}`;
            } else {
                mins = mins < 10 ? `0${mins}` : mins;
                secs = secs < 10 ? `0${secs}` : secs;
                display = `${mins}:${secs}`;
            }
            timerText.forEach(t => {
                t.innerHTML = display;
            });
        }, 1000);
    }

    function change_box_color() {
        let boxes = Q_boxes.querySelectorAll('.box')
        boxes.forEach((b, i) => {
            if (i !== currentIndex) {
                b.style.border = null
            }
            else {
                if (b.classList.contains('answered')) {
                    b.style.border = '2px solid rgb(22 163 74)'
                }
                else if (b.classList.contains('marked')) {
                    b.style.border = '2px solid rgb(79 70 229)'
                }
                else if (b.classList.contains('ansAndMarked')) {
                    b.style.border = '2px solid rgb(202 138 4)'
                }
                else {
                    b.style.border = '2px solid rgb(220 38 38)'
                }
            }
        })
    }
    function Q_box_border() {
        let boxes = Q_boxes.querySelectorAll('.box')
        boxes.forEach((b, i) => {
            if (i !== currentIndex) {
                b.style.border = null
            }
            else {
                if (!b.classList.contains('visited')) {
                    b.style.border = '2px solid rgb(220 38 38)'
                    notVisitedQuestions--;
                    getEle('visit').innerText = notVisitedQuestions
                    getEle('NotAnswersed').innerText = totalQuestions - (notVisitedQuestions + answersList.length + reviewList.length + answeredAndMarkedList.length);
                    b.classList.add('visited')
                }
                else {
                    change_box_color()
                }
            }
        })
    }
    box.addEvent(Q_boxes, 'click', (e) => {
        if (e.target.classList.contains('box')) {
            let boxId = e.target.id.split('-')
            captureTimeSpent()
            currentIndex = parseInt(boxId[1])
            renderQuestion(currentIndex);
            qs('#gridViewBtn').checked = false;
        }
    })
    box.addEvent(getEle("preQueBtn"), "click", previousQuestion)
    box.addEvent(getEle("nextQueBtn"), "click", nextQuestion)
    box.addEvent(option_selection_box, "click", (e) => {
        if (e.target.closest('div').classList.contains("option")) {
            showSelectedOption(e.target.closest('div'))
        }
    })
    box.addEvent(answerInput, "input", () => {
        let ans = answerInput.value;
        if (ans == "") {
            saveAnswer(null)
            updateAnswersList(0)
        }
        else {
            saveAnswer(ans)
            updateAnswersList(1)
        }
    })
    const captureTimeSpent = () => {
        if (!isQuestionShown) return
        if (timeSpent[currentQuestionId()] != null) {
            timeSpent[currentQuestionId()] += Date.now() - questionStartTime
        }
        else {
            timeSpent[currentQuestionId()] = Date.now() - questionStartTime
        }
        isQuestionShown = false
    }
    const saveAnswer = (value) => {
        let newAns = {
            value: value == null ? null : Number(value),
            ts: Date.now()
        }
        userAnswers[currentQuestionId()] = newAns;
        updateAnswersList(1)
    }
    const showSelectedOption = (e) => {
        if (e.classList.contains('marked')) {
            e.classList.remove('marked')
            saveAnswer(null)
            updateAnswersList(0)
        }
        else {
            qsAll('.option').forEach(d => {
                d.classList.remove('marked')
            })
            e.classList.add('marked')
            const selectOptionIndex = e.dataset.option
            saveAnswer(selectOptionIndex)
        }
    }
    function nextQuestion() {
        if (currentIndex !== totalQuestions - 1) {
            captureTimeSpent()
            currentIndex += 1
            renderQuestion(currentIndex);
        }
        else {
            toastBottom('This is the last Question', 'normal', 1500)
        }
    }
    function previousQuestion() {
        if (currentIndex != 0) {
            captureTimeSpent()
            currentIndex -= 1
            renderQuestion(currentIndex);
        }
    }
    const showOldSelectedAnswer = () => {
        if (questionsCache[currentQuestionId()]?.type == "mcq") {
            qsAll('.option').forEach(d => {
                d.classList.remove('marked')
            })
            if (userAnswers[currentQuestionId()]?.value != null) {
                qs(`[data-option="${userAnswers[currentQuestionId()].value}"]`).classList.add('marked')
            }
        }
        else {
            answerInput.value = userAnswers[currentQuestionId()]?.value ?? ""
        }
        updateReviewBtn();
    }
    //     Full Image System
    box.addEvent(getEle('fullImg_icon'), 'click', () => {
        const curImage = questionsCache[currentQuestionId()].image.imageUrl
        display.open(`
            <div class="relative p-4 flex items-center justify-center w-full h-full" style="touch-action:pinch-zoom;">
            <div class="absolute top-6 right-4 w-10 h-10 p-2 flex items-center justify-center bg-white/50 rounded-full" onclick="display.close()">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M55.1 73.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L147.2 256 9.9 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192.5 301.3 329.9 438.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.8 256 375.1 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192.5 210.7 55.1 73.4z"/></svg>
            </div>
            <img src="${curImage}" class="rounded-lg" alt="Question_Image_ERROR_NOT_LOAD">
            </div>
            `)
    })
    function updateReviewBtn() {
        if (reviewList.includes(currentIndex) || answeredAndMarkedList.includes(currentIndex)) {
            reviewBtn.checked = true;
            markText.innerText = "Marked for Review"
        }
        else {
            reviewBtn.checked = false;
            markText.innerText = "Mark for Review"
        }
    }
    const submitPage = (t) => {
        let checkbox = getEle('Submit-checkbox');
        if (t == 1) {
            checkbox.checked = true;
            getEle('attemptTestTitle').innerText = document.title;
            getEle('visit2').innerText = notVisitedQuestions
            getEle('Answered2').innerText = answersList.length;
            getEle('totalQ').innerText = totalQuestions;
            getEle('MarkforReview2').innerText = reviewList.length;
            getEle('aAndm2').innerText = answeredAndMarkedList.length;
            getEle('NotAnswersed2').innerText = totalQuestions - (notVisitedQuestions + answersList.length + reviewList.length + answeredAndMarkedList.length);
        }
        else if (t == 0) {
            checkbox.checked = false;
        }
    }
    const goToSubmit = () => {
        getEle("Submit-checkbox").checked = false
        popUp.show(`
            <div class="flex flex-col items-center justify-center p-2 gap-4"> 
            <h3 class="text-2xl font-semibold">Submit Test?</h3>
            <p class="font-medium text-center">Are you sure you want to submit the test?<br>
                No changes will be allowed <br>after submission
            </p>
            <div class="w-full flex gap-6">
                <button id="userSubmitBtn" class="flex-1 btn-primary rounded-md">Submit</button>
                <button onclick="popUp.hide()" class="flex-1 btn-secondary rounded-md">Resume</button>
            </div>
        </div>`)
        box.setTimeout(() => {
            getEle("userSubmitBtn").addEventListener('click', () => { userSubmit() })
        }, 100)
    }
    function userSubmit() {
        popUp.hide()
        submitTest('submitted')
    }
    function formatTime(time) {
        let date = new Date(time)
        let timeString = date.toLocaleTimeString("en-us", {
            hour: "numeric", minute: "numeric", hour12: true
        })
        return timeString
    }
    const goToLeave = () => {
        getEle('gridViewBtn').checked = false
        popUp.show(`
            <div class="flex flex-col items-center justify-center p-2 gap-4"> 
            <h3 class="text-2xl font-semibold">Heads up!</h3>
            <p class="font-medium text-center">Leaving the test now will trigger auto submit if you dont return before the <b> ${formatTime(testMeta.endTime)}.</b>Want to exit anyway?</p>
            <div class="w-full flex gap-6">
                <button onclick="leaveTest()" class="flex-1 btn-primary rounded-md">Exit</button>
                <button onclick="popUp.hide()" class="flex-1 btn-secondary rounded-md">Resume</button>
            </div>
        </div>`)
    }
    let toastQueue = []
    let isToastShowing = false
    const toastBottom = (text, type = "normal", duration = 1500) => {
        toastQueue.push({ text, type, duration })
        processToastQueue()
    }
    const processToastQueue = () => {
        if (isToastShowing || toastQueue.length === 0) return
        const { text, type, duration } = toastQueue.shift()
        const toastBox = getEle('toastBottom')
        isToastShowing = true
        toastBox.innerHTML = `<p class="font-medium tracking-[0.5px] text-lg">${text}</p>`
        toastBox.className = "show h-12 p-3 shadow-lg fixed bottom-[120px] left-1/2 flex items-center justify-center rounded z-[50] " + type
        box.setTimeout(() => {
            toastBox.className = 'hidden'
            box.setTimeout(() => {
                isToastShowing = false
                processToastQueue()
            }, 50)
        }, duration)
    }
    function leaveTest() {
        syncAnswers()
        box.setTimeout(() => {
            window.location.replace('/')
        }, 100)
    }
    const submitTest = async (status = "submitted") => {
        captureTimeSpent()
        if (awayTime > Date.now()) {
            awayTime -= Date.now()
        }
        stopSyncInterval()
        let finalPayload = {
            status,
            userAnswers,
            timeSpent,
            awayTime,
            tabSwitchCount,
            clientTime: Date.now()
        }
        const res = await fetchData(`/attempts/${attemptId}/submit-test`, "POST", { ...finalPayload })
        if (!res || !res.success) {
            toastBottom('Failed to submit test', "error")
            questionStartTime = Date.now()
            startSyncInterval()
            return
        }
        attemptId = null
        questionsCache = {}
        userAnswers = {}
        questionIds = []
        if (status == "submitted") {
            displayMessage("📑", "Test has been submitted", "submit")
        }
    }
    //------------  Tab switch detected ---------------- //
    let isAway = false;
    let awayStart = null;
    function handleAwayStart() {
        if (!isAway) {
            isAway = true
            awayStart = Date.now()
        }
        if (!attemptId) return
        if (focusGuard.enabled) {
            displayMessage('🚫Warning', 'You are trying to switch tab or minimize test avoid this otherwise test will be auto submitted.')
        }
    }
    function handleAwayEnd() {
        if (isAway) {
            awayTime += Date.now() - awayStart
            isAway = false
            awayStart = null
        }
        if (!attemptId) return
        if (focusGuard.enabled) {
            if (tabSwitchCount >= focusGuard.maxTabSwitch) {
                displayMessage("🕵 <br> Fired", 'You are switching tabs too many times <br> test is <b> auto-submitted <b>', "submit")
                submitTest("fired")
                return
            }
            if (awayTime >= focusGuard.maxAwayTime) {
                displayMessage("🕵 <br> Fired", 'You away too long from test! <br> test is <b>auto-submitted <b>', "submit")
                submitTest("fired")
            }
        }
    }
    function syncAnswers() {
        if (!attemptId) return
        let syncData = {
            userAnswers,
            timeSpent,
            awayTime,
            tabSwitchCount,
            clientTime: Date.now()
        }
        fetchData(`/attempts/${attemptId}/sync`, "POST", syncData)
    }
    function trySync() {
        if (navigator.onLine) {
            startSyncInterval()
            return
        }
        stopSyncInterval()
    }
    const startSyncInterval = () => {
        if (syncInterval) return
        syncInterval = box.setInterval(() => {
            syncAnswers()
        }, SYNC_INTERVAL_TIME)
    }
    box.setInterval(() => {
        trySync()
    }, 10000)
    function stopSyncInterval() {
        clearInterval(syncInterval)
        syncInterval = null
    }
    function initApp() {
        window.leaveTest = leaveTest
        window.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                captureTimeSpent()
                handleAwayStart()
                stopSyncInterval()
                syncAnswers()
            }
            else {
                handleAwayEnd()
                tabSwitchCount++
                stopSyncInterval()
                syncAnswers()
                questionStartTime = Date.now()
                isQuestionShown = true
            }
        })
        box.addEvent(window, 'blur', () => {
            stopSyncInterval()
            syncAnswers()
            tabSwitchCount++
            handleAwayStart()
        })
        box.addEvent(window, 'focus', () => {
            handleAwayEnd()
            stopSyncInterval()
            syncAnswers()
        })
        box.addEvent(window, "offline", () => {
            toastBottom('Internet connection lost', "error", 3000)
            stopSyncInterval()
        })
        box.addEvent(window, "online", () => {
            toastBottom('Internet connection back', "success")
            syncAnswers()
            startSyncInterval()
        })
        box.addEvent(window, "beforeunload", () => {
            handleAwayEnd()
            stopSyncInterval()
            syncAnswers()
        })
        box.addEvent(window, "app_page_change", () => {
            handleAwayEnd()
            stopSyncInterval()
            syncAnswers()
        })
        box.addEvent(window, 'keydown', (e) => {
            if (e.key == 'ArrowLeft') {
                previousQuestion()
            }
            else if (e.key == "ArrowRight") {
                nextQuestion()
            }
        })
        qsAll('.openSubmitPage').forEach(btn => { btn.addEventListener('click', () => { submitPage(1) }) })
        getEle('goToLeave').addEventListener('click', () => { goToLeave() })
        getEle('goToSubmit').addEventListener('click', () => { goToSubmit() })
        getEle('resumeTest').addEventListener('click', () => { submitPage(0) })
        startTest()
    }
    initApp()
}