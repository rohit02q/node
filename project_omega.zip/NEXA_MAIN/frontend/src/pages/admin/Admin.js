export function Admin(){
return '<div class="w-full h-full flex justify-center items-center text-blue-800 text-xl font-semibold">Admin Page</div>'
}
export function init(params){
initNavBar()
}