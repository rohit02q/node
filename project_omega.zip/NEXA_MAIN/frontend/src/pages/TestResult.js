export async function TestResult(params) {
    return `
    <style>
    
.performance-comp table {
    width: 100%;
    border-collapse: separate;
    text-align: center;
    font-weight: 600;
    border-spacing: 10px 0;
}

.performance-comp th {
    font-weight: 600;
}

.performance-comp th div span {
    font-size: 12px;
    font-weight: normal;
}

.performance-comp td {
    padding: 10px 0;
}

.performance-comp td:nth-child(2),
.performance-comp th:nth-child(2) {
    background-color: #fff6e5;
}

.performance-comp td:nth-child(3),
.performance-comp th:nth-child(3) {
    background-color: #ddebf8;
}

.performance-comp tr:first-child th {
    border-radius: 5px 5px 0 0;
}

.performance-comp tr:last-child td {
    border-radius: 0 0 5px 5px;
}

.leaderboard-cards {
    overflow-x: hidden;
    overflow-y: auto;
    -ms-overflow-style: none;
    scrollbar-width: none;
}

.leaderboard-cards::-webkit-scrollbar {
    display: none;
}

    </style>
       <div id="resultPage-loader" class="flex items-center justify-center h-full">
            <div class="text-center">
                <div class="inline-block animate-spin rounded-full h-12 w-12 loader"></div>
                <p class="mt-4 text-gray-500">Loading...</p>
            </div>
        </div>
    <section id="resultPage" class="hidden fixed w-full min-h-full inset-0 bg-white overflow-y-auto" style="--bar-clr: #3093ca;">
        <nav class="w-full h-auto shadow fixed top-0 z-[5] flex justify-between items-center bg-white p-2 pr-4">
            <svg class="w-6 h-6"  fill="none" stroke="#454545" viewBox="0 0 24 24" onclick="history.back()">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" /></path>
            </svg>
            <div class="view-btn flex gap-4">
                <div class="flex items-center space-x-1 border rounded-3xl p-1 px-2 cursor-pointer" id="attempt-selector">
                    <span class="text-xl" id="cur-atm"> Attempt 1</span>
                    <svg class="w-4 h-4 rotate-[90deg]" fill="black" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7 Z">
                        </path>
                    </svg>
                </div>
            </div>
        </nav>
        <div class="w-full h-auto p-4 pt-[4.5rem]">
            <div class="test-meta-card flex flex-col w-full h-auto px-4 pt-4 pb-6 rounded-xl"
                style="background:radial-gradient(circle at center,#fff,#f3e8ff);">
                <h3 class="test-meta-title mb-2 font-semibold"> Test Title </h3>
                    <div class="flex gap-1 items-center mb-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                    class="w-4 h-4 text-indigo-400">
                                    <path fill="currentColor"
                                        d="M133.8 36.3c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 158 47 153L7 113C-2.3 103.6-2.3 88.4 7 79S31.6 69.7 41 79l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zm0 160c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 318 47 313L7 273c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zM224 96c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zm0 160c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zM160 416c0-17.7 14.3-32 32-32l288 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-288 0c-17.7 0-32-14.3-32-32zM64 376a40 40 0 1 1 0 80 40 40 0 1 1 0-80z" />
                                </svg>
                                <span class="text-gray-900 text-sm test-meta-info font-medium"></span>
                            </div>
                     <div class="flex gap-1 items-center mb-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"
                                    class="w-4 h-4 text-indigo-400">
                                    <path fill="currentColor"
                                        d="M128 0c17.7 0 32 14.3 32 32l0 32 128 0 0-32c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-32c0-17.7 14.3-32 32-32zM64 240l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm128 0l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM64 368l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zm112 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16z" />
                                </svg>
                                <span class="text-gray-900 attempt-date text-sm font-medium">Attempted on:</span>
                            </div>
                     <div class="flex gap-1 items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-indigo-400" viewBox="0 0 512 512"><path fill="currentColor" d="M256 0a256 256 0 1 1 0 512 256 256 0 1 1 0-512zM232 120l0 136c0 8 4 15.5 10.7 20l96 64c11 7.4 25.9 4.4 33.3-6.7s4.4-25.9-6.7-33.3L280 243.2 280 120c0-13.3-10.7-24-24-24s-24 10.7-24 24z"/></svg>
                                <span class="text-gray-900 attempt-time text-sm font-medium">Attempted on:</span>
                            </div>
                <div class="flex mt-4 gap-4">
                    <button
                        class="w-fit px-3 py-2 bg-white rounded-lg text-primary border-[1px] border-primary font-[600]"
                        onclick="goToReattempt()">Reattempt</button>
                    <button class="solutions-btn w-fit bg-primary px-3 py-2 rounded-lg text-white font-[600]">View
                        Solutions</button>
                </div>
            </div>
        </div>
        <div class="mb-4 mt-2 pl-4 w-fit">
            <div class="section-btn px-3 py-2 flex gap-2 rounded-xl bg-[#F1F5FE]">
                <button class="section-result-btn text-md font-semibold px-3 py-2 rounded-lg bg-white text-primary">Result
                    Summary</button>
                <button class="section-leaderboard-btn text-md font-semibold px-3 py-2 rounded-lg text-gray-600">Leaderboard</button>
            </div>
        </div>
        <div class="result-section flex flex-col items-center py-2 bg-[#F1F5FE]">
            <h3 class="text-xl font-semibold mb-1">Your Progress</h3>
            <div class='flex w-full h-auto px-2 py-3 justify-center items-center'>
                <div class='circle w-[10rem] h-[10rem] rounded-full relative flex justify-center items-center before:content-[""] before:absolute before:w-[9rem] before:h-[9rem] before:bg-white before:rounded-full' style="background:conic-gradient(var(--bar-clr) 0%, #e5e7eb 0)">
                    <p class="text-primary absolute text-2xl font-semibold">0/0</p>
                </div>
            </div>

            <div class="w-full h-auto px-4 mb-2">
                <div class="border py-2 px-1 rounded-xl bg-white flex items-center justify-evenly w-full">
                    <div class="flex items-center flex-col gap-3">
                        <p class="text-xl font-semibold text-green-800">SCORE</p>
                        <span class="text-lg font-medium percent-score">0%</span>
                    </div>
                    <img src="/assets/icons/scoring.png" alt="icon" width="64" height="auto">
                    <div class="flex items-center flex-col gap-3">
                        <p class="text-xl font-semibold text-yellow-800">RANK</p>
                        <span class="rank-text text-lg font-medium">--</span>
                    </div>
                </div>
            </div>
            <div class="w-full flex flex-col gap-4 p-4">
                <div class="w-full h-auto bg-white flex flex-col gap-1 rounded-xl px-3 py-2">
                    <div class="flex justify-between">
                        <div class="flex items-center gap-[2px]">
                            <img src="/assets/icons/correct.png" alt="Correct png" width="15" height="auto">
                            <p class="font-semibold">Correct</p>
                        </div>
                        <p class="type-count" id="correctQuestionsCount">0/0</p>
                    </div>
                    <div class="w-full rounded-lg bg-[#e5e7eb] overflow-hidden">
                        <div class="bar h-[5px]" style="width: 0%;border-radius: 15px 0 0 15px;background: linear-gradient(to right, #74b1e0, var(--bar-clr));" id="correctQuestionsBar"></div>
                    </div>
                    <div class="flex justify-between">
                        <p class="info-name">Marks Obtained</p>
                        <p class="info-count text-green-600 font-bold" id="marksObtained">+0</p>
                    </div>
                </div>
          <div class="w-full h-auto bg-white flex flex-col gap-1 rounded-xl px-3 py-2">
                    <div class="flex justify-between">
                        <div class="flex items-center gap-[2px]">
                            <img src="/assets/icons/incorrect.png" alt="Incorrect png" width="15" height="auto">
                            <p class="font-semibold">Incorrect</p>
                        </div>
                        <p class="type-count" id="incorrectQuestionsCount">0/0</p>
                    </div>
                    <div class="w-full rounded-lg bg-[#e5e7eb] overflow-hidden">
                        <div class="bar h-[5px]" style="width: 0%;border-radius: 15px 0 0 15px;background: linear-gradient(to right, #74b1e0, var(--bar-clr));"  id="incorrectQuestionsBar"></div>
                    </div>
                    <div class="flex justify-between">
                        <p class="info-name">Marks lost</p>
                        <p class="info-count text-red-600 font-bold" id="marksLost">-0</p>
                    </div>
                </div>
            <div class="w-full h-auto bg-white flex flex-col gap-1 rounded-xl px-3 py-2">
                    <div class="flex justify-between">
                        <div class="flex items-center gap-[2px]">
                            <img src="/assets/icons/skip.png" alt="Skipped png" width="15" height="auto">
                            <p class="font-semibold">Skipped</p>
                        </div>
                        <p class="type-count" id="skippedQuestionsCount">0/0</p>
                    </div>
                    <div class="w-full rounded-lg bg-[#e5e7eb] overflow-hidden">
            <div class="bar h-[5px]" style="width: 0%;border-radius: 15px 0 0 15px;background: linear-gradient(to right, #74b1e0, var(--bar-clr));" id="skippedQuestionsBar"></div>
                    </div>
                    <div class="flex justify-between">
                        <p class="info-name">Marks Skipped</p>
                        <p class="info-count font-bold text-gray-600" id="marksSkipped">0</p>
                    </div>
                </div>
            </div>
            <div class="w-full h-auto mt-1 px-4 py-2 flex items-center gap-2">
                <div class="flex-1 h-auto bg-white p-4 rounded-xl">
                    <img src="/assets/icons/accuracy.png" alt="icon" width="15" height="auto" class="mb-1.5">
                    <p class="text-lg mb-2 font-semibold">Accuracy</p>
                    <span class="text-lg font-medium accuracy">0%</span>
                </div>
                <div class="flex-1 h-auto bg-white p-4 rounded-xl">
                    <img src="/assets/icons/complete.png" alt="icon" width="15" height="auto" class="mb-1.5">
                    <p class="text-lg mb-2 font-semibold">Complete</p>
                    <span class="text-lg font-medium complete">0%</span>
                </div>
                <div class="flex-1 h-auto bg-white p-4 rounded-xl">
                    <img src="/assets/icons/time.png" alt="icon" width="15" height="auto" class="mb-1.5">
                    <p class="text-md mb-2 font-semibold">Time Taken</p>
                    <span class="text-lg font-medium time-taken">00<span class="mx-1">:</span>00</span>
                </div>
            </div>
            <div class="performance-comp w-full h-auto flex flex-col items-center p-4">
                <h3 class="text-xl font-semibold mb-4"> Performance Comparison</h3>
                <div class="w-full py-4 pl-2 pr-3 bg-white rounded-xl shadow-sm">
                    <table>
                        <thead>
                            <tr>
                                <th></th>
                                <th>
                                    <div>
                                        <p>Topper</p>
                                        <span>(First Attempt)</span>
                                    </div>
                                </th>
                                <th>
                                    <div>
                                        <p>Average</p>
                                        <span>(First Attempt)</span>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Score</td>
                                <td id="topperScore">-</td>
                                <td id="averageScore">-</td>
                            </tr>
                            <tr>
                                <td>Correct</td>
                                <td id="topperCorrect">-</td>
                                <td id="averageCorrect">-</td>
                            </tr>
                            <tr>
                                <td>Incorrect</td>
                                <td id="topperIncorrect">-</td>
                                <td id="averageIncorrect">-</td>
                            </tr>
                            <tr>
                                <td>Skipped</td>
                                <td id="topperSkipped">-</td>
                                <td id="averageSkipped">-</td>
                            </tr>
                            <tr>
                                <td>Accuracy</td>
                                <td id="topperAccuracy">-</td>
                                <td id="averageAccuracy">-</td>
                            </tr>
                             <tr>
                                <td>Complete</td>
                                <td id="topperComplete">-</td>
                                <td id="averageComplete">-</td>
                            </tr>
                            <tr>
                                <td>Time Taken</td>
                                <td id="topperTimeTaken">-</td>
                                <td id="averageTimeTaken">-</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="leaderboard-section w-full h-fit flex hidden bg-white flex-col items-center py-2 relative">
            <h3 class="px-4 text-center text-sm font-semibold mb-3">
                *Leaderboard shows top students on the basis of first attempt
            </h3>
           <div id="learderboard-loader" class="flex w-full justify-center h-fit pt-6">
            <div class="inline-block animate-spin rounded-full h-12 w-12 loader"></div>
          </div>
            <div class="leaderboard-cards w-[92%] max-w-[40rem] max-h-[26rem] bg-white rounded-2xl p-4 flex-1" id="leaderboard">
            </div>
        </div>
    </section>
    `
}
let currentAttempt = null
export async function init(params, box) {
    // All Variables
    let testId = params.testId
    let allResults = {}
    let testMeta = {}
    let totalQuestions
    let finalMarks
    let totalMarks
    let timeTaken
    let accuracy
    let completed
    let scoreAnimation
    let startValue = 0
    let endValue
    let myRank
    box.var('scorePercentText', document.querySelector('.percent-score'))
    box.var('ScoreText', document.querySelector('.circle p'))
    box.var('scoreCircle', document.querySelector('.circle'))
    box.addEvent(document.getElementById("attempt-selector"), 'click', () => { openAttemptSelector() })
    box.addEvent(document.querySelector('.section-btn'), 'click', (e) => {
        if (e.target.classList.contains('section-result-btn')) {
            let curBtnClass = e.target.classList
            let nextBtnClass = e.target.nextElementSibling.classList
            nextBtnClass.remove('bg-white');
            nextBtnClass.remove('text-primary');
            nextBtnClass.add('text-gray-600')
            curBtnClass.add('bg-white');
            curBtnClass.add('text-primary');
            curBtnClass.remove('text-gray-600')
            handleTabChange('RESULT')
        }
        else if (e.target.classList.contains('section-leaderboard-btn')) {
            let curBtnClass = e.target.classList
            let preBtnClass = e.target.previousElementSibling.classList
            preBtnClass.remove('bg-white');
            preBtnClass.remove('text-primary');
            preBtnClass.add('text-gray-600')
            curBtnClass.add('bg-white');
            curBtnClass.add('text-primary');
            curBtnClass.remove('text-gray-600')
            handleTabChange('LEADERBOARD')
        }
    })
    function getCurrentResult() { return allResults[`attempt${currentAttempt}`] }
    const chngeAttemptDate = (startTime, submitTime) => {
        const dateText = document.querySelector('.attempt-date')
        const timeText = document.querySelector(".attempt-time")
        const attemptDate = new Date(startTime)
        const submitDate = new Date(submitTime)
        dateText.innerText = "Attempted on: " + attemptDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: "2-digit", minute: "2-digit", hour12: true })
        timeText.innerText = "Submited on: " + submitDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: "2-digit", minute: "2-digit", hour12: true })
        document.querySelector('.rank-text').innerHTML = myRank == null ? "--" : (currentAttempt == 1 ? myRank : myRank + ' (Predicted)');
    }
    const setupResult = (result, isStart = false) => {
        document.getElementById('cur-atm').innerText = `Attempt ${currentAttempt}`
        totalQuestions = result.totalQuestions
        accuracy = result.accuracy
        completed = result.completed
        finalMarks = result.finalMarks || 0
        totalMarks = result.totalMarks || 0
        timeTaken = Math.floor(result.timeTaken / 1000)
        ScoreText.innerText = `0/${totalMarks}`;
        myRank = result.liveRank || null;
        chngeAttemptDate(result.startTime, result.submitTime)
        clearInterval(scoreAnimation)
        scorePercentText.innerText = '0%'
        scoreCircle.style.background = `conic-gradient(var(--bar-clr) 0%, #e5e7eb 0)`
        document.getElementById("resultPage").classList.remove('hidden')
        document.getElementById('modalTopBar').classList.add('hidden')
        document.getElementById("resultPage-loader").classList.add('hidden')
        if (isStart) { box.setTimeout(start, 500) }
        else { start(0) }
    }

    const endAnimation = () => {
        clearInterval(scoreAnimation)
        scoreCircle.style.background = `conic-gradient(var(--bar-clr) ${endValue}%,  #e5e7eb 0)`;
        ScoreText.innerText = `${finalMarks}/${totalMarks}`
        scorePercentText.innerText = `${((finalMarks / totalMarks) * 100).toFixed(2)}%`
        updateTextData()
    }
    const start = (speed = 30) => {
        if (finalMarks > 0) {
            startValue = 0
            endValue = Math.floor((finalMarks / totalMarks) * 100)
            if (speed == 0) return endAnimation()
            scoreAnimation = box.setInterval(() => {
                startValue++;
                scoreCircle.style.background = `conic-gradient(var(--bar-clr) ${startValue}%, #e5e7eb 0)`;
                ScoreText.innerText = `${Math.floor(startValue * (totalMarks / 100))}/${totalMarks}`
                scorePercentText.innerText = startValue + '.00%';
                if (startValue == endValue) {
                    endAnimation()
                }
            }, speed)
        }
        else {
            clearInterval(scoreAnimation)
            scoreCircle.style.background = `conic-gradient(var(--bar-clr) 0%,  #e5e7eb 0)`;
            ScoreText.innerText = `${finalMarks}/${totalMarks}`
            scorePercentText.innerText = '0%'
            updateTextData()
        }
    }

    const updateTextData = () => {
        let questionsCounts = ["correct", "incorrect", "skipped"]
        questionsCounts.forEach(key => {
            let keyVariable = getCurrentResult()[`${key}QuestionsCount`]
            try {
                document.getElementById(`${key}QuestionsCount`).innerText = `${keyVariable}/${totalQuestions}`
                let bar = document.getElementById(`${key}QuestionsBar`)
                bar.style.width = `${Math.floor((keyVariable / totalQuestions) * 100)}%`
            } catch { }
        })
        let marksTypes = ['Obtained', 'Lost', 'Skipped']
        marksTypes.forEach(key => {
            let keyVariable = getCurrentResult()[`marks${key}`]
            let sign = key == 'Obtained' ? '+' : (key == 'Lost' ? '-' : "")
            try { document.getElementById(`marks${key}`).innerText = sign + keyVariable } catch { }
        })
        showTimeTaken()
    }

    const showTimeTaken = () => {
        try {
            document.querySelector('.accuracy').innerHTML = accuracy + "%";
            document.querySelector('.complete').innerHTML = completed + "%"
        } catch { }
        let hrs = Math.floor(timeTaken / 3600);
        let mins = Math.floor((timeTaken % 3600) / 60);
        let secs = timeTaken % 60;
        let display;
        if (hrs > 0) {
            hrs = hrs < 10 ? `0${hrs}` : hrs;
            mins = mins < 10 ? `0${mins}` : mins;
            secs = secs < 10 ? `0${secs}` : secs;
            display = `${hrs}<span class="mx-1">:</span>${mins}<span class="mx-1">:</span>${secs}`;
        } else {
            mins = mins < 10 ? `0${mins}` : mins;
            secs = secs < 10 ? `0${secs}` : secs;
            display = `${mins}<span class="mx-1">:</span>${secs}`;
        }
        try { document.querySelector('.time-taken').innerHTML = display; } catch { }
    }
    const changeAttempt = (attempt) => {
        setupResult(allResults[`attempt${attempt}`]);
    }
    const openAttemptSelector = () => {
        const drawerHtml = document.getElementById("drawerHtml")
        let optionsDiv = document.createElement("div")
        optionsDiv.className = "overflow-auto divide-y mt-1"
        for (let i = 1; i <= allResults.totalAttempts; i++) {
            let label = document.createElement('label')
            label.className = "flex items-center justify-between p-3 cursor-pointer hover:bg-gray-50";
            label.innerHTML = `
                    <span>Attempt ${i}</span>
                    <input type="radio" name="attempt" value="${i}" class="form-radio h-4 w-4 text-indigo-600" style="accent-color:var(--primary);"/> `
            optionsDiv.appendChild(label)
        }
        drawerHtml.innerHTML = ` <div>
                    <h3 class="text-lg font-semibold">Select Attempt</h3>
                </div>`
        drawerHtml.appendChild(optionsDiv)
        const radioInput = document.querySelectorAll('.form-radio')
        radioInput[currentAttempt - 1].checked = true;
        radioInput.forEach(input => {
            box.addEvent(input, 'change', () => {
                currentAttempt = input.value;
                changeAttempt(currentAttempt)
                closeDrawer()
            })
        })
        openDrawer()
    }
    const setUpTestCard = async () => {
        const titleText = document.querySelector('.test-meta-title');
        const infoText = document.querySelector('.test-meta-info');
        titleText.innerText = testMeta.title;
        infoText.innerHTML = ` ${testMeta.totalQuestions} Questions • ${testMeta.totalMarks} Marks • ${testMeta.duration} mins`
        const isSolutionsHidden = testMeta.isSolutionsHidden
        box.addEvent(document.querySelector('.solutions-btn'), 'click', () => {
            if (!isSolutionsHidden) {
                navigate(`/attempts/${getCurrentResult()._id}/solutions?viewer=User&attempt=${currentAttempt}&test=${testId}`)
            }
            else {
                openDrawer(`
                   <div class="text-center flex flex-col items-center">           
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="text-primary/70 w-16 h-16"><path fill="currentColor" d="M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-192a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm0-192c-18.2 0-32.7 15.5-31.4 33.7l7.4 104c.9 12.6 11.4 22.3 23.9 22.3 12.6 0 23-9.7 23.9-22.3l7.4-104c1.3-18.2-13.1-33.7-31.4-33.7z"/></svg>   
             <h3 class="text-xl font-semibold py-2">Oop's</h3>
            <p class="text-secondary mb-1">Solutions is hidden by test creator
            </p>
        </div>
            `)
            }
        })
    }
    function setPerformance(performance) {
        for (let [key, value] of Object.entries(performance)) {
            for (let [r, n] of Object.entries(value)) {
                if (key !== "TimeTaken") {
                    try { document.getElementById(r + key).innerText = n } catch { }
                }
                else {
                    let readableTime;
                    let s = n / 1000
                    if (s < 60) { readableTime = Math.round(s) + 's' }
                    else {
                        let m = s / 60
                        if (m < 60) {
                            readableTime = Math.round(m) + 'm'
                        }
                        else {
                            let h = Math.floor(m / 60)
                            m = Math.floor(m) % 60
                            readableTime = `${h}h ${m}m`
                        }
                    }
                    try { document.getElementById(r + key).innerText = readableTime } catch { }
                }
            }
        }
    }
    let lbCache = null;
    const setLeaderboard = async () => {
        if (!lbCache) {
            let resp = await fetchData(`/tests/${testId}/leaderboard?viewer=User`);
            if (!resp || !resp.success) {
                toast(resp?.message || "Failed to load leaderboard", "error")
                return
            }
            lbCache = resp.data
        }
        const students = lbCache;
        const medals = ["🥇", "🥈", "🥉"];
        const leaderboardDiv = document.getElementById("leaderboard");
        leaderboardDiv.innerHTML = ""
        leaderboardDiv.innerHTML = students.map((student, index) => {
            const rank = index + 1
            let rankDisplay = ""
            if (index < 3) {
                rankDisplay = `<div class="text-2xl">${medals[index]}</div>`
            } else {
                rankDisplay = `
          <div class="bg-blue-100 text-black font-bold px-3 py-1 rounded-lg text-lg">
            ${rank}
          </div>
        `
            }
            return `
        <div class="relative flex items-center justify-between bg-white border border-blue-100 rounded-xl px-2 py-1 mb-3 h-[4rem] shadow-sm hover:scale-[1.02] transition-all duration-200">
          <div class="absolute left-0 top-0 h-full w-[0.8rem] bg-blue-100 rounded-l-xl"></div>
          <div class="flex items-center gap-2 pl-4">
            <img src="${student.profile}" alt="${student.name}" class="w-8 h-8 rounded-full object-cover">
            <div>
              <h2 class="text-lg font-semibold">${student.name}</h2>
              <p class="text-sm text-gray-600 mt-1">${student.marks} Marks • ${student.correct} Correct</p>
            </div>
          </div>
          ${rankDisplay}
        </div>
      `
        }).join(" ")
        document.getElementById("learderboard-loader").classList.add('hidden')
    }

    const handleTabChange = (tabName) => {
        if (tabName === 'RESULT') {
            document.querySelector('.leaderboard-section').classList.add('hidden');
            document.querySelector('.result-section').classList.remove('hidden');
        }
        else if (tabName === 'LEADERBOARD') {
            document.querySelector('.leaderboard-section').classList.remove('hidden');
            document.querySelector('.result-section').classList.add('hidden');
            setLeaderboard()
        }
    }
    const startNewTest = () => {
        closeDrawer()
        navigate(`/tests/${testId}?type=Reattempt&source=resultPage&startTime=${Date.now()}&attemptId=${getCurrentResult()._id}`)
    }
    const goToReattempt = () => {
        if (!testMeta.isReattemptAllowed) {
            openDrawer(`
                <div class="text-center flex flex-col items-center">           
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="text-primary/70 w-16 h-16"><path fill="currentColor" d="M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-192a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm0-192c-18.2 0-32.7 15.5-31.4 33.7l7.4 104c.9 12.6 11.4 22.3 23.9 22.3 12.6 0 23-9.7 23.9-22.3l7.4-104c1.3-18.2-13.1-33.7-31.4-33.7z"/></svg>   
  <h3 class="text-xl font-semibold py-2">Oop's</h3>
            <p class="text-secondary mb-1">Reattempt not allowed by test creator
            </p>
        </div>
            `)
            return
        }
        openDrawer(`
        <div class="text-center">
            <h3 class="text-xl font-semibold mb-3">Reattempt Test?</h3>
            <p class="text-gray-700 mb-6">Are you sure you want to reattempt the test? <br> 
            leaderboad  will not be reflect in other attempts
            </p>
            <div class="space-y-2">
                <button class="btn-primary w-full" id="startNewTestBtn">Yes, Reattempt</button>
                <button class="btn-secondary w-full" onclick="closeDrawer()">Cancel</button>
            </div>
        </div>
    `)
        box.addEvent(document.getElementById("startNewTestBtn"), "click", startNewTest)
    }
    box.var('goToReattempt', goToReattempt)
    let cacheResults = cache.get('myResults') || {}
    try {
        let data;
        if (cacheResults[testId]) {
            data = cacheResults[testId]
            allResults = data.results
            if (!currentAttempt || allResults.totalAttempts < currentAttempt) { currentAttempt = allResults.totalAttempts }
        } else {
            let resp = await fetchData(`/tests/${testId}/my-result`)
            if (!resp || !resp.success) {
                display.open(`
                <div class="bg-[#fbfbfb] px-[2rem] pt-[1rem] pb-[2rem] flex flex-col justify-center items-center rounded-lg w-full h-full">
                    <h3 class="text-[3rem] font-semibold text-center">❌<br>Error</h3>
                    <p class="font-medium text-xl mb-[0.8rem]">${resp?.message || "Something went wrong!"}</p>
                    <button class="btn-primary" onclick="history.back()">Back</button>
                </div>
            `)
                return
            }
            data = resp.data
            cache.set("myResults", { ...cacheResults, [testId]: data }, 10 * 60 * 100)
            allResults = data.results
            currentAttempt = allResults.totalAttempts
        }
        testMeta = data.testMeta
        lbCache = null
        setUpTestCard();
        setupResult(getCurrentResult(), cacheResults[testId] != null ? false : true)
        setPerformance(data.performance)
    } catch (e) {
        console.eraror("Error to initialize", e)
        return
    }
}
