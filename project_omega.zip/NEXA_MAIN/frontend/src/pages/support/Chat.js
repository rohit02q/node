export async function Chat(params) {
  let demoChats = [
    { from: "admin", text: "Hello 👋, Nexa Support here. How can I help you?", ts: 1711952520000 },
    { from: "user", text: "Hi, I'm facing an issue with my test page.", ts: 1711952580000 },
    { from: "admin", text: "Sure, can you explain the issue in detail?", ts: 1711952700000 },
    { from: "user", text: "It gets stuck while loading after submission.", ts: 1711952820000 },
    { from: "admin", text: "This is a testing of is this proper best", ts: 1764611266326 },
    { from: "user", text: "Okay admin i think its good now", ts: 1764611266326 },
    { from: "admin", text: "Thanks for letting us know. We're checking it right now.", ts: 1711952940000 },
    { from: "user", text: "Any update on that?", ts: 1711868100000 },
    { from: "admin", text: "Yes, we fixed the issue. Try again now.", ts: 1711868820000 }
  ]
  let resp = await fetchData('/support/chat')
  demoChats = [...demoChats, ...resp.data]
  demoChats.sort((a, b) => a.ts - b.ts)
  function formatTime(ms) {
    const d = new Date(ms)
    return d.toLocaleTimeString('en-US', {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    })
  }
  function formatDate(ms) {
    const d = new Date(ms)
    const today = new Date()
    if (d.toDateString() === today.toDateString()) {
      return "Today"
    }
    const yesterday = new Date()
    yesterday.setDate(today.getDate() - 1)

    if (d.toDateString() === yesterday.toDateString()) {
      return "Yesterday"
    }
    return d.toLocaleDateString([], { day: "2-digit", month: "short", year: "numeric" })
  }

  let lastDate = null

  const chatsHTML = demoChats.map(msg => {
    const currentDate = formatDate(msg.ts)
    let dateLabel = ""
    if (currentDate !== lastDate) {
      dateLabel = `
        <div class="text-center text-xs text-gray-500 py-2" data-date="${currentDate}">
          <span class="bg-gray-200 px-3 py-1 rounded-lg">${currentDate}</span>
        </div>
      `
      lastDate = currentDate
    }
    const side =
      msg.from === "user"
        ? "justify-end text-right"
        : "justify-start text-left"
    const bubble =
      msg.from === "user"
        ? "bg-primary text-white rounded-br-none"
        : "bg-gray-200 text-secondary rounded-bl-none"
    return dateLabel + `
      <div class="w-full flex ${side}">
        <div class="max-w-[80%] px-4 py-2 my-1 rounded-2xl ${bubble} shadow-sm">
          <div class="break-words">${msg.text}</div>
          <div class="text-[10px] opacity-70 mt-1">${formatTime(msg.ts)}</div>
        </div>
      </div>
    `
  }).join("")
  return `
  <div class="h-[100vh] w-full flex flex-col bg-white fixed top-0">
    <div class="border-b px-4 py-3 flex items-center gap-3">
      <button class="w-fit h-fit flex items-center justify-center" aria-label="Back" onclick="history.back()">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
        </svg>
      </button>
      <div class="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-bold">
        N
      </div>
      <div>
        <h3 class="font-semibold text-lg">Nexa Support Chat</h3>
        <p class="text-xs text-gray-500">Ask anything direct to admin</p>
      </div>
    </div>
    <div 
      id="support_chat_box" 
      class="flex-1 p-4 space-y-2 overflow-y-auto bg-gray-50"
    >
      ${chatsHTML}
    </div>
    <style>
      #support_message_input:focus {
        border:1px solid var(--primary)
      }
    </style>
    <div class="px-3 py-4 border-t flex gap-2 bg-white">
      <input
        id="support_message_input"
        type="text"
        placeholder="Type your message..."
        class="flex-1 border rounded-xl px-4 py-2 outline-none"
      />
      <button
        id="support_send_btn"
        class="w-12 h-12 flex items-center justify-center rounded-full bg-primary text-white hover:bg-indigo-800 transition"
      >
        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
          <path d="M2 21l21-9L2 3v7l15 2-15 2v7z"/>
        </svg>
      </button>
    </div>
  </div>
  `
}
export async function init() {
  document.getElementById('modalTopBar').classList.add('hidden')
  const input = document.getElementById("support_message_input")
  const sendBtn = document.getElementById("support_send_btn")
  const chatBox = document.getElementById("support_chat_box")
  setTimeout(() => {
    chatBox.scrollTop = chatBox.scrollHeight
  }, 0)

  function getDateLabel(ms) {
    const d = new Date(ms)
    const today = new Date()
    if (d.toDateString() === today.toDateString()) return "Today"
    const yesterday = new Date()
    yesterday.setDate(today.getDate() - 1)
    if (d.toDateString() === yesterday.toDateString()) return "Yesterday"
    return d.toLocaleDateString([], { day: "2-digit", month: "short", year: "numeric" })
  }
  async function sendMessage() {
    const message = input.value.trim()
    if (!message) return
    const timestamp = Date.now()
    const dateLabel = getDateLabel(timestamp)
    const lastLabel = chatBox.lastElementChild?.dataset?.date
    if (lastLabel !== dateLabel) {
      const labelDiv = document.createElement("div")
      labelDiv.className = "text-center text-xs text-gray-500 my-4"
      labelDiv.dataset.date = dateLabel
      labelDiv.innerHTML = `<span class="bg-gray-200 px-3 py-1 rounded-lg">${dateLabel}</span>`
      chatBox.appendChild(labelDiv)
    }
    const div = document.createElement("div")
    div.className = "w-full flex justify-end text-right"
    div.dataset.date = dateLabel
    div.innerHTML = `
      <div class="max-w-[80%] px-4 py-2 my-1 rounded-2xl rounded-br-none bg-primary text-white shadow-sm">
        <div class="break-words">${message}</div>
        <div class="text-[10px] opacity-70 mt-1">
          ${new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
    `
    chatBox.appendChild(div)
    chatBox.scrollTop = chatBox.scrollHeight
    input.value = "";
    await fetchData('/support/chat/send', "post", { text: message })
  }
  sendBtn.addEventListener("click", sendMessage)
  input.addEventListener("keydown", e => {
    if (e.key === "Enter") sendMessage()
  })
}
