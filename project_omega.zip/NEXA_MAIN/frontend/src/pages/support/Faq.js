export async function Faq() {
  return `
  <style>
    .faq-rotate {
      transform: rotate(45deg);
    }
    .faq-answer {
      max-height: 0;
      opacity: 0;
      overflow: hidden;
      padding-top:0rem;
      transition:all 0.35s ease;
    }
    .faq-answer.show {
      max-height: 300px;
      opacity: 1;
      padding-top:0.75rem;
      margin-top: 12px;
    }
  </style>
  <div class="bg-gray-50 min-h-full py-6">
    <div class="space-y-4" id="faq_boxes">
      ${"<div class='skeleton w-full h-16 rounded-md'></div>".repeat(4)}
    </div>
  </div>
  `
}
export async function init() {
    
  const faqBox = document.getElementById('faq_boxes')

  function setFaqBox(faqs) {
    faqBox.innerHTML = faqs.map((f, i) => `
      <div class="bg-white p-4 pl-6 shadow-sm w-full rounded-lg" id="faq-${f._id}">
        <div class="flex items-center justify-between cursor-pointer faq-toggle" data-faq="${i}">
          <div class="pr-3"> 
            <h3 class="font-[500] text-secondary">${f.question}</h3>
          </div>
          <div 
            style="transition:all 0.35s;"
            class="faq-icon"
            data-faq-icon="${i}"
          >
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M12 4v16m8-8H4"></path>
            </svg>
          </div>

        </div>

        <div 
          class="faq-answer text-sm text-gray-600 border-t"
          id="faq_answer_${i}"
        >
          ${f.answer}
        </div>
      </div>
    `).join('')
    const toggles = document.querySelectorAll('.faq-toggle')
    toggles.forEach(item => {
      item.addEventListener("click", () => {
        const index = item.dataset.faq
        const icon = document.querySelector(`[data-faq-icon="${index}"]`)
        const answer = document.getElementById(`faq_answer_${index}`)
        icon.classList.toggle("faq-rotate")
        answer.classList.toggle("show")
      })
    })
  }
  if (!cache.has("faq")) {
    const resp = await fetchData("/app/faq")
    if (!resp || !resp.success) {
      toast("Failed to load FAQs", "error")
      history.back()
      return
    }
    cache.set("faq", resp.data)
    setFaqBox(resp.data)
  } else {
    setFaqBox(cache.get("faq"))
  }
}
