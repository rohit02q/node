function eyeIcon() {
  return `
    <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-width="2" d="M1.5 12s4.5-7.5 10.5-7.5S22.5 12 22.5 12s-4.5 7.5-10.5 7.5S1.5 12 1.5 12z"/>
      <circle cx="12" cy="12" r="3" />
    </svg>
  `
}
function eyeSlashIcon() {
  return `
    <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-width="2" d="M17.94 17.94A10.94 10.94 0 0 1 12 19.5C6 19.5 1.5 12 1.5 12a21.26 21.26 0 0 1 4.1-5.23M9.9 4.24A10.94 10.94 0 0 1 12 4.5c6 0 10.5 7.5 10.5 7.5a21.4 21.4 0 0 1-4.02 5.25M1 1l22 22"/>
    </svg>
  `
}
export async function ChangePassword() {
  return `
  <style>
  .toggleEye {
  position: absolute;
  right: -8px;
  width: 40px;
  aspect-ratio: 1;
  top:26%;
  transform: translateY(-25%);
}
  </style>
    <div class="p-4 max-w-md mx-auto">
      <h2 class="text-xl font-semibold mb-1">Change Your Password</h2>
      <div class="w-10 h-1 bg-primary mb-6 rounded-full"></div>
      <div class="space-y-4">
        <!-- Current Password -->
        <div>
          <label class="text-sm font-medium">Current Password</label>
          <div class="relative mt-1">
            <input 
              id="currentPassword"
              type="password"
              class="w-full border rounded-lg px-3 py-2 pr-10 outline-none focus:border-primary"
              placeholder="Enter your current password"
            />
            <button class="toggleEye" data-target="currentPassword">
              ${eyeIcon()}
            </button>
          </div>
        </div>
        <!-- New Password -->
        <div>
          <label class="text-sm font-medium">New Password</label>
          <div class="relative mt-1">
            <input 
              id="newPassword"
              type="password"
              class="w-full border rounded-lg px-3 py-2 pr-10 outline-none focus:border-primary"
              placeholder="Enter your new password"
            />
            <button class="toggleEye" data-target="newPassword">
              ${eyeIcon()}
            </button>
          </div>
        </div>
        <!-- Password rules -->
         <div class="bg-gray-50 p-3 rounded-lg">
        <span class="font-medium text-gray-700">Password must:</span>
        <ul class="text-sm text-gray-600 list-disc pl-5 mt-1 space-y-1">
          <li>Be at least 6 characters long</li>
          <li>Contain a number and a letter</li>
        </ul>
      </div>
        <!-- Confirm Password -->
        <div>
          <label class="text-sm font-medium">Confirm Password</label>
          <div class="relative mt-1">
            <input 
              id="confirmPassword"
              type="password"
              class="w-full border rounded-lg px-3 py-2 pr-10 outline-none focus:border-primary"
              placeholder="Confirm your new password"
            />
            <button class="toggleEye" data-target="confirmPassword">
              ${eyeIcon()}
            </button>
          </div>
         </div>
        <p id="error_msg" class="hidden"></p>
        <!-- Submit -->
        <button id="changePasswordBtn" 
          class="w-full bg-primary text-white py-2 rounded-lg mt-4 font-medium">
          Change Password
        </button>
         <span class="text-sm text-gray-600 font-medium text-center block mt-3" id="forgotPasswordBtn">Forgot Password? Click here.<span>
      </div>
    </div>
  `
}
export async function init() {
  if (!APP_STATE.isLoggedIn) return

  const cur = document.getElementById("currentPassword")
  const newP = document.getElementById("newPassword")
  const confirm = document.getElementById("confirmPassword")
  const btn = document.getElementById("changePasswordBtn")
  const error_msg = document.getElementById("error_msg")
  document.querySelectorAll(".toggleEye").forEach(btn => {
    btn.addEventListener("click", () => {
      const input = document.getElementById(btn.dataset.target)
      if (input.type === "password") {
        input.type = "text"
        btn.innerHTML = eyeSlashIcon()
      } else {
        input.type = "password"
        btn.innerHTML = eyeIcon()
      }
    })
  })
  function showError(text) {
    error_msg.textContent = text
    error_msg.className = `text-sm py-2 mt-4 px-2 border-l-4 rounded bg-red-50 border-red-400 text-red-700`
  }
  function validPassword(password) {
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/
    if (!passwordRegex.test(password))return false
    return true
  }
  btn.addEventListener("click", async () => {
    if (!cur.value) return showError("Current password is required")
    if (!newP.value) return showError("Enter your new password")
    if (!validPassword(newP.value)) return showError("New password must follow all conditions")
    if (!confirm.value) return showError("Conform your password")
    if (confirm.value !== newP.value) return showError("Passwords do not match")
    btn.innerText = "Updating..."
    const resp = await fetchData("/users/change-password", "POST", {
      currentPassword: cur.value,
      newPassword: newP.value,
    })
    if (!resp || !resp.success) {
      btn.innerText = "Change Password"
      return toast(resp?.message || "Failed to update password", "error")
    }
    toast("Password updated", "success")
    btn.innerText = "Change Password"
    cur.value = ""
    newP.value = ""
    confirm.value = ""
    navigate('/settings')
  })
  document.getElementById("forgotPasswordBtn").addEventListener("click", () => {
    const maskEmail = e => (([n, d]) => n[0] + "*".repeat(Math.max(0, n.length - 2)) + n.slice(-1) + "@" + d)(e.split("@"))
    openDrawer(`
      <div class="text-center">
        <h3 class="text-xl font-semibold mb-3">Reset Your Password</h3>
        <p class="text-gray-700 mb-6">
            We will send a password reset link to your email address
            <strong>${maskEmail(APP_STATE.user.email)}</strong>.
            Please check your inbox.
        </p>
        <div class="flex gap-4">
            <button class="btn-primary w-full">Send Reset Link</button>
            <button class="btn-secondary w-full" onclick="closeDrawer()">Cancel</button>
        </div>
      </div>
    `)
  })
}