export async function Logout(params) {
    loader.start()
    await fetchData('/users/logout',"delete")
    localStorage.clear()
    sessionStorage.clear()
    cache.clear()
    APP_STATE.isLoggedIn = false
    APP_STATE.user = null
    await initNavBar()
    loader.finish()
    navigate('/')
    return '<div class="w-full h-full flex justify-center items-center text-red-900 text-xl font-semibold">Loging Out...</div>'
}