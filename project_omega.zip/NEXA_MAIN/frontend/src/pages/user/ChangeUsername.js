export async function ChangeUsername() {
  if (!APP_STATE.isLoggedIn) return navigate('/login')

  return `
  <div class="min-h-full bg-white p-5">
     <h2 class="text-xl font-semibold mb-1">Change Your Username</h2>
      <div class="w-10 h-1 bg-primary mb-6 rounded-full"></div>
    <div class="space-y-5">
      <!-- Current username -->
      <div>
        <label class="block text-sm font-semibold mb-1">Current Username</label>
        <div class="border rounded-lg px-3 py-2 bg-gray-50">
          <span class="text-secondary">${APP_STATE.user.username}</span>
        </div>
      </div>
      <!-- New username -->
      <div>
        <label for="new_username" class="block font-semibold text-sm mb-1">New Username</label>
        <div class="relative">
          <input 
            id="new_username"
            type="text"
            placeholder="Enter new username"
            autocomplete="off"
            spellcheck = "false" 
            class="w-full border rounded-lg px-3 py-2 pr-10 focus:outline-none focus:ring-1 focus:ring-primary"
          />
          <!-- Status Icon (hidden by default) -->
          <div 
            id="username_status_icon"
            class="absolute right-3 top-1/2 -translate-y-1/2 hidden"
          >
          </div>
        </div>
        <p id="username_msg" class="hidden"></p>
      </div>

      <!-- Rules -->
      <div class="bg-gray-50 p-3 rounded-lg">
        <span class="font-medium text-gray-700">Username must:</span>
        <ul class="text-sm text-gray-600 list-disc pl-5 mt-1 space-y-1">
          <li>Be at least 4 characters long</li>
          <li>No spaces allowed</li>
          <li>Capital letters not allowed</li>
          <li>Only letters, numbers, underscore & dot</li>
        </ul>
      </div>
      <button
        id="changeUsernameBtn"
        class="w-full bg-primary text-white py-2.5 rounded-lg font-medium opacity-60"
        disabled
      >
        Change Username
      </button>
    </div>
  </div>
  `
}
export async function init() {
  function validateUsername(username) {
    if (!username) return { ok: false, msg: 'Enter new username.' };
    const cleaned = String(username).trim().toLowerCase()
    if (cleaned.length < 4) return { ok: false, msg: 'Username must be at least 4 characters long.' };
    if (cleaned.length > 30) return { ok: false, msg: 'Username cannot exceed 30 characters.' };
    if (!/^[a-z0-9._]+$/.test(cleaned)) return { ok: false, msg: 'Username can only contain letters, numbers, dots, and underscores.' };
    if (/^[._]/.test(cleaned)) return { ok: false, msg: 'Username cannot start with a dot or underscore.' };
    if (/[._]$/.test(cleaned)) return { ok: false, msg: 'Username cannot end with a dot or underscore.' };
    if (/\.\./.test(cleaned)) return { ok: false, msg: 'Username cannot contain consecutive dots.' };
    if (/__/.test(cleaned)) return { ok: false, msg: 'Username cannot contain consecutive underscores.' };
    const dots = (cleaned.match(/\./g) || []).length;
    const underscores = (cleaned.match(/_/g) || []).length;
    if (dots > 1) return { ok: false, msg: 'Username can contain only one dot.' };
    if (underscores > 4) return { ok: false, msg: 'Username can contain at most four underscores.' };
    if (/^(\w)\1+$/.test(cleaned)) return { ok: false, msg: 'Username cannot consist of a single repeated character.' };
    const chars = cleaned.split('').map(c => c.charCodeAt(0));
    let inc = 1, dec = 1;
    for (let i = 1; i < chars.length; i++) {
      if (chars[i] === chars[i - 1] + 1) inc++; else inc = 1;
      if (chars[i] === chars[i - 1] - 1) dec++; else dec = 1;
      if (inc >= 4 || dec >= 4) return { ok: false, msg: 'Username cannot contain sequential characters.' };
    }
    const badWords = [
      'admin', 'support', 'test', 'demo', 'user', 'null', 'root', 'owner', 'superuser', 'master',
      'moderator', 'staff', 'staffmember', 'system', 'guest', 'info', 'contact', 'help', 'service',
      'manager', 'webmaster', 'security', 'mail', 'email', 'postmaster', 'noreply', 'no-reply',
      'password', 'pass', 'login', 'signup', 'account', 'billing', 'temp', 'temporary', 'trial',
      'fake', 'bot', 'robot', 'spam', 'junk', 'offer', 'free', 'discount', 'sale', 'cash', 'money',
      'win', 'winner', 'prize', 'gift', 'giveaway', 'hot', 'sex', 'xxx', 'porn', 'adult', 'erotic',
      'nude', 'fuck', 'shit', 'bitch', 'ass', 'dick', 'pussy', 'cock', 'cunt', 'whore', 'slut',
      'damn', 'crap', 'idiot', 'stupid', 'fakeuser', 'tester', 'sample', 'example', 'qwerty', 'asdf',
      'zxcv', 'abc123', '123abc', '123456', 'abcdef', 'password123', 'admin123', 'test123', 'demo123', 'hack', 'black', 'topper',
      'king', 'funny', 'badboy', 'love'
    ];
    for (const bad of badWords) {
      if (cleaned.includes(bad)) return { ok: false, msg: 'This username is not allowed.' };
    }
    return { ok: true, value: cleaned };
  }
  const input = document.getElementById("new_username")
  input.focus()
  const btn = document.getElementById("changeUsernameBtn")
  const msg = document.getElementById("username_msg")
  const iconBox = document.getElementById("username_status_icon")
  let usernameTimeout = null
  let loaderTimeout = null
  function showMsg(text, type = "error") {
    msg.textContent = text
    msg.className = `text-sm py-2 mt-4 px-2 border-l-4 rounded ${ type === "error" ? "bg-red-50 border-red-400 text-red-700" : "border-green-400 text-green-700 bg-green-50"}`
  }
  function clearMsg() {
    msg.textContent = ""
    msg.classList.add("hidden")
  }
  function showIcon(type) {
    iconBox.classList.remove("hidden")
    if (type === "success") {
      iconBox.innerHTML = `
     <svg xmlns="http://www.w3.org/2000/svg" class="text-white bg-green-500 rounded-full w-5 h-5 p-1" viewBox="0 0 448 512"><path fill="currentColor" d="M434.8 70.1c14.3 10.4 17.5 30.4 7.1 44.7l-256 352c-5.5 7.6-14 12.3-23.4 13.1s-18.5-2.7-25.1-9.3l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l101.5 101.5 234-321.7c10.4-14.3 30.4-17.5 44.7-7.1z"/></svg>
      `; return
    }
    if (type === "error") {
      iconBox.innerHTML = `
       <svg xmlns="http://www.w3.org/2000/svg" class="text-white bg-red-500 rounded-full w-5 h-5 p-1" viewBox="0 0 384 512"><path fill="currentColor" d="M55.1 73.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L147.2 256 9.9 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192.5 301.3 329.9 438.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.8 256 375.1 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192.5 210.7 55.1 73.4z"/></svg>
      `; return
    }
    if (type === "loader") {
      iconBox.innerHTML = '<div class="inline-block animate-spin rounded-full h-5 w-5 loader"></div>'; return
    }
  }
  function hideIcon() {
    iconBox.classList.add("hidden")
    iconBox.innerHTML = ""
  }
  input.addEventListener("input", () => {
    btn.disabled = true
    btn.classList.add("opacity-60")
    clearTimeout(usernameTimeout)
    clearTimeout(loaderTimeout)
    hideIcon()
    clearMsg()
    const inputValue = input.value.trim();
    if (!inputValue) return
    input.value = inputValue.toLowerCase()
    const isUsernameValid = validateUsername(inputValue)
    if (!isUsernameValid.ok) {
      showMsg(isUsernameValid.msg)
      return
    }
    loaderTimeout = setTimeout(()=>{
      showIcon("loader")
    },400)
    const username = isUsernameValid.value
    usernameTimeout = setTimeout(async () => {
      const resp = await fetchData('/auth/exists?type=username', 'post', { username })
      if (!resp || typeof resp.exists === "undefined") {
        showMsg("Error checking username")
        showIcon("error")
        return
      }
      if (resp.exists) {
        showMsg(`Username '${username}' is already taken`, 'error')
        showIcon("error")
        return
      }
      showMsg("Username is available", "success")
      showIcon("success")
      btn.disabled = false
      btn.classList.remove("opacity-60")
    },1000)
  })
  btn.addEventListener("click", async () => {
    const isUsernameValid = validateUsername(input.value)
    if (!isUsernameValid.ok) {
      showMsg(isUsernameValid.msg)
      return
    }
    const username = isUsernameValid.value
    btn.disabled = true
    const resp = await fetchData("/users/change-username", "post", { username })
    if (!resp || !resp.success) {
      toast(resp?.message || "Failed to change username", "error")
      btn.disabled = false
      return
    }
    toast("Username updated", "success")
    APP_STATE.user.username = username
    const u = JSON.parse(localStorage.getItem("user"))
    u.username = username
    localStorage.setItem("user", JSON.stringify(u))
    setTimeout(() => {
      history.back()
    },50)
  })
}
