export async function Profile(params) {
    const user = APP_STATE.user;
    return `
        <div class="p-6 bg-gray-50">
                <div class="text-center">
                    <div class="relative inline-block">
                        <div class="w-32 h-32 flex items-center justify-center cursor-pointer border-4 border-white rounded-full overflow-hidden" style="box-shadow: 0px 0px 8px #80808065">
                            <img class="object-fit" src="${user.profile}" alt="${user.fullname}-photo" width="100%" height="100%">
                        </div>
                        <button
                            class="absolute bottom-0 right-0 w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center border-2 border-gray-100"
                            onclick="editProfilePicture()">
                            <svg class="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z">
                                </path>
                            </svg>
                        </button>
                    </div>
                </div>
                <div
                    class="mt-4 text-lg text-secondary font-semibold w-full h-fit flex items-center justify-center gap-1">
                    ${user.username}
                    ${user.verified ? '<svg stroke="currentColor" onclick="showVerifyInfo()" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="text-blue-500 w-5 h-5 cursor-pointer" xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0z"></path><path d="M23 12l-2.44-2.79.34-3.69-3.61-.82-1.89-3.2L12 2.96 8.6 1.5 6.71 4.69 3.1 5.5l.34 3.7L1 12l2.44 2.79-.34 3.7 3.61.82L8.6 22.5l3.4-1.47 3.4 1.46 1.89-3.19 3.61-.82-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81 1.48-1.48 2.32 2.33 5.85-5.87 1.48 1.48-7.33 7.35z"></path></svg>'
                    : ""}
                </div>
                <div class="flex gap-4 mt-6">
                    <div
                        class="flex flex-1 flex-col justify-between items-center bg-white p-2 rounded-lg border">
                        <div class="text-lg font-bold text-secondary">Total Test</div>
                        <div class="bg-white rounded-xl px-2 py-1">
                            <span class="xp text-lg font-semibold text-secondary">${user.totalTests || 0}</span>
                        </div>
                    </div>
                </div>
                <div class="mt-4 bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-6">
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="text-xl font-bold text-secondary">Your Details</h3>
                            <svg  id="editProfile" class="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                 <path d="M14.0514 3.73889L15.4576 2.33265C16.0678 1.72245 17.0572 1.72245 17.6674 2.33265C18.2775 2.94284 18.2775 3.93216 17.6674 4.54235L8.81849 13.3912C8.37792 13.8318 7.83453 14.1556 7.23741 14.3335L5 15L5.66648 12.7626C5.84435 12.1655 6.1682 11.6221 6.60877 11.1815L14.0514 3.73889ZM14.0514 3.73889L16.25 5.93749M15 11.6667V15.625C15 16.6605 14.1605 17.5 13.125 17.5H4.375C3.33947 17.5 2.5 16.6605 2.5 15.625V6.87499C2.5 5.83946 3.33947 4.99999 4.375 4.99999H8.33333" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                    </div>

                    <!-- Name -->
                    <div class="flex items-start mb-6 pb-6 border-b">
                        <div class="w-10 h-10 flex items-center justify-center mr-4 flex-shrink-0">
                            <svg class="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z">
                                </path>
                            </svg>
                        </div>
                        <div class="flex-1">
                            <div class="text-sm text-gray-500 mb-1">Full Name</div>
                            <div class="font-semibold text-gray-900">${user.fullname}</div>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="flex items-start mb-6 pb-6 border-b">
                        <div class="w-10 h-10 flex items-center justify-center mr-4 flex-shrink-0">
                            <svg class="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z">
                                </path>
                            </svg>
                        </div>
                        <div class="flex-1">
                            <div class="text-sm text-gray-500 mb-1">E-mail</div>
                            <div class="font-semibold text-gray-900">${user.email}</div>
                        </div>
                    </div>

                    <!-- Phone -->
                    <div class="flex items-start">
                        <div class="w-10 h-10 flex items-center justify-center mr-4 flex-shrink-0">
                            <svg class="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                                <path
                                    d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z">
                                </path>
                            </svg>
                        </div>
                        <div class="flex-1">
                            <div class="text-sm text-gray-500 mb-1">Phone number</div>
                            <div class="font-semibold text-gray-900">${user.phone || "--"}</div>
                        </div>
                    </div>
                </div>
                <div class="flex w-full justify-between mt-4 mb-6 px-4 h-auto items-center">
                    <div class="text-lg text-gray-800 font-semibold">Member Since</div>
                    <div class="text-md font-semibold text-gray-600">${new Date(user.createdAt).toLocaleDateString('en-UK', { month: 'short', day: 'numeric', year: "numeric" })}</div>
                </div>
                <!-- Logout Button -->
                <button class="btn-secondary w-full text-red-600 border-red-600" onclick="navigate('/logout')">
                    Logout
                </button>
            </div>
    `;
}
export async function init(params) {
    const user = APP_STATE.user
    function openEditDrawer() {
        openDrawer(`
                   <div>
            <h2 class="text-xl font-semibold mb-1">Edit Your Profile</h2>
      <div class="w-10 h-1 bg-primary mb-6 rounded-full"></div>
        </div>
        <form class="mt-4 space-y-4" id="editProfileForm">
            <div class="space-y-1">
                <label for="nameInput" class="block font-[500] text-lg">Fullname</label>
                <input class="outline-primary outline outline-[1px] p-3 w-full rounded-lg"
                    type="text" id="nameInput" name="fullname" value="${user.fullname}" required autocomplete="off">
            </div>
            <div class="space-y-1">
                <label for="emailInput" class="block font-[500] text-lg">Email</label>
                <div class="flex gap-2 overflow-hidden border border-primary rounded-xl">
                    <input class="outline-none flex-1 p-3 flex-1"
                        type="text" id="emailInput" value="${user.email}" readonly>
                        <button type="button" class="px-4 font-semibold text-primary rounded" id="changeEmailBtn">Change</button>
                </div>
                <p class="px-1 text-red-600 hidden" id="linkSendMessage"></p>
            </div>
            <div class="space-y-1">
                <label for="phoneInput" class="block font-[500] text-lg">Phone</label>
                <input class="outline-primary outline outline-[1px] p-3 w-full rounded-lg"
                    type="text" id="phoneInput" name="phone" value="${user.phone}"  autocomplete="off">
            </div>
            <button type="submit" class="btn-primary text-lg w-full">Update & Save</button>
        </form>
            `)
        initEditProfile()
    }
    document.getElementById('editProfile').addEventListener("click", openEditDrawer)
    function initEditProfile() {
        document.getElementById("changeEmailBtn").addEventListener('click', async () => {
            const message = document.getElementById('linkSendMessage')
            message.innerText = '*Link send check your mail inbox its valid for next 10 minutes.'
            message.classList.remove('hidden')
        })
        document.getElementById('editProfileForm').addEventListener('submit', async (e) => {
            e.preventDefault()
            closeDrawer()
            loader.start()
            const fullname = document.getElementById('nameInput').value || ""
            const phone = document.getElementById("phoneInput").value || ""
            let resp = await fetchData('/users/update/profile', 'POST', { fullname, phone })
            loader.finish()
            if (!resp || resp?.success) {
                APP_STATE.user.fullname = fullname
                APP_STATE.user.phone = phone
                openModal('Profile', await Profile())
                document.getElementById('editProfile').addEventListener("click", openEditDrawer)
                closeDrawer()
                toast(resp.message || "profile updated", "success")
            } else { toast(resp?.message || "profile not updated", "error") }
        })
    }
}