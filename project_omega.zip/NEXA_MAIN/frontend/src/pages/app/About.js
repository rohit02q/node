export async function About(params) {
    if(!cache.has('aboutApp')){
        const aboutApp = await fetchData("/app/about")
        cache.set('aboutApp',aboutApp?.html)
        return aboutApp?.html || "About message not loaded or not found,try again!"
    }
    return cache.get('aboutApp')
}