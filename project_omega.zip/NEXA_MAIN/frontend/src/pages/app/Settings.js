export async function Settings(params) {
    return `
<div class="pb-4 bg-gray-50 h-full">
<h2 class="text-secondary text-xl bg-white font-bold px-6 py-3">Settings</h2>
            <div class="space-y-2">
             ${APP_STATE.isLoggedIn ? `<div class="bg-white p-4 pl-6 shadow">
                <div class="flex items-center mb-4 gap-1">
                  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" class="w-5 h-5"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 14a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0-2a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12 23c6.075 0 11-4.925 11-11S18.075 1 12 1 1 5.925 1 12s4.925 11 11 11zm6.542-4.82a9 9 0 1 0-13.084 0C6.518 16.06 9.258 15 12 15c2.741 0 5.483 1.06 6.542 3.18zm-1.62 1.355c-.159-.631-.564-1.143-1.21-1.568-.911-.6-2.254-.967-3.712-.967-1.458 0-2.8.366-3.712.967-.646.425-1.051.937-1.21 1.569A8.958 8.958 0 0 0 12 21a8.958 8.958 0 0 0 4.923-1.465z"></path></svg>                 <h3 class="font-semibold text-lg">Account</h3>
                </div>
                <div class="space-y-4 pl-2">
                    <div onclick="navigate('/user/change-username')" class="flex items-center justify-between">
                        <span class="font-[500]">Change Username</span>
                        <svg class="w-5 h-5 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </div>
                    <div onclick="navigate('/user/change-password')" class="flex items-center justify-between">
                        <span class="font-[500]">Change Password</span>
                        <svg class="w-5 h-5 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </div>
                </div>
        </div>` : ""}
              <div class="bg-white p-4 pl-6 shadow">
                    <h3 class="font-semibold mb-2">Preferences</h3>
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="font-medium">Notifications</p>
                                    <p class="text-sm text-gray-600">Control app notifications</p>
                                </div>
                                <div class="relative inline-flex items-center">
                                    <input type="checkbox" class="sr-only peer" id="toggleBtn" checked>
                                    <label for="toggleBtn" class="cursor-pointer w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary">
                                    </label>
                                </div>
                            </div>
                </div>
                    <div class="bg-white p-4 pl-6 shadow">
                <div class="flex items-center mb-4 gap-1">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.3" d="M16.875 7.09253C17.6117 7.32957 18.125 8.03267 18.125 8.84018V12.4115C18.125 13.3587 17.4188 14.1619 16.4748 14.2389C16.1923 14.262 15.9091 14.2821 15.625 14.2994V16.875L13.125 14.375C11.9969 14.375 10.8797 14.329 9.77519 14.2388C9.5266 14.2186 9.2945 14.1479 9.08745 14.0375M16.875 7.09253C16.7488 7.05193 16.6161 7.025 16.4783 7.01356C15.3727 6.9218 14.2543 6.875 13.125 6.875C11.9957 6.875 10.8773 6.9218 9.77174 7.01356C8.82916 7.09179 8.125 7.89436 8.125 8.84018V12.4114C8.125 13.1092 8.50822 13.7288 9.08745 14.0375M16.875 7.09253V5.53109C16.875 4.17991 15.9152 3.00887 14.5753 2.83492C12.8732 2.61396 11.1375 2.5 9.37524 2.5C7.61278 2.5 5.87694 2.61399 4.1747 2.83499C2.83477 3.00895 1.875 4.17998 1.875 5.53115V10.7189C1.875 12.07 2.83478 13.2411 4.1747 13.415C4.65551 13.4774 5.13899 13.5313 5.625 13.5765V17.5L9.08745 14.0375"></path>
                </svg>
                   <h3 class="font-semibold text-lg">Support</h3>
                           </div>
                <div class="space-y-4 pl-2">
                    <div onclick="navigate('/support/faq')" class="flex items-center justify-between">
                        <span class="font-[500]">FAQ</span>
                        <svg class="w-5 h-5 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </div>
                    <div onclick="navigate('/support/chat')" class="flex items-center justify-between">
                        <div class="pr-2">
                                <p class="font-[500]">Contact</p>
                                <span class="text-sm text-gray-600">Chat with admin for any help or issue</span>
                         </div>
                        <svg class="w-5 h-5 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </div>
                </div>
        </div>
                <div class="bg-white p-4 pl-6 shadow">
                <div class="flex items-center mb-4 gap-1">
                 <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" class="w-5 h-4"><path fill="currentColor" d="M16 64C16 28.7 44.7 0 80 0L304 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64L80 512c-35.3 0-64-28.7-64-64L16 64zM128 440c0 13.3 10.7 24 24 24l80 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-80 0c-13.3 0-24 10.7-24 24zM304 64l-224 0 0 304 224 0 0-304z"></path></svg>
                    <h3 class="font-semibold text-lg">App</h3>
                </div>
                    <div class="space-y-2 pl-2">
                      <div onclick="navigate('/app/about')" class="flex items-center justify-between">
                        <span class="font-[500]">About</span>
                        <svg class="w-5 h-5 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </div>
                </div>
                </div>
                <div class="bg-white p-4 pl-6 shadow">
                    <div class="space-y-2 pl-2">
                   <div class="flex items-center">
        <span class="text-sm font-semibold text-gray-500">Version 1.0.0</span>
    </div>
    <div class="flex items-center">
         <span class="text-sm font-semibold text-gray-500">Delevopled by ~ Rohit</span>
    </div>
                </div>
                </div>
            </div>
        </div>
    `
}
