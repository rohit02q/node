function eyeIcon() {
  return `
    <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-width="2" d="M1.5 12s4.5-7.5 10.5-7.5S22.5 12 22.5 12s-4.5 7.5-10.5 7.5S1.5 12 1.5 12z"/>
      <circle cx="12" cy="12" r="3" />
    </svg>
  `
}
function eyeSlashIcon() {
  return `
    <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-width="2" d="M17.94 17.94A10.94 10.94 0 0 1 12 19.5C6 19.5 1.5 12 1.5 12a21.26 21.26 0 0 1 4.1-5.23M9.9 4.24A10.94 10.94 0 0 1 12 4.5c6 0 10.5 7.5 10.5 7.5a21.4 21.4 0 0 1-4.02 5.25M1 1l22 22"/>
    </svg>
  `
}
export async function Login() {
  return `
    <div class="w-full h-auto p-6">
      <div class="flex justify-center mb-[8px]" aria-hidden="true">
      <img src="/assets/images/login.jpg" alt="illustration" width=180 height="auto"/>
    </div>
    <div>
      <h1 id="title" class="text-center my-[6px] text-2xl">Welcome,</h1>
      <p class="text-gray-600 mb-[14px] text-center">Login to continue!</p>
      <div class="mt-6">
        <div class="flex items-center gap-[10px] border p-[12px] rounded-2xl mb-[12px] bg-white">
           <div class="w-[28px] flex justify-center text-primary">
           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-4 h-4"><path fill="currentColor" d="M224 248a120 120 0 1 0 0-240 120 120 0 1 0 0 240zm-29.7 56C95.8 304 16 383.8 16 482.3 16 498.7 29.3 512 45.7 512l356.6 0c16.4 0 29.7-13.3 29.7-29.7 0-98.5-79.8-178.3-178.3-178.3l-59.4 0z"/></svg>
           </div>
          <input class="flex-1 border-none outline-none bg-transparent" id="loginUsername" type="text" placeholder="Username or Email" autocomplete="off" spellcheck = "false" />
        </div>
        <div class="flex items-center  gap-[10px] border p-[12px] rounded-2xl mb-[8px] bg-white">
          <div class="w-[28px] flex justify-center text-primary">
         <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4"><path fill="currentColor" d="M336 352c97.2 0 176-78.8 176-176S433.2 0 336 0 160 78.8 160 176c0 18.7 2.9 36.8 8.3 53.7L7 391c-4.5 4.5-7 10.6-7 17l0 80c0 13.3 10.7 24 24 24l80 0c13.3 0 24-10.7 24-24l0-40 40 0c13.3 0 24-10.7 24-24l0-40 40 0c6.4 0 12.5-2.5 17-7l33.3-33.3c16.9 5.4 35 8.3 53.7 8.3zM376 96a40 40 0 1 1 0 80 40 40 0 1 1 0-80z"/></svg>
          </div>
          <input class="flex-1 border-none outline-none bg-transparent" id="loginPassword" type="password" placeholder="Password" autocomplete="current-password" />
          <div class="toggleEye">${eyeIcon()}</div>
          </div>
        <p class="pl-4 text-gray-500 font-[500] text-sm mb-3">Forgot Password?</p>
          <button id="loginBtn" class="w-full py-[12px] px-[14px] border-none cursor-pointer font-semibold text-lg text-white bg-primary mt-[6px] rounded-2xl" type="button">Login</button>
      </div>
      <div class="text-gray-600 text-center mt-[16px]">Don't have an account? <a href="/signup" class="text-primary font-semibold">Sign up</a></div>
    </div>
    </div>
  `;
}
export function init() {
  const loginBtn = document.getElementById('loginBtn');
  const loginUsername = document.getElementById('loginUsername');
  const loginPassword = document.getElementById('loginPassword');
  const toggleEyeBtn = document.querySelector('.toggleEye');
  toggleEyeBtn.addEventListener('click', () => {
    if (loginPassword.type === "password") {
      loginPassword.type = "text"
      toggleEyeBtn.innerHTML = eyeSlashIcon()
    } else {
      loginPassword.type = "password"
      toggleEyeBtn.innerHTML = eyeIcon()
    }
  })
  loginUsername.focus()
  loginBtn.addEventListener('click', async () => {
    const usr = loginUsername.value.trim();
    const pass = loginPassword.value.trim();
    if (!usr) { toast("Enter username", "error"); loginUsername.focus(); return }
    if (!pass) { toast("Enter password", "error"); loginPassword.focus(); return }
    loader.start()
    loginBtn.disabled = true;
    loginBtn.textContent = 'Logging in...';
    let resp = await fetchData('/auth/login', "POST", { username: usr, password: pass })
    if (resp?.success === true) {
      toast("Logged in successfully", "success")
      let access_token = resp.data.access_token
      let refresh_token = resp.data.refresh_token
      localStorage.setItem('TOKEN', access_token)
      localStorage.setItem('REFRESH_TOKEN', refresh_token)
      localStorage.setItem('lastLogin', Date.now())
      APP_STATE.isLoggedIn = true;
      let userResp = await fetchData('/users/self')
      if (userResp && userResp?.success) {
        localStorage.setItem("user", JSON.stringify(userResp.data))
        APP_STATE.user = { name: userResp.data.fullname, ...userResp.data };
      }
      await initNavBar()
      loader.finish()
      navigate('/')
    } else {
      loginUsername.value = ""
      loginPassword.value = ""
      loginUsername.focus()
      loader.finish()
      toast(resp?.message || 'Something went wrong!', "error")
      loginBtn.disabled = false;
      loginBtn.textContent = 'Login';
    }
  })
  loginUsername.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); loginBtn.click(); } });
  loginPassword.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); loginBtn.click(); } });
}