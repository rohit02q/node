export async function Solutions(params) {
    return `
         <div id="solutions-loader" class="flex items-center justify-center h-full">
            <div class="text-center">
                <div class="inline-block animate-spin rounded-full h-12 w-12 loader"></div>
                <p class="mt-4 text-gray-500">Loading...</p>
            </div>
        </div>
<div id="solutions-main--body" class="hidden min-h-full bg-white pb-[80px] pt-[13.5rem] w-full">
    <header class="fixed top-0 left-0 w-full bg-white z-20 shadow">
        <div class="p-4 flex items-center border-b border">
            <svg class="h-6 w-6 text-gray-800 cursor-pointer" fill="none" viewBox="0 0 24 24" stroke="currentColor"
                onclick="history.back()">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
            <h1 class="text-xl font-bold ml-4 text-gray-900">Solutions</h1>
        </div>
        <div id="tabs-container" class="flex justify-around text-center border-b border-gray-200">
        </div>
        <div class="question-grid-container py-3 px-4 bg-white">
            <div id="question-grid" class="inline-flex space-x-2"></div>
        </div>
    </header>
    <div class="no-q-container hidden"></div>
    <section class="container mx-auto pb-6 question-area">
        <div id="question-details" class="bg-white px-8">
            <div class="flex items-center space-x-3 mb-3 pb-4">
                <span id="current-q-id"
                    class="flex items-center justify-center text-lg font-semibold w-[2rem] h-[2rem] bg-gray-700 text-[#fbfbfb] rounded-full shadow-sm">1</span>
                <span id="q-marks"
                    class="text-lg px-[10px] py-[3px] bg-[#fbfbfb] text-gray-700 rounded-lg border border-gray-400">Marks:
                    </span>
                <span id="q-type"
                    class="text-lg px-[10px] py-[3px] bg-[#fbfbfb] text-gray-700 rounded-lg border border-gray-400">Type:
                    MCQ</span>
            </div>
            <div class="question-content mb-6">
                <p id="q-text" class="text-black text-sm leading-relaxed"></p>
                   <div class="q-img-box relative rounded-md overflow-hidden">
                     <img src='' class="w-full aspect-video object-cover" alt="Question_Image" id="question-img">
                     <span id="fullImg_icon" class="absolute bottom-2 right-2 p-2 w-8 h-8 rounded-md bg-white/40 text-gray-800">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M32 32C14.3 32 0 46.3 0 64l0 96c0 17.7 14.3 32 32 32s32-14.3 32-32l0-64 64 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 32zM64 352c0-17.7-14.3-32-32-32S0 334.3 0 352l0 96c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0 0-64zM320 32c-17.7 0-32 14.3-32 32s14.3 32 32 32l64 0 0 64c0 17.7 14.3 32 32 32s32-14.3 32-32l0-96c0-17.7-14.3-32-32-32l-96 0zM448 352c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 64-64 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l96 0c17.7 0 32-14.3 32-32l0-96z"/></svg>
                     </span>
                   </div>
                <div id="options-text" class="mt-2">
                </div>
            </div>
            <div id="question-summary"
                class="mb-6 rounded-lg text-base flex justify-center flex-col items-center gap-2">
                <div class="bg-gray-50 p-4 w-full flex justify-center">
                    <span class="text-black">Correct Answer :</span>
                    <span id="correct-answer-value" class="ml-2 font-semibold text-gray-900"></span>
                </div>
                <div class="bg-gray-50 p-4 w-full flex justify-center">
                    <span class="text-black">Time Spent :</span>
                    <span id="time-spent" class="ml-2 font-semibold text-gray-900"></span>
                </div>
            </div>
            <div id="input-container"></div>
            <div id="options-list" class="space-y-4 mb-4"></div>
            <div class="py-2">
            <h3 class="text-lg font-semibold text-secondary">Explanation</h3>
            <div id="q_explanation" class="mt-1"></div>
            </div>
        </div>
    </section>
    <footer class="q-bottom-btn fixed bottom-0 left-0 w-full bg-white border-t-2 border-gray-200 p-3 z-20">
        <div class="container mx-auto flex justify-between space-x-4">
            <button id="prev-btn" class="w-[8rem] px-4 rounded-md py-[0.8rem] border border-indigo-500 text-indigo-600">
                Previous
            </button>
            <button id="next-btn" class="w-[8rem] px-4 rounded-md py-[0.8rem] bg-indigo-600 text-white">
                Next
            </button>
        </div>
    </footer>
    <div>`
}
export async function init(params, box) {
    let TOTAL_ALL
    let TOTAL_CORRECT
    let TOTAL_INCORRECT
    let TOTAL_SKIPPED
    let QUESTIONS
    let currentFilter = 'All'
    let currentQId = 1
    const initData = async (attemptId) => {
        let data;
        let cacheSolutions = cache.get('solutions') || {}
        if (cacheSolutions[attemptId]) {
            data = cacheSolutions[attemptId]
        } else {
            let resp = await fetchData(`/attempts/${attemptId}/solutions${location.search}`)
            if (!resp || !resp.success) {
                display.open(`
                <div class="bg-[#fbfbfb] px-[2rem] pt-[1rem] pb-[2rem] flex flex-col justify-center items-center rounded-lg w-full h-full">
                    <h3 class="text-[3rem] font-semibold text-center">❌<br>Error</h3>
                    <p class="text-medium text-xl mb-[0.8rem]">${resp?.message || "Something went wrong!"}</p>
                    <button class="btn-primary" onclick="history.back()">Back</button>
                </div>
            `)
                return
            }
            data = resp.data
            cache.set("solutions", { ...cacheSolutions, [attemptId]: data }, 10 * 60 * 1000)
        }
        TOTAL_ALL = data.TOTAL_ALL
        TOTAL_CORRECT = data.TOTAL_CORRECT
        TOTAL_INCORRECT = data.TOTAL_INCORRECT
        TOTAL_SKIPPED = data.TOTAL_SKIPPED
        QUESTIONS = data.QUESTIONS
        initializeApp()
        document.getElementById("solutions-main--body").classList.remove('hidden')
        document.getElementById('modalTopBar').classList.add('hidden')
        document.getElementById("solutions-loader").classList.add('hidden')
    }
    function renderTabs() {
        const tabsData = [
            { id: 'All', label: 'All', count: TOTAL_ALL, colorClass: 'text-gray-800' },
            { id: 'Correct', label: 'Correct', count: TOTAL_CORRECT, colorClass: 'text-green-600' },
            { id: 'Incorrect', label: 'Incorrect', count: TOTAL_INCORRECT, colorClass: 'text-red-600' },
            { id: 'Skipped', label: 'Skipped', count: TOTAL_SKIPPED, colorClass: 'text-gray-500' },
        ];
        const container = document.getElementById('tabs-container');
        container.innerHTML = tabsData.map(tab => {
            const isActive = tab.id === currentFilter;
            const activeStyle = isActive
                ? 'border-primary text-primary font-bold bg-indigo-50/50'
                : 'border-transparent text-gray-800';
            return `
                    <div data-filter="${tab.id}" class="tab-item flex-1 py-2 border-b cursor-pointer transition duration-150 ease-in-out ${activeStyle}" onclick="handleTabClick('${tab.id}')">
                        <p class="text-lg">${tab.label}</p>
                        <p class="mt-1 text-normal font-bold ${tab.colorClass}">${tab.count}</p>
                    </div>
                `;
        }).join('');
    }

    function getQuestionButtonClasses(q, isActive) {
        let baseClasses = 'w-10 h-10 flex-shrink-0 text-sm font-semibold rounded-lg flex pt-[5px] justify-center transition duration-200 relative';
        let statusClasses = 'bg-gray-50 text-gray-700 border border-gray-300';
        let dotColor = 'bg-gray-500';

        if (q.status === 'correct') {
            statusClasses = 'bg-green-50 text-green-700 border border-green-300';
            dotColor = 'bg-green-600';
        } else if (q.status === 'incorrect') {
            statusClasses = 'bg-red-50 text-red-700 border border-red-300';
            dotColor = 'bg-red-600';
        }
        if (isActive) {
            if (q.status === 'correct') {
                statusClasses = 'bg-green-50 text-green-700 border border-green-600 border-2';
            } else if (q.status === 'incorrect') {
                statusClasses = 'bg-red-50 text-red-700 border border-red-600 border-2';
            }
            else {
                statusClasses = 'bg-gray-50 text-gray-700 border border-gray-600 border-2';
            }
        }
        return {
            button: `${baseClasses} ${statusClasses}`,
            dot: dotColor
        };
    }

    function renderQuestionGrid() {
        const container = document.getElementById('question-grid');
        const filteredQuestions = currentFilter === 'All'
            ? QUESTIONS
            : QUESTIONS.filter(q => q.status === currentFilter.toLowerCase());
        container.innerHTML = filteredQuestions.map(q => {
            const isActive = q.id === currentQId;
            const classes = getQuestionButtonClasses(q, isActive);
            return `
                    <button data-q-id="${q.id}" class="${classes.button}" onclick="selectQuestion(${q.id})">
                        ${q.id}
                        <span class="absolute bottom-1 left-1/2 -translate-x-1/2 h-1.5 w-1.5 rounded-full ${classes.dot}"></span>
                    </button>
                `;
        }).join('');
    }

    function renderQuestionDetails(question) {
        try {
            const no_q_container = document.querySelector('.no-q-container')
            if (!question) {
                document.querySelector('.question-grid-container').classList.add('hidden')
                document.querySelector('.question-area').classList.add('hidden');
                document.querySelector('.q-bottom-btn').classList.add('hidden');
                no_q_container.classList.remove('hidden')
                no_q_container.innerHTML = `<h3 class="text-xl text-center text-black font-semibold mb-2 mt-[10rem]">No Questions found!</h3>
                <p class="text-center text-gray-900 px-8">Looks like you don't have any questions in this particular section</p>`
                return;
            }
            document.querySelector('.question-grid-container').classList.remove('hidden')
            document.querySelector('.question-area').classList.remove('hidden');
            document.querySelector('.q-bottom-btn').classList.remove('hidden');
            no_q_container.classList.add('hidden')
            document.getElementById('current-q-id').textContent = question.id;
            document.getElementById('q-marks').innerHTML = `Marks: <span class='font-semibold text-${question.marks > 0 ? 'green' : (question.marks < 0 ? 'red' : 'gray')}-600'>${question.marks > 0 ? '+' : ''}${question.marks}<span>`;
            document.getElementById('q-type').textContent = `Type: ${question.type == "mcq" ? "MCQ" : "Numeric"}`;
            document.getElementById('q-text').innerHTML = question.text.replaceAll(/[\n\r]/g, "<br>")
            document.getElementById('q_explanation').innerHTML = question.explanation.replaceAll(/[\n\r]/g, "<br>")
            if (question.image.hasImage) {
                document.getElementById('question-img').src = question.image.imageUrl
                document.querySelector('.q-img-box').classList.remove('hidden')
            }
            else {
                document.querySelector('.q-img-box').classList.add('hidden')
            }

            const optionsText = document.getElementById('options-text');
            const inputContainer = document.getElementById('input-container');
            const optionsList = document.getElementById('options-list');
            function formatTimeSpent(time) {
                if (time < 60) return Math.floor(time) + "s"
                let mins = Math.floor(time / 60)
                let sec = Math.floor(time % 60)
                return `${mins}m ${sec}s`
            }
            document.getElementById('time-spent').textContent = formatTimeSpent(Number(question.timeSpent) / 1000)
            if (question.type === "mcq") {
                document.getElementById('correct-answer-value').textContent = String.fromCharCode(65 + question.correctAnswer);
                optionsText.innerHTML = question.options.map((opt, index) => {
                    const optionLabel = String.fromCharCode(65 + index);
                    return `
                 <p class="mt-[2px] text-sm text-black leading-relaxed">(${optionLabel}) ${opt.replaceAll(/[\n\r]/g, "<br>")}</p>
                `
                }).join('')
                inputContainer.classList.add('hidden')
                optionsList.innerHTML = question.options.map((opt, index) => {
                    const isCorrect = question.correctAnswer === index
                    const isUserAnswer = question.userAnswer === index;
                    let containerClasses = 'bg-white text-gray-900 option-container';
                    let labelClasses = 'option-label';
                    let textClasses = 'text-gray-900';
                    if (isCorrect) {
                        containerClasses = 'text-green-600 font-medium option-container  border border-green-400 bg-green-50';
                        labelClasses = 'option-label bg-green-600 text-white border-0'
                        textClasses = 'text-green-600';
                    }
                    if (isUserAnswer && !isCorrect) {
                        containerClasses = 'text-red-600 font-medium option-container border border-red-400 bg-red-50';
                        labelClasses = 'option-label bg-red-600 text-white border-0'
                        textClasses = 'text-red-600';
                    }
                    if (isUserAnswer && isCorrect) {
                        containerClasses = 'text-green-600 font-bold option-container border border-green-400 bg-green-50';
                    }
                    const optionLabel = String.fromCharCode(65 + index);
                    return `
                    <div class="flex items-start p-4 rounded-md ${containerClasses}">
                        <div class="${labelClasses} mr-4">${index + 1}</div>
                        <div class="flex-1 text-base leading-relaxed pt-0.5 ${textClasses}">${optionLabel}</div>
                    </div>
                `;
                }).join('');
            }
            else {
                document.getElementById('correct-answer-value').textContent = question.correctAnswer;
                optionsText.innerHTML = "";
                let statusColor = 'gray'
                let inputValue = '~Skipped~'
                if (question.status === 'correct') {
                    statusColor = 'green'
                    inputValue = question.userAnswer;
                }
                else if (question.status === 'incorrect') {
                    statusColor = 'red'
                    inputValue = question.userAnswer;
                }
                optionsList.innerHTML = "";
                inputContainer.classList.remove('hidden');
                inputContainer.classList = `class="w-full h-[3rem] border mb-4 rounded-sm relative border-${statusColor}-500`
                inputContainer.innerHTML = `
                   <label for="input-answer" class="bg-white absolute top-[-12px] left-[20px] text-sm text-${statusColor}-600">Your
                    Answer</label>
                <input id="input-answer" type="text" value="${inputValue}"
                    class="text-${question.status === 'skipped' ? 'gray-500' : 'black'} bg-transparent w-full h-full px-4 :focus outline-none" readonly>
                `
            }
        } catch { }
    }
    //     Full Image System
    box.addEvent(document.getElementById('fullImg_icon'), 'click', () => {
        const currentQuestion = QUESTIONS.find(q => q.id === currentQId)
        const curImage = currentQuestion.image.imageUrl
        display.open(`
            <div class="relative p-4 flex items-center justify-center w-full h-full" style="touch-action:pinch-zoom;">
            <div class="absolute top-6 right-4 w-10 h-10 p-2 flex items-center justify-center bg-white/50 rounded-full" onclick="display.close()">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M55.1 73.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L147.2 256 9.9 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192.5 301.3 329.9 438.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.8 256 375.1 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192.5 210.7 55.1 73.4z"/></svg>
            </div>
            <img src="${curImage}" class="rounded-lg" alt="Question_Image_ERR_NOT_LOAD">
            </div>
            `)
    })

    function handleTabClick(filter) {
        currentFilter = filter;
        const filteredQuestions = currentFilter === 'All'
            ? QUESTIONS
            : QUESTIONS.filter(q => q.status === currentFilter.toLowerCase());
        if (!filteredQuestions.find(q => q.id === currentQId) && filteredQuestions.length > 0) {
            currentQId = filteredQuestions[0].id;
        } else if (filteredQuestions.length === 0) {
            currentQId = null;
        }
        initializeApp();
    }

    function selectQuestion(id) {
        currentQId = id
        initializeApp()
    }

    function changeQuestion(direction) {
        const filteredQuestions = currentFilter === 'All'
            ? QUESTIONS
            : QUESTIONS.filter(q => q.status === currentFilter.toLowerCase());
        if (filteredQuestions.length === 0) return;

        const currentIndex = filteredQuestions.findIndex(q => q.id === currentQId);
        let newIndex;
        if (direction === 'next') {
            newIndex = (currentIndex + 1) % filteredQuestions.length;
        } else if (direction === 'prev') {
            newIndex = (currentIndex - 1 + filteredQuestions.length) % filteredQuestions.length;
        }
        currentQId = filteredQuestions[newIndex].id
        initializeApp()
    }

    function initializeApp() {
        renderTabs();
        renderQuestionGrid();
        const currentQuestion = QUESTIONS.find(q => q.id === currentQId);
        renderQuestionDetails(currentQuestion);
        const activeBtn = document.querySelector(`.question-grid-container button[data-q-id="${currentQId}"]`);
        if (activeBtn) {
            activeBtn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }
    }
    box.addEvent(document.getElementById('prev-btn'), 'click', () => changeQuestion('prev'));
    box.addEvent(document.getElementById('next-btn'), 'click', () => changeQuestion('next'));
    box.addEvent(document.body, 'keydown', (e) => {
        if (e.key == 'ArrowLeft') {
            changeQuestion('prev')
        }
        else if (e.key == "ArrowRight") {
            changeQuestion('next')
        }
    })
    box.var('handleTabClick', handleTabClick)
    box.var('selectQuestion', selectQuestion)
    initData(params.attemptId)
}