export async function NotFoundPage() {
  return `
  <div class="absolute w-72 h-72 bg-indigo-600/20 rounded-full blur-3xl animate-float1"></div>
    <div class="w-full h-full flex pt-12 justify-center bg-transparent text-black overflow-hidden relative">
      <div class="z-10 flex flex-col items-center text-center px-6">
        <h1 class="text-[7rem] md:text-[10rem] font-black tracking-widest glitch">
          404
        </h1>
        <p class="text-2xl font-semibold text-secondary mt-4">You unlocked a secret page</p>
        <p class="text-lg text-gray-600 mt-1">But sadly… it doesn’t exist.</p>
        <p class="mt-4 text-lg text-secondary max-w-xs">
       Look like you enter a wrong URL please check and try again.
        </p>
        <div class="mt-8 flex gap-4 flex-wrap justify-center">
        <button onclick="history.back()" class="btn-primary hover:bg-indigo-800">Back</button>
        </div>
      </div>
      <style>
        @keyframes float1 {
          0% { transform: translateY(0) translateX(0); }
          50% { transform: translateY(-40px) translateX(40px); }
          100% { transform: translateY(0) translateX(0); }
        }
        .animate-float1 {
          top: 10%;
          left: 5%;
          animation: float1 10s infinite ease-in-out;
        }
        .glitch {
          position: relative;
          color: #fff;
        }
        .glitch:before, .glitch:after {
          content: '404';
          position: absolute;
          left: 0;
          top: 0;
          opacity: .7;
        }
        .glitch:before {
          color: #ec4899;
          animation: glitchTop 2s infinite linear alternate-reverse;
        }
        .glitch:after {
          color: #22d3ee;
          animation: glitchBottom 1.5s infinite linear alternate-reverse;
        }
        @keyframes glitchTop {
          0% { transform: translate(0, 0); }
          20% { transform: translate(-3px, -3px); }
          40% { transform: translate(3px, -3px); }
          60% { transform: translate(-2px, 2px); }
          80% { transform: translate(2px, 2px); }
          100% { transform: translate(0,0); }
        }

        @keyframes glitchBottom {
          0% { transform: translate(0, 0); }
          20% { transform: translate(3px, 3px); }
          40% { transform: translate(-3px, 3px); }
          60% { transform: translate(2px, -2px); }
          80% { transform: translate(-2px, -2px); }
          100% { transform: translate(0,0); }
        }
      </style>
    </div>
  `;
}
