function skeleton(number) {
    return '<div class="skeleton h-24 mb-3 rounded-lg border border-gray-500"></div>'.repeat(number)
}
export async function Explore(params) {
    return `
    <style>
.search-input {
    width: 100%;
    padding: 12px 16px 12px 40px;
    border: 1px solid var(--gray-300);
    border-radius: 12px;
    font-size: 17px;
    outline: none;
    transition: all 0.2s;
    margin-bottom: 16px;
    background: white;
}
.search-input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px #5a4bda15;
}
    </style>
        <div class="p-4 flex flex-col gap-2 h-full w-full">
            <!-- Search -->
            <div class="relative">
                <svg style="pointer-events:none;" class="w-6 h-6 text-gray-400 absolute top-3 left-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                </svg>
                <input type="text" class="search-input" placeholder="Search tests by title or username" autocomplete="off" spellcheck="false" id="testSearch">
            </div>
            
            <!-- Filters -->
            <div class="filter-chips border-b pb-3">
                <div class="filter-chip active" data-filter="newest">Newest</div>
                <div class="filter-chip" data-filter="popular">Popular</div>
                <div class="filter-chip" data-filter="oldest">Oldest</div>
            </div>
            <!-- Test List -->
            <div id="testList" class="flex-1 overflow-y-auto hideScroll space-y-4">${skeleton(5)}</div>
        </div>
    `;
}


export async function init(_, box) {
    const searchInput = document.getElementById('testSearch')
    const filterChips = document.querySelectorAll('.filter-chip')
    const testList = document.getElementById('testList')
    function emptyState(title, text) {
        return `
              <div class="empty-state">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                        </path>
                     </svg>
                    <h3>${title}</h3>
                    <p>${text}</p>
                    </div>
        `
    }
    let allTests = null
    let searchTimeout
    box.addEvent(searchInput, 'input', (e) => {
        testList.innerHTML = skeleton(5)
        clearTimeout(searchTimeout);
        searchTimeout = box.setTimeout(() => {
            loadTests("query", e.target.value)
        }, 300)
    })
    const query = new URLSearchParams(location.search)
    let filter = "newest"
    filterChips.forEach(chip => {
        box.addEvent(chip, 'click', () => {
            filterChips.forEach(c => c.classList.remove('active'))
            chip.classList.add('active')
            if (filter == chip.dataset.filter) return
            filter = chip.dataset.filter
            loadTests()
        })
    });
    if (!cache.has('all_tests_list')) {
        const resp = await fetchData('/tests/list-all')
        if (!resp || !resp?.success) {
            return emptyState('Something went worng', resp?.message || "Failed to load tests")
        }
        allTests = resp.data
        cache.set('all_tests_list', allTests, 10 * 60 * 1000)
        loadTests()
    } else {
        allTests = cache.get('all_tests_list')
        loadTests()
    }
    function renderTestList(tests) {
        if (tests.length === 0) {
            testList.innerHTML = emptyState("No Tests Found", "Try adjusting your search or filters")
            return
        }
        testList.innerHTML = tests.map(test => {
            const statusClass = test.entryType === 'locked' ? 'bg-orange-100/50 text-orange-600' : 'bg-green-100/50 text-green-600'
            return `
                  <div class="bg-card rounded-lg border p-4">
                  <div class="flex items-center justify-between mb-2">
                  <div class="flex items-center gap-2 cursor-pointer">
                  <img 
                  src="${test.testCreator.profile}" 
                  class="w-6 h-6 rounded-full border" 
                  alt="creator"
                  />
             <span class="${test.testCreator.verified ? 'text-blue-600' : 'text-secondary'} font-medium">
             ${test.testCreator.username}
            </span>
        ${test.testCreator.verified
                    ? '<svg stroke="currentColor" onclick="showVerifyInfo()" id="verifyIcon" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="text-blue-500 w-4 h-4" xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0z"></path><path d="M23 12l-2.44-2.79.34-3.69-3.61-.82-1.89-3.2L12 2.96 8.6 1.5 6.71 4.69 3.1 5.5l.34 3.7L1 12l2.44 2.79-.34 3.7 3.61.82L8.6 22.5l3.4-1.47 3.4 1.46 1.89-3.19 3.61-.82-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81 1.48-1.48 2.32 2.33 5.85-5.87 1.48 1.48-7.33 7.35z"></path></svg>'
                    : ''
                }
</div>
 <span class="${statusClass} px-2 py-1 font-medium text-xs rounded-lg" style="letter-spacing:0.7px">${test.entryType.toUpperCase()}</span>
</div>

<div class="font-semibold">${test.title}</div>
                    <div class="flex mt-1">
                        <div class="flex-1">
                            <div class="flex gap-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                    class="w-4 h-4 text-indigo-400">
                                    <path fill="currentColor"
                                        d="M133.8 36.3c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 158 47 153L7 113C-2.3 103.6-2.3 88.4 7 79S31.6 69.7 41 79l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zm0 160c10.9 7.6 13.5 22.6 5.9 33.4l-56 80c-4.1 5.8-10.5 9.5-17.6 10.1S52 318 47 313L7 273c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l19.8 19.8 39.6-56.6c7.6-10.9 22.6-13.5 33.4-5.9zM224 96c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zm0 160c0-17.7 14.3-32 32-32l224 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0c-17.7 0-32-14.3-32-32zM160 416c0-17.7 14.3-32 32-32l288 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-288 0c-17.7 0-32-14.3-32-32zM64 376a40 40 0 1 1 0 80 40 40 0 1 1 0-80z" />
                                </svg>
                                <span class="text-gray-900 text-sm font-medium">
                                    ${test.totalQuestions} Questions • ${test.totalMarks} Marks • ${test.duration} mins
                                </span>
                            </div>
                            <div class="flex gap-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"
                                    class="w-4 h-4 text-indigo-400">
                                    <path fill="currentColor"
                                        d="M128 0c17.7 0 32 14.3 32 32l0 32 128 0 0-32c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-32c0-17.7 14.3-32 32-32zM64 240l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm128 0l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM64 368l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zm112 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16z" />
                                </svg>
                                <span class="text-gray-900 text-sm font-medium">
                                    ${new Date(test.publishedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: "2-digit", minute: "2-digit", hour12: true })}
                                </span>
                            </div>
                        </div>
                        <div class="cursor-pointer flex flex-col justify-center items-center gap-[1px]"  onclick="navigate('/tests/${test._id}')">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                class="w-8 h-8 py-1 px-2 text-white bg-primary rounded-full">
                                <path fill="currentColor"
                                    d="M502.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L402.7 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l370.7 0-105.4 105.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z" />
                            </svg>
                            <span class="text-xs font-semibold">
                                Attempt
                            </span>
                        </div>
                    </div>
                </div>
                    `
        }).join('')
    }
    async function loadTests(type = "filter", query = "") {
        testList.innerHTML = skeleton(5)
        if (type === "filter") {
            const currentTests = [...allTests]
            currentTests.sort((a, b) => {
                if (filter == "newset") return b.publishedAt - a.publishedAt
                else if (filter == "oldest") return a.publishedAt - b.publishedAt
                else if (filter == "popular") {
                    if (b.totalUsersAttempted !== a.totalUsersAttempted) return b.totalUsersAttempted - a.totalUsersAttempted
                    if (a.totalAttemptsCount !== b.totalAttemptsCount) return b.totalAttemptsCount - a.totalAttemptsCount
                    return b.publishedAt - a.publishedAt
                }
            })
            renderTestList(currentTests)
        } else {
            const currentTests = allTests.filter(t =>
                t.title.toLowerCase().includes(query.toLowerCase()) ||
                t.testCreator.username.toLowerCase().includes(query.toLowerCase())
            )
            renderTestList(currentTests)
        }
    }
}