// ============================================
//! CONFIGS
// ============================================
const APP_STATE = {
    currentRoute: '/',
    visitedRoutes: [],
    user: null,
    isLoggedIn: false,
    modalOpen: false,
    drawerOpen: false,
    isOffline: false,
}
// ! Caches
class Cache {
    constructor({ maxEntries = 200 } = {}) {
        this.map = new Map()
        this.max = maxEntries
    }
    set(key, val, exp = 5 * 60 * 1000) {
        const entry = { val, exp: Date.now() + exp }
        if (this.map.has(key)) this.map.delete(key)
        this.map.set(key, entry)
        if (this.map.size > this.max) {
            const oldest = this.map.keys().next().value
            this.map.delete(oldest)
        }
    }
    get(key) {
        const e = this.map.get(key)
        if (!e) return null
        if (Date.now() > e.exp) {
            this.map.delete(key)
            return null
        }
        return e.val
    }
    has(key) {
        return this.get(key) !== null
    }
    delete(key) {
        this.map.delete(key)
    }
    clear() {
        this.map.clear()
    }
    clearExpired() {
        const now = Date.now()
        for (const [k, e] of this.map) {
            if (now > e.exp) {
                this.map.delete(k)
            }
        }
    }
}
const cache = new Cache({ maxEntries: 100 })
const clearCacheInterval = setInterval(() => {
    cache.clearExpired()
}, 60 * 1000)
// ! SandBox 
const Sandbox = {
    current: null,
    create(pageName) {
        if (this.current && this.current.destroy) {
            this.current.destroy()
        }
        const box = {
            name: pageName,
            intervals: [],
            timeouts: [],
            events: [],
            variables: [],
            var(name, value) {
                this.variables.push(name)
                window[name] = value
            },
            setInterval(fn, ms) {
                const id = setInterval(fn, ms)
                this.intervals.push(id)
                return id
            },
            setTimeout(fn, ms) {
                const id = setTimeout(fn, ms)
                this.timeouts.push(id)
                return id
            },
            addEvent(target, event, listener) {
                target.addEventListener(event, listener)
                this.events.push({ target, event, listener })
            },
            destroy() {
                this.variables.forEach(v => delete window[v])
                this.intervals.forEach(clearInterval)
                this.timeouts.forEach(clearTimeout)
                this.events.forEach(e => e.target.removeEventListener(e.event, e.listener))
            }
        }
        this.current = box
        return box
    }
}
function isTokenExpire(token) {
    try {
        let payload = JSON.parse(atob(token.split('.')[1]))
        let expireTime = payload.exp * 1000
        return Date.now() >= expireTime
    } catch (e) { return true }
}

async function refreshToken() {
    let refresh_token = localStorage.getItem("REFRESH_TOKEN")
    if (!refresh_token || isTokenExpire(refresh_token)) return false
    try {
        let fetchUrl = location.origin + '/api' + '/auth/refresh-token'
        let res = await fetch(fetchUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ token: refresh_token })
        })
        const json_data = await res.json() || {}
        if (json_data.success) {
            const data = json_data.data
            localStorage.setItem('TOKEN', data.access_token)
            localStorage.setItem('REFRESH_TOKEN', data.refresh_token)
            return true
        }
        return false
    }
    catch (e) {
        console.error(e)
        return false
    }
}
const verifyToken = async () => {
    let access_token = localStorage.getItem("TOKEN")
    if (!access_token || isTokenExpire(access_token)) {
        return await refreshToken()
    }
    else {
        let res = await fetchData('/auth/verify-token', "POST", { token: access_token })
        if (res?.success) return true
        return await refreshToken()
    }
}
const fetchData = async (url, method = "GET", body = {}) => {
    let token = localStorage.getItem("TOKEN") || ''
    if (isTokenExpire(token)) {
        await refreshToken()
        token = localStorage.getItem("TOKEN") || ''
    }
    const fetchUrl = location.origin + '/api' + url
    const headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + token
    }
    try {
        const res = await fetch(fetchUrl, {
            method,
            headers,
            body: method === "GET" ? undefined : JSON.stringify(body)
        })
        const data = await res.json()
        if (!data) return null
        if (!data.success && data.type === "TokenError") {
            if (await verifyToken()) {
                return await fetchData(url, method, body)
            }
        }
        return data
    }
    catch (e) {
        console.error(e)
        return null
    }
}
//! ============================================
// UI FUNCTIONS
//! ============================================

//! TOAST NOTIFICATIONS
function toast(message, type = 'normal', duration = 2500) {
    const container = document.getElementById('toastContainer');
    const toastEl = document.createElement('div');
    toastEl.className = `toast ${type}`;
    const icon = type === 'success' ? '✓' : type === 'error' ? '✕' : '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="w-4 h-4"><path fill="currentColor" d="M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-192a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm0-192c-18.2 0-32.7 15.5-31.4 33.7l7.4 104c.9 12.6 11.4 22.3 23.9 22.3 12.6 0 23-9.7 23.9-22.3l7.4-104c1.3-18.2-13.1-33.7-31.4-33.7z"/></svg>'
    toastEl.innerHTML = `<span style="font-size: 18px;">${icon}</span><span>${message}</span>`;
    container.appendChild(toastEl);
    setTimeout(() => {
        toastEl.style.opacity = '0';
        toastEl.style.transform = 'translateY(-20px)';
        setTimeout(() => toastEl.remove(), 300);
    }, duration);
}
//! MODAL MANAGEMENT
function openModal(title, content) {
    const modal = document.getElementById('fullModal')
    const modalTopBar = document.getElementById('modalTopBar')
    const modalTitle = document.getElementById('modalTitle')
    const modalContent = document.getElementById('modalContent')
    setTimeout(() => { modalContent.scrollTop = 0 }, 10)
    modalTitle.textContent = title
    modalContent.innerHTML = content
    modalTopBar.classList.remove('hidden')
    modal.classList.remove('hidden')
    APP_STATE.modalOpen = true
    const app = document.getElementById('app')
    app.innerHTML = `<div class="flex items-center justify-center h-full">
            <div class="text-center">
                <div class="inline-block animate-spin rounded-full h-12 w-12 border-2 border-gray loader"></div>
                <p class="mt-4 text-gray-500">Loading...</p>
            </div>
        </div>`
}
function closeModal() {
    const modal = document.getElementById('fullModal')
    const modalTitle = document.getElementById('modalTitle')
    const modalContent = document.getElementById('modalContent')
    modalTitle.textContent = ""
    modalContent.innerHTML = ""
    modal.classList.add('hidden')
    APP_STATE.modalOpen = false
}
document.getElementById('modalBack').addEventListener('click', () => {
    closeModal()
    history.back()
})

//! POPUP MODAL 
const popUp = {
    show(content) {
        setTimeout(() => {
            document.getElementById("popUp").innerHTML = content
            document.getElementById("popUpModal").classList.remove('hidden')
        }, 50)
    },
    hide() {
        document.getElementById("popUpModal").classList.add('hidden')
        document.getElementById("popUp").innerHTML = ""
    }
}
//! Display 
const display = {
    open(content = "") {
        document.getElementById("displayHtml").innerHTML = content
        setTimeout(() => {
            document.getElementById("display").classList.remove('hidden')
        }, 50)
    },
    close() {
        document.getElementById("display").classList.add('hidden')
        document.getElementById("displayHtml").innerHTML = ""
    }
}

//! SIDE MENU
function openSideMenu() {
    const menu = document.getElementById('sideMenu');
    const overlay = document.getElementById('sideMenuOverlay');
    overlay.classList.remove('hidden');
    menu.style.transform = 'translateX(0)';
}
function closeSideMenu() {
    const menu = document.getElementById('sideMenu');
    const overlay = document.getElementById('sideMenuOverlay');
    menu.style.transform = 'translateX(-100%)';
    overlay.classList.add('hidden');
}
//! VERIFY ICON INFO
function showVerifyInfo() {
    openDrawer(`
                <div class="flex flex-col items-center">
             <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" class="text-blue-500 w-16 h-16"xmlns="http://www.w3.org/2000/svg"><path fill="none" d="M0 0h24v24H0z"></path><path d="M23 12l-2.44-2.79.34-3.69-3.61-.82-1.89-3.2L12 2.96 8.6 1.5 6.71 4.69 3.1 5.5l.34 3.7L1 12l2.44 2.79-.34 3.7 3.61.82L8.6 22.5l3.4-1.47 3.4 1.46 1.89-3.19 3.61-.82-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81 1.48-1.48 2.32 2.33 5.85-5.87 1.48 1.48-7.33 7.35z"></path></svg>
  <h3 class="text-xl font-semibold py-2">Verified Account</h3>
<p class="text-secondary text-center">
This account has been <span class="text-primary font-semibold">officially verified</span> by the 
<span class="font-semibold">Nexa Admin Team</span> for its <span class="font-semibold">authenticity</span> and 
<span class="font-semibold">content quality</span>.<br>
Verified creators receive <span class="font-semibold">higher visibility</span>, 
<span class="font-semibold">better trust</span>, and <span class="font-semibold">priority placement</span> in search and listings.
<br>Verified creators are <span class="font-semibold">trusted members</span> of the Nexa community who consistently provide valuable and reliable content.
 </p>
        </div>
            `)
}
//! DRAWER MANAGEMENT
const backdrop = document.getElementById('drawerOverlay');
const sheet = document.getElementById('sheet');
const sheetInner = document.getElementById('sheetInner');
const cancelBtn = document.getElementById('cancelBtn');
let startY = 0;
let currentY = 0;
let sheetHeight = 0;
APP_STATE.drawerOpen = false
const THRESHOLD = 120;
const MAX_OPACITY = 0.4;
function disableScroll() { document.body.style.overflow = 'hidden' }
function enableScroll() { document.body.style.overflow = '' }
function openDrawer(content) {
    if (content) {
        document.getElementById("drawerHtml").innerHTML = content
    }
    cancelBtn.style.transitionDelay = "0.3s";
    cancelBtn.style.top = "-28px";
    cancelBtn.style.rotate = "-90deg"
    sheet.classList.remove('translate-y-full');
    sheet.style.transform = 'translateY(0)';
    backdrop.style.opacity = MAX_OPACITY;
    backdrop.classList.remove('pointer-events-none')
    backdrop.classList.remove('hidden')
    APP_STATE.drawerOpen = true
    disableScroll();
    sheetHeight = sheetInner.getBoundingClientRect().height;
    cancelBtn.style.transitionDelay = "";
}
function closeDrawer() {
    cancelBtn.style.rotate = "90deg"
    cancelBtn.style.top = "50px"
    sheet.style.transform = `translateY(100%)`;
    backdrop.style.opacity = 0;
    backdrop.classList.add('hidden')
    backdrop.classList.add('pointer-events-none');
    APP_STATE.drawerOpen = false;
    enableScroll();
    setTimeout(() => sheet.classList.add('translate-y-full'), 300);
}
backdrop.addEventListener('click', closeDrawer);
cancelBtn.addEventListener('click', closeDrawer);
sheetInner.addEventListener('touchstart', (e) => {
    if (!APP_STATE.drawerOpen || e.target.closest("div").id == "drawerHtml") return;
    startY = e.touches[0].clientY
    sheetInner.classList.remove('sheet-transition')
}, { passive: true });
sheetInner.addEventListener('touchmove', (e) => {
    if (!APP_STATE.drawerOpen || e.target.closest.id == "drawerHtml") return;
    currentY = e.touches[0].clientY;
    const diff = Math.max(0, currentY - startY);
    const pct = Math.min(diff / sheetHeight, 1);
    sheet.style.transform = `translateY(${pct * 100}%)`;
    backdrop.style.opacity = Math.max(0, MAX_OPACITY * (1 - pct));
}, { passive: true });
sheetInner.addEventListener('touchend', (e) => {
    if (!APP_STATE.drawerOpen || e.target.closest.id == "drawerHtml") return;
    sheetInner.classList.add('sheet-transition');
    const diff = currentY - startY;
    if (diff > THRESHOLD) {
        closeDrawer()
    } else {
        sheet.style.transform = 'translateY(0)';
        backdrop.style.opacity = MAX_OPACITY;
    }
    startY = currentY = 0;
})
//! KEYBOARD NAVIVATION
function initKeyboardNav() {
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (APP_STATE.drawerOpen) {
                closeDrawer()
            }
            else if (APP_STATE.modalOpen) {
                history.back()
            }
        }
    })
}
//! RENDER TESTS CARD   
function renderTestList(container, tests, showActions = false) {
    if (tests.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2">
                        </path>
                    </svg>
                <h3>No Tests Found</h3>
                <p>Try adjusting your search or filters</p>
            </div>
        `;
        return;
    }

    container.innerHTML = tests.map(test => `
        <div class="test-card" onclick="navigate('/tests/${test.id}')">
            ${test.isLocked ? '<div class="test-card-lock">' + `<svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zM9 7c0-1.654 1.346-3 3-3s3 1.346 3 3v3H9V7z"/></svg>` + '</div>' : ''}
            <div class="test-card-avatar" style="background: ${test.color}">
                ${getInitials(test.subject)}
            </div>
            <div class="test-card-content">
                <div class="test-card-title">${test.title}</div>
                <div class="test-card-meta">
                    <span class="test-card-chip chip-${test.visibility}">${test.visibility === 'users' ? 'Only Users' : test.visibility}</span>
                    <span>${test.questionCount} Q</span>
                    <span>${test.maxMarks} marks</span>
                    <span>${test.duration} min</span>
                </div>
            </div>
            <div class="test-card-action">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                </svg>
            </div>
        </div>
    `).join('');
}

//! NETWORK
function checkOnlineStatus() {
    const isOnline = navigator.onLine;
    const banner = document.querySelector('.offline-banner') || createOfflineBanner();
    if (!isOnline && !APP_STATE.isOffline) {
        APP_STATE.isOffline = true;
        banner.classList.add('show');
        toast('You are offline. Using cached data.', 'normal');
    } else if (isOnline && APP_STATE.isOffline) {
        APP_STATE.isOffline = false;
        banner.classList.remove('show');
        toast('Back online!', 'success');
    }
}
function createOfflineBanner() {
    const banner = document.createElement('div');
    banner.className = 'offline-banner';
    banner.textContent = '⚠ Offline Mode - Using cached data';
    document.body.appendChild(banner);
    return banner;
}
//! Top Loader
const loader = {
    topLoader: null,
    loaderTimer: null,
    start() {
        document.getElementById('topLoaderWrap').style.display = "block"
        clearInterval(this.loaderTimer);
        this.topLoader.style.width = '3%';
        this.topLoader.style.opacity = '1';
        let percent = 3;
        this.loaderTimer = setInterval(() => {
            const increment = Math.random() * (percent < 40 ? 4 : percent < 70 ? 2 : 0.5);
            percent = Math.min(90, percent + increment);
            this.topLoader.style.width = percent + '%';
        }, 100);
    },
    finish() {
        clearInterval(this.loaderTimer);
        this.topLoader.style.width = '100%';
        setTimeout(() => {
            this.topLoader.style.opacity = '0';
            this.topLoader.style.width = '0%';
        }, 300);
    }
}
async function initNavBar() {
    const isAdminRoute = window.location.pathname.startsWith("/admin")
    let navBars
    if (isAdminRoute && APP_STATE.user?.role === "admin") { navBars = await import('/src/components/AdminNav.js') }
    else { navBars = await import('/src/components/NavBar.js') }
    document.getElementById("topNav").innerHTML = await navBars.TopNav()
    document.getElementById("sideMenu").innerHTML = await navBars.SideMenu()
    document.getElementById("bottomTabs").innerHTML = await navBars.BottomNav()
    document.getElementById("topNav").classList.add("border-b")
    document.getElementById("bottomTabs").classList.add("border-t")
    document.getElementById('sideMenuOverlay').addEventListener('click', closeSideMenu)
    document.getElementById('menuBtn').addEventListener('click', openSideMenu)
}
function initUiFunctions() {
    document.getElementById('popUpModal').addEventListener('click', (e) => { if (e.target.classList.contains("modal-overlay")) popUp.hide() })
    window.addEventListener('online', checkOnlineStatus)
    window.addEventListener('offline', checkOnlineStatus)
    loader.topLoader = document.getElementById('topLoader')
    window.showVerifyInfo = showVerifyInfo
    window.closeDrawer = closeDrawer
    window.openDrawer = openDrawer
    window.closeModal = closeModal
    window.openModal = openModal
    window.loader = loader
    window.popUp = popUp
    window.display = display
    window.toast = toast
    // checkOnlineStatus()
    initKeyboardNav()
    window.renderTestList = renderTestList
}
// ============================================
//! SPA ROUTER SYSTEM
// ============================================
//! Routes
const routes = [
    {
        path: '/',
        page: 'Home',
        title: 'Home'
    },
    {
        path: '/explore',
        page: 'Explore',
        title: 'Explore Tests'
    },
    {
        path: '/tests/:testId',
        page: 'TestDetail',
        fullModal: true,
        lazy: true,
        title: 'Test Details'
    },
    {
        path: '/results',
        page: 'Results',
        title: 'Results'
    },
    {
        path: '/attempts/:attemptId/solutions',
        page: 'Solutions',
        fullModal: true,
        guard: 'auth',
        title: 'Solutions'
    },
    {
        path: '/results/:testId',
        page: 'TestResult',
        guard: 'auth',
        fullModal: true,
        title: 'My Result'
    },
    {
        path: '/create',
        page: 'create/Create',
        title: 'Create Test'
    },
    {
        path: '/tests/:testId/dashboard',
        page: 'create/Dashboard',
        guard: 'auth',
        title: 'Test Dashboard',
        fullModal: true
    },
    {
        path: '/tests/:testId/results',
        page: 'create/Results',
        guard: 'auth',
        title: 'Test Results',
        fullModal: true
    },
    {
        path: '/tests/:testId/attempt',
        page: '/Attempt',
        guard: 'auth',
        title: 'Attempt Test',
        fullModal: true
    },
    {
        path: '/tests/:testId/edit',
        page: 'create/EditTest',
        guard: 'auth',
        title: 'Edit Test',
        fullModal: true
    },
    {
        path: '/tests/:testId/questions',
        page: 'create/Questions',
        guard: 'auth',
        title: 'Questions',
        fullModal: true
    },
    {
        path: '/tests/:testId/questions/:qId/edit',
        page: 'create/EditQuestions',
        guard: 'auth',
        title: 'Edit Question',
        fullModal: true
    },
    {
        path: '/profile',
        page: 'user/Profile',
        guard: 'auth',
        fullModal: true,
        title: 'Profile'
    },
    {
        path: '/settings',
        page: 'app/Settings',
        fullModal: false,
        title: 'Settings'
    },
    {
        path: '/support/faq',
        page: 'support/Faq',
        fullModal: true,
        title: 'Frequently Ask Questions'
    },
    {
        path: '/support/chat',
        page: 'support/Chat',
        fullModal: true,
        lazy: true,
        guard: 'auth',
        title: 'Support Chat'
    },
    {
        path: '/login',
        page: 'app/Login',
        guard: 'guestOnly',
        fullModal: true,
        title: 'Login'
    },
    {
        path: '/logout',
        page: 'user/Logout',
        guard: 'auth',
        title: 'Logout'
    },
    {
        path: '/admin',
        page: 'admin/Admin',
        guard: 'admin',
        title: 'Welcome-admin'
    },
    {
        path: '/user/change-password',
        page: 'user/ChangePassword',
        guard: 'auth',
        fullModal: true,
        title: 'Change Password'
    },
    {
        path: '/user/change-username',
        page: 'user/ChangeUsername',
        guard: 'auth',
        fullModal: true,
        title: 'Change Username'
    },
    {
        path: '/app/about',
        page: 'app/About',
        fullModal: true,
        title: 'About'
    },
    {
        path: '/social-links',
        page: 'app/SocialLink',
        fullModal: true,
        title: 'Social Links'
    }
]
function pathToRegex(path) {
    const paramNames = [];
    const regexPath = path
        .replace(/\//g, '\\/')
        .replace(/:\w+\?/g, (match) => {
            paramNames.push(match.slice(1, -1));
            return '(?:\\/([^\\/]+))?';
        })
        .replace(/:\w+/g, (match) => {
            paramNames.push(match.slice(1));
            return '([^\\/]+)';
        });
    return { regex: new RegExp('^' + regexPath + '$'), paramNames };
}
const compiledRoutes = routes.map(r => {
    const { regex, paramNames } = pathToRegex(r.path);
    return { ...r, regex, paramNames };
});

async function router() {
    const path = window.location.pathname || '/';
    if (APP_STATE.visitedRoutes.includes(path)) {
        document.getElementById('topLoaderWrap').style.display = "none"
    } else {
        loader.start()
        APP_STATE.visitedRoutes.push(path)
    }
    APP_STATE.currentRoute = path
    closeSideMenu()
    closeDrawer()
    display.close()
    popUp.hide()
    window.dispatchEvent(new Event("app_page_change"))
    for (let route of compiledRoutes) {
        const match = path.match(route.regex);
        if (match) {
            try {
                const params = {}
                route.paramNames.forEach((name, i) => { params[name] = match[i + 1] || null })
                const pageName = route.page.split('/').at(-1)
                updateActiveTab()
                if (route.lazy && APP_STATE.visitedRoutes.includes(path)) {
                    loader.start()
                }
                if (route.guard) {
                    let guard = await import(`/src/guard/${route.guard}.js`)
                    if (!guard.default(params)) return
                }
                document.title = route.title
                let module = await import(`/src/pages/${route.page}.js`)
                let html = await module[pageName](params)
                if (route.fullModal) { openModal(route.title, html) }
                else {
                    const app = document.getElementById('app');
                    app.innerHTML = html
                    closeModal()
                    app.scrollTop = 0;
                }
                const box = Sandbox.create(pageName)
                if (module.init) module.init(params, box)
                loader.finish()
                return
            } catch (error) {
                console.error(error);
                toast("Something went wrong", "error");
                loader.finish()
                navigate('/')
                return
            }
        }
    }
    loader.finish()
    const app = document.getElementById('app');
    let module = await import(`/src/pages/NotFoundPage.js`)
    app.innerHTML = await module['NotFoundPage']()
    closeModal()
    document.title = "Page Not Found"
    updateActiveTab()
}

function navigate(path) {
    if (path === location.pathname) { closeSideMenu(); return }
    if (APP_STATE.isOffline && !APP_STATE.visitedRoutes.includes(path)) {
        toast("You're offline. Try again when you're connected.", "error")
        return
    }
    history.pushState({}, '', path)
    router()
}
function updateActiveTab() {
    let path = location.pathname
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => {
        tab.classList.remove('active');
        const tabPath = tab.getAttribute('href')
        if (path === tabPath || (path.startsWith(tabPath) && tabPath !== '/')) {
            tab.classList.add('active')
        } else if (path === '/' && tabPath === '/') {
            tab.classList.add('active')
        }
    });
}
// ============================================
// INITIALIZATION
// ============================================
async function init() {
    let faltu = await import("/src/faltu.js")
    faltu.init()
    APP_STATE.isLoggedIn = await verifyToken()
    if (APP_STATE.isLoggedIn) {
        let userResp = await fetchData('/users/self')
        if (userResp && userResp?.success) {
            localStorage.setItem("user", JSON.stringify(userResp.data))
            APP_STATE.user = { name: userResp.data.fullname, ...userResp.data };
        }
    }
    window.initNavBar = initNavBar
    window.APP_STATE = APP_STATE
    window.fetchData = fetchData
    window.navigate = navigate
    window.cache = cache
    await initNavBar()
    await initUiFunctions()
    window.addEventListener('popstate', router)
    document.body.addEventListener('click', (e) => {
        const link = e.target.closest('a[href]')
        if (link && link.origin === location.origin) {
            e.preventDefault()
            let newPath = link.getAttribute('href')
            if (newPath == APP_STATE.currentRoute) closeSideMenu()
            navigate(newPath)
        }
    })
    router()
}
document.addEventListener('DOMContentLoaded', init)