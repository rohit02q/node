//! CONFIG 
const fetchData = async (url, method = "GET", body = {}) => {
    let token = localStorage.getItem("TOKEN") || ""
    let fetchUrl = location.origin + '/api' + url
    let headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + token
    }
    try {
        let res = await fetch(fetchUrl, {
            method,
            headers,
            body: method === "GET" ? undefined : JSON.stringify(body)
        })
        return await res.json()
    }
    catch (e) {
        console.log(e);
        return null
    }
}
const verifyToken = async () => {
    let access_token = localStorage.getItem("token")
    function isTokenExpire(token) {
        try {
            let payload = JSON.parse(atob(token.split('.')[1]))
            let expireTime = payload.exp * 1000
            return Date.now() >= expireTime
        } catch (e) { return true }
    }
    async function refreshToken() {
        let refresh_token = localStorage.getItem("REFRESH_TOKEN")
        if (!refresh_token || isTokenExpire(refresh_token)) return false
        let res = await fetchData('/auth/refresh-token', "POST", { token: refresh_token })
        if (res.success) {
            let data = res.data
            localStorage.setItem('token', data.access_token)
            localStorage.setItem('REFRESH_TOKEN', data.refresh_token)
            return true
        }
        return false
    }
    if (!access_token || isTokenExpire(access_token)) {
        return await refreshToken()
    }
    else {
        let res = await fetchData('/auth/verify-token', "POST", { token: access_token })
        if (res.success) return true
        return await refreshToken()
    }
}

//* Document Elements
const timerText = document.querySelectorAll('#timer')
const question_loader = document.querySelector('.question_loader')
const questionText = document.getElementById('question');
const Q_marks = document.querySelector('.Q-marks');
const Q_type = document.querySelector('.Q-type');
const Q_boxes = document.querySelector('.Q-boxes')
const Q_Img = document.querySelector('.Q-img');
const reviewBtn = document.getElementById('review-checkbox');
const answerInputDiv = document.querySelector('.inputAns');
const answerInput = document.getElementById('answerInput')
const textOptions = document.querySelector('.text-opt');
const option_selection_box = document.querySelector('.option-section')
//* Variables
let testId;
let testMeta;
let attemptId
let totalQuestions;
let duration;
let timeGap;
let notVisitedQuestions;
let currentIndex = 0;
let timeSpent = {}
let focusGuard = {}
let awayTime = 0
let tabSwitchCount = 0
let questionStartTime = null
let questionIds = [];
let userAnswers = {};
let questionsCache = {}
let answersList = []
let reviewList = []
let answeredAndMarkedList = []
let syncInterval = null
let SYNC_INTERVAL_TIME;
function currentQuestionId() { return questionIds[currentIndex] }
const popUp = (tittle, description, type = "ok") => {
    let alertModal = document.querySelector('.alert-modal');
    alertModal.style.display = 'flex';
    alertModal.innerHTML = `
            <div class="main-box">
            <h3>${tittle}</h3>
            <p>${description}</p>
            <button onclick="${type == "back" ? "window.history.back" : (type == 'submit' ? `location.replace('/results/${testId}')` : "hideModal")}()">
            ${type == "back" ? "BACK" : (type == 'submit' ? " View Result " : "Okay")}
            </button>
        </div>
    `;
}
const startTest = async () => {
    sessionStorage.clear()
    let query = new URLSearchParams(location.search)
    let type = query.get('type') || null
    testId = location.pathname.split("/").at(-2) || null
    let res = await fetchData(`/tests/${testId}/start-test?type=${type}`)
    if (!res || !res.success) {
        popUp(res?.type || "❌ <br>Error", res?.message || "Something went wrong", res?.submitted == true ? "submit" : "back");
        return
    }
    setAllVariables(res.data)
    initializeTest()
}
function setAllVariables(data) {
    testMeta = data.testMeta
    attemptId = data.attemptId
    timeGap = Date.now() - data.serverTime
    SYNC_INTERVAL_TIME = data.attemptSyncInterval
    questionIds = data.questionIds
    userAnswers = data.userAnswers
    timeSpent = data.timeSpent
    focusGuard = data.focusGuard
    awayTime = data.awayTime
    tabSwitchCount = data.tabSwitchCount
}
const initializeTest = () => {
    document.title = testMeta.title;
    totalQuestions = questionIds.length
    duration = (testMeta.duration) * 60; // In Seconds
    notVisitedQuestions = totalQuestions;
    questionIds.forEach((id, index) => {
        if (userAnswers[id]?.value != null) {
            answersList.push(index)
        }
    })
    for (let i = 0; i < totalQuestions; i++) {
        let box = document.createElement('div')
        box.className = 'box';
        if (answersList.includes(i)) { box.classList.add('visited') }
        box.id = `box-${i}`;
        box.innerHTML = i + 1;
        Q_boxes.append(box);
    }
    updateBoxColor()
    renderQuestion(currentIndex)
    startSyncInterval()
    timer()
    stopLoader()
}

async function loadQuestion(index) {
    let questionId = questionIds[index]
    if (questionsCache[questionId]) return questionsCache[questionId]
    let resp = await fetchData(`/attempts/${attemptId}/questions/${questionId}`)
    if (!resp || !resp.success) {
        toast(resp?.message || "Fail to load question")
        return null
    }
    questionsCache[questionId] = resp.data
    return resp.data
}

async function preloadQuestion(index) {
    if (index == totalQuestions - 1) return
    await loadQuestion(index + 1)
    if (index == 0) return
    await loadQuestion(index - 1)
}
const renderQuestion = async (qId) => {
    questionStartTime = Date.now()
    question_loader.style.display = "flex"
    document.querySelector("#Q-num").innerHTML = qId + 1;
    // Remove previous question data
    questionText.innerHTML = "";
    Q_Img.style.display = 'none';
    textOptions.style.display = 'none'
    answerInputDiv.style.display = 'none'
    option_selection_box.style.display = 'none'
    let newQuestion = await loadQuestion(qId)
    if (!newQuestion) return
    let { text, options, marks, type, image } = newQuestion;
    questionText.innerHTML = text;
    if (image && image !== "") {
        Q_Img.querySelector('img').src = image;
        Q_Img.style.display = 'block';
    }
    if (type == "mcq") {
        textOptions.style.display = 'block'
        option_selection_box.style.display = 'grid'
        document.querySelectorAll(`.opt-text`).forEach((c) => {
            c.innerHTML = ''
        })
        if (!options) options = []
        options.forEach((option_text, i) => {
            let curOption = document.querySelector(`.txt-opt-${i}`);
            curOption.innerHTML = `(${['A', 'B', 'C', 'D'][i]}) ${option_text}`
        })
    }
    else {
        answerInput.value = ""
        answerInputDiv.style.display = 'flex'
    }
    Q_type.innerHTML = `Type: ${type == "mcq" ? "MCQ" : "Numeric"}`
    Q_marks.innerHTML = `Marks: <span style='color:rgb(22,163,74);font-weight:600;'>+${marks.correct}</span> <span style='color:rgb(220,38,38);font-weight:700;'>${marks.wrong}</span>`
    showOldSelectedAnswer();
    question_loader.style.display = "none"
    Q_box_border()
    preloadQuestion(qId)
}

const updateBoxColor = () => {
    document.getElementById('Answered').innerText = answersList.length;
    document.getElementById('MarkforReview').innerText = reviewList.length;
    document.getElementById('aAndm').innerText = answeredAndMarkedList.length;
    document.getElementById('NotAnswersed').innerText = totalQuestions - (notVisitedQuestions + answersList.length + reviewList.length + answeredAndMarkedList.length);
    let boxes = Q_boxes.querySelectorAll('.box')
    boxes.forEach((e, i) => {
        e.classList.remove('answered');
        e.classList.remove('marked');
        e.classList.remove('ansAndMarked');
        if (answersList.includes(i)) {
            e.classList.add('answered')
        }
        else if (reviewList.includes(i)) {
            e.classList.add('marked')
        }
        else if (answeredAndMarkedList.includes(i)) {
            e.classList.add('ansAndMarked')
        }
    })
    change_box_color()
}

const updateAnswersList = (s) => {
    if (s == 1) {
        if (!answersList.includes(currentIndex)) {
            if (reviewList.includes(currentIndex)) {
                answeredAndMarkedList.push(currentIndex)
                let i = reviewList.indexOf(currentIndex)
                reviewList.splice(i, 1)
            }
            else if (!answeredAndMarkedList.includes(currentIndex)) {
                answersList.push(currentIndex)
            }
        }
    }
    else if (s == 0) {
        if (answeredAndMarkedList.includes(currentIndex)) {
            reviewList.push(currentIndex)
            let i = answeredAndMarkedList.indexOf(currentIndex)
            answeredAndMarkedList.splice(i, 1)
        }
        else {
            let i = answersList.indexOf(currentIndex)
            answersList.splice(i, 1)
        }
    }
    updateBoxColor()
}

reviewBtn.addEventListener('change', () => {
    if (!reviewBtn.checked) {
        document.getElementById('mark-text').innerText = "Mark for Review"
        if (answeredAndMarkedList.includes(currentIndex)) {
            answersList.push(currentIndex)
            let i = answeredAndMarkedList.indexOf(currentIndex)
            answeredAndMarkedList.splice(i, 1)
        }
        else {
            let i = reviewList.indexOf(currentIndex)
            reviewList.splice(i, 1)
        }
    }
    else {
        document.getElementById('mark-text').innerText = "Marked for Review";
        toast('Marked for Review')
        if (answersList.includes(currentIndex)) {
            answeredAndMarkedList.push(currentIndex);
            let i = answersList.indexOf(currentIndex)
            answersList.splice(i, 1)
        }
        else {
            reviewList.push(currentIndex)
        }
    }
    updateBoxColor()
})

function timer() {
    const endTime = testMeta.endTime;
    const timerInterval = setInterval(() => {
        const now = Date.now() + timeGap;
        const remaining = Math.floor((endTime - now) / 1000); // in Seconds
        if (remaining <= 0) {
            clearInterval(timerInterval);
            timerText.forEach(t => t.innerHTML = "00:00");
            submitTest('timeout');
            popUp('⌛<br>Opp\'s Times Up', "The allotted time has ended and your test has been <b> auto-submitted <b> ", "submit")
            return;
        }
        if (remaining < 600) {
            timerText.forEach(t => {
                t.style.color = 'rgb(185,28,28)' // Red color
            })
        }

        let hrs = Math.floor(remaining / 3600);
        let mins = Math.floor((remaining % 3600) / 60);
        let secs = remaining % 60;
        let display;
        if (hrs > 0) {
            hrs = hrs < 10 ? `0${hrs}` : hrs;
            mins = mins < 10 ? `0${mins}` : mins;
            secs = secs < 10 ? `0${secs}` : secs;
            display = `${hrs}:${mins}:${secs}`;
        } else {
            mins = mins < 10 ? `0${mins}` : mins;
            secs = secs < 10 ? `0${secs}` : secs;
            display = `${mins}:${secs}`;
        }
        timerText.forEach(t => {
            t.innerHTML = display;
        });
    }, 1000);
}

function change_box_color() {
    let boxes = Q_boxes.querySelectorAll('.box')
    boxes.forEach((b, i) => {
        if (i !== currentIndex) {
            b.style.border = null
        }
        else {
            if (b.classList.contains('answered')) {
                b.style.border = '2px solid rgb(22 163 74)'
            }
            else if (b.classList.contains('marked')) {
                b.style.border = '2px solid rgb(79 70 229)'
            }
            else if (b.classList.contains('ansAndMarked')) {
                b.style.border = '2px solid rgb(202 138 4)'
            }
            else {
                b.style.border = '2px solid rgb(220 38 38)'
            }
        }
    })
}
function Q_box_border() {
    let boxes = Q_boxes.querySelectorAll('.box')
    boxes.forEach((b, i) => {
        if (i !== currentIndex) {
            b.style.border = null
        }
        else {
            if (!b.classList.contains('visited')) {
                b.style.border = '2px solid rgb(220 38 38)'
                notVisitedQuestions--;
                document.getElementById('visit').innerText = notVisitedQuestions
                document.getElementById('NotAnswersed').innerText = totalQuestions - (notVisitedQuestions + answersList.length + reviewList.length + answeredAndMarkedList.length);
                b.classList.add('visited')
            }
            else {
                change_box_color()
            }
        }
    })
}
Q_boxes.addEventListener('click', (e) => {
    if (e.target.classList.contains('box')) {
        let boxId = e.target.id.split('-')
        captureTimeSpent()
        currentIndex = parseInt(boxId[1])
        renderQuestion(currentIndex);
        document.querySelector('#menu-checkBtn').checked = false;
    }
})
document.querySelector('.btn-bar')
    .addEventListener("click", (e) => {
        if (e.target.classList.contains("back-btn")) {
            previousQuestion();
        }
        else if (e.target.classList.contains("next-btn")) {
            nextQuestion()
        }
    })
option_selection_box.addEventListener("click", (e) => {
    if (e.target.classList.contains("option")) {
        showSelectedOption(e);
    }
})

answerInput.addEventListener("input", () => {
    let ans = answerInput.value;
    if (ans == "") {
        saveAnswer(null)
        updateAnswersList(0)
    }
    else {
        saveAnswer(ans)
        updateAnswersList(1)
    }
})
const captureTimeSpent = () => {
    if (timeSpent[currentQuestionId()] != null) {
        timeSpent[currentQuestionId()] += Date.now() - questionStartTime
    }
    else {
        timeSpent[currentQuestionId()] = Date.now() - questionStartTime
    }
    // localStorage.setItem('timeSpent', JSON.stringify(timeSpent))
}
const saveAnswer = (value) => {
    let newAns = {
        value: value == null ? null : Number(value),
        ts: Date.now()
    }
    userAnswers[currentQuestionId()] = newAns;
    // localStorage.setItem('userAnswers', JSON.stringify(userAnswers))
    updateAnswersList(1)
}
const showSelectedOption = (e) => {
    if (e.target.classList.contains('marked')) {
        e.target.classList.remove('marked')
        saveAnswer(null)
        updateAnswersList(0)
    }
    else {
        document.querySelectorAll('.option').forEach(d => {
            d.classList.remove('marked')
        })
        e.target.classList.add('marked')
        let selectOptionIndex = e.target.querySelector('span').id[3];
        saveAnswer(selectOptionIndex)
    }
}
const nextQuestion = () => {
    if (currentIndex !== totalQuestions - 1) {
        captureTimeSpent()
        currentIndex += 1
        renderQuestion(currentIndex);
    }
    else {
        toast('This is the last Question', 'normal', 1500)
    }
}
const previousQuestion = () => {
    if (currentIndex != 0) {
        captureTimeSpent()
        currentIndex -= 1
        renderQuestion(currentIndex);
    }
}
const showOldSelectedAnswer = () => {
    if (questionsCache[currentQuestionId()]?.type == "mcq") {
        document.querySelectorAll('.option').forEach(d => {
            d.classList.remove('marked')
        })
        if (userAnswers[currentQuestionId()]?.value != null) {
            document.getElementById(`optDiv${userAnswers[currentQuestionId()].value}`).classList.add('marked')
        }
    }
    else {
        answerInput.value = userAnswers[currentQuestionId()]?.value ?? ""
    }
    updateReviewBtn();
    window.scrollTo({ top: 0 })
}

//     Full Image System

document.getElementById('full_image_btn').addEventListener('click', () => {
    document.getElementById('full-checkbox').checked = true;
    let curImage = questionsCache[currentQuestionId()].image
    document.querySelector('.fullImg img').src = curImage;
})
function updateReviewBtn() {
    if (reviewList.includes(currentIndex) || answeredAndMarkedList.includes(currentIndex)) {
        reviewBtn.checked = true;
        document.getElementById('mark-text').innerText = "Marked for Review"
    }
    else {
        reviewBtn.checked = false;
        document.getElementById('mark-text').innerText = "Mark for Review"
    }
}

const submitPage = (t) => {
    let checkbox = document.getElementById('Submit-checkbox');
    if (t == 1) {
        checkbox.checked = true;
        document.getElementById('test-title').innerText = document.title;
        document.getElementById('visit2').innerText = notVisitedQuestions
        document.getElementById('Answered2').innerText = answersList.length;
        document.getElementById('totalQ').innerText = totalQuestions;
        document.getElementById('MarkforReview2').innerText = reviewList.length;
        document.getElementById('aAndm2').innerText = answeredAndMarkedList.length;
        document.getElementById('NotAnswersed2').innerText = totalQuestions - (notVisitedQuestions + answersList.length + reviewList.length + answeredAndMarkedList.length);

    }
    else if (t == 0) {
        checkbox.checked = false;
    }
}

const goToSubmit = () => {
    document.getElementById('Submit-checkbox').checked = false;
    let submitModal = document.querySelector('.sumbit-conform');
    submitModal.innerHTML = `
            <div class="main-box">
            <h3>Submit Test</h3>
            <p>Are you sure you want to submit the test?<br>
                No changes will be allowed <br>after submission
            </p>
            <div>
                <button id="userSubmitBtn">Submit</button>
                <button onclick="hideModal()">Resume</button>
            </div>
        </div>`;
    document.getElementById("userSubmitBtn").addEventListener('click', () => { userSubmit() })
    submitModal.style.display = 'flex';
}
function userSubmit() {
    hideModal()
    submitTest('submitted')
}
function formatTime(time) {
    let date = new Date(time)
    let timeString = date.toLocaleTimeString("en-us", {
        hour: "numeric", minute: "numeric", hour12: true
    })
    return timeString
}
const goToLeave = () => {
    document.getElementById('menu-checkBtn').checked = false;
    let submitModal = document.querySelector('.sumbit-conform');
    submitModal.innerHTML = `
            <div class="main-box">
            <h3>Heads up!</h3>
            <p>Leaving the test now will trigger auto submit <br> if you dont return before the <b> ${formatTime(testMeta.endTime)} </b>. <br> Want to exit anyway?
            </p>
            <div>
                <button onclick="leaveTest()">Exit</button>
                <button onclick="hideModal()">Resume</button>
            </div>
        </div>`;
    submitModal.style.display = 'flex';
}
const hideModal = () => {
    document.querySelectorAll('.modal').forEach(m => {
        m.style.display = 'none';
    })
}

document.querySelectorAll('.modal').forEach(m => {
    m.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            hideModal()
        }
    })
})
let toastQueue = []
let isToastShowing = false
const toast = (text, type = "normal", duration = 1500) => {
    toastQueue.push({ text, type, duration })
    processToastQueue()
}
const processToastQueue = () => {
    if (isToastShowing || toastQueue.length === 0) return
    const { text, type, duration } = toastQueue.shift()
    const toastBox = document.getElementById('toast')
    isToastShowing = true
    toastBox.innerHTML = `<p>${text}</p>`
    toastBox.className = "show " + type
    setTimeout(() => {
        toastBox.classList.remove('show')
        setTimeout(() => {
            isToastShowing = false
            processToastQueue()
        }, 100)
    }, duration)
}
function leaveTest() {
    syncAnswers()
    setTimeout(() => {
        window.location.replace('/')
    }, 300)
}

const submitTest = async (status = "submitted") => {
    await verifyToken()
    captureTimeSpent()
    if (awayTime > Date.now()) {
        awayTime -= Date.now()
    }
    stopSyncInterval()
    let finalPayload = {
        status,
        userAnswers,
        timeSpent,
        awayTime,
        tabSwitchCount,
        clientTime: Date.now()
    }
    let res = await fetchData(`/attempts/${attemptId}/submit-test`, "POST", { ...finalPayload })
    if (!res || !res.success) {
        toast('failed to submit test', "error")
        questionStartTime = Date.now()
        startSyncInterval()
        return
    }
    attemptId = null
    questionsCache = {}
    userAnswers = {}
    questionIds = []
    if (status == "submitted") {
        popUp("📑", "Test has been submitted successfully", "submit")
    }
}

//------------  Tab switch detected ---------------- //
let isAway = false;
let awayStart = null;
function handleAwayStart() {
    if (!isAway) {
        isAway = true
        awayStart = Date.now()
    }
    if (focusGuard.enabled && attemptId) {
        popUp('🚫Warning', 'You are trying to switch tab or minimize test avoid this otherwise test will be auto submitted.')
    }
}
function handleAwayEnd() {
    if (isAway) {
        isAway = true
        awayTime += Date.now() - awayStart
        isAway = false;
        awayStart = null
    }
    if (focusGuard.enabled && attemptId) {
        if (tabSwitchCount >= focusGuard.maxTabSwitch) {
            popUp("🕵 <br> Fired", 'You are switching tabs too many times <br> test is <b> auto-submitted <b>', "submit")
            submitTest("fired")
            return
        }
        if (awayTime >= focusGuard.maxAwayTime) {
            popUp("🕵 <br> Fired", 'You away too long from test! <br> test is <b>auto-submitted <b>', "submit")
            submitTest("fired")
        }
    }
}

function syncAnswers() {
    if (!attemptId) return
    let syncData = {
        userAnswers,
        timeSpent,
        awayTime,
        tabSwitchCount,
        clientTime: Date.now()
    }
    fetchData(`/attempts/${attemptId}/sync`, "POST", syncData)
}
function trySync() {
    if (navigator.onLine) {
        startSyncInterval()
        return
    }
    stopSyncInterval()
}
const startSyncInterval = () => {
    if (syncInterval) return
    syncInterval = setInterval(() => {
        syncAnswers()
    }, SYNC_INTERVAL_TIME)
}
setInterval(() => {
    trySync()
}, 10000)
function stopSyncInterval() {
    clearInterval(syncInterval)
    syncInterval = null
}
function initApp() {
    window.hideModal = hideModal
    window.leaveTest = leaveTest
    window.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            captureTimeSpent()
            handleAwayStart()
            stopSyncInterval()
            syncAnswers()
        }
        else {
            handleAwayEnd()
            tabSwitchCount++
            stopSyncInterval()
            syncAnswers()
            questionStartTime = Date.now()
        }
    })
    window.addEventListener('blur', () => {
        stopSyncInterval()
        syncAnswers()
        tabSwitchCount++
        handleAwayStart()
    })
    window.addEventListener('focus', () => {
        handleAwayEnd()
        stopSyncInterval()
        syncAnswers()
    })

    window.addEventListener("offline", () => {
        toast('Internet connection lost', "error", 3000)
        stopSyncInterval()
    })
    window.addEventListener("online", () => {
        toast('Internet connection back', "success")
        syncAnswers()
        startSyncInterval()
    })

    document.body.addEventListener('keydown', (e) => {
        if (e.key == 'ArrowLeft') {
            previousQuestion()
        }
        else if (e.key == "ArrowRight") {
            nextQuestion()
        }
    })
    document.querySelectorAll('.openSubmitPage').forEach(btn => {
        btn.addEventListener('click', () => { submitPage(1) })
    })
    document.getElementById('goToLeave').addEventListener('click', () => { goToLeave() })
    document.getElementById('goToSubmit').addEventListener('click', () => { goToSubmit() })
    document.getElementById('resumeTest').addEventListener('click', () => { submitPage(0) })
    startTest()
}
initApp()