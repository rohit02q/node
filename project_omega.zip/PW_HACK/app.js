import express from "express"
import { fetchData } from "./controllers/fetch.js"
import { BATCH_ID } from "./config/constant.js"
import Storage from "./controllers/storage.js"
const app = express()
const PORT = process.env.PORT || 5600
app.use(express.static('./frontend'))
app.get('/s', async (_, res) => {

    const SUBJECTS = await Storage.get("SUBJECTS")

    // const url = `/v3/batch-service/batch-config/${BATCH_ID}`
    // const url = `/batch-service/v1/batch-tags/${BATCH_ID}/subject/${SUBJECTS[0]._id}/topics?page=1&batchTagType=UNITS&limit=50&enabled=true`
    // const url = `/batch-service/v1/batch-tags/${BATCH_ID}/topics?page=1&batchSubjectIds=${SUBJECTS[5]._id}`
    const url = `/batch-service/v3/batch-subject-schedules/${BATCH_ID}/subject/${SUBJECTS[0]._id}/contents?skip=0&limit=1&contentType=EXERCISES&contentFilter=ALL&tagId=67fa0bfa33882ea1b7089a82`




    const resp = await fetchData(url)
    return res.json(resp)
})

app.listen(PORT, () => { console.log('Live Server is Running on port', PORT) })
