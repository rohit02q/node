import { TOKEN } from "../config/constant.js"
export const fetchData = async (url) => {
    const fetchUrl = 'https://api.penpencil.co' + url
    const headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + TOKEN
    }
    try {
        const res = await fetch(fetchUrl, {
            method: "GET",
            headers
        })
        return await res.json()
    }
    catch (e) {
        console.log(e)
        return null
    }
}