import fs from "fs"
import path from "path"
const FILE_NAME = "arjuna.json"
const filePath = path.resolve(import.meta.dirname, '../' + FILE_NAME)
const loadData = () => { return JSON.parse(fs.readFileSync(filePath, "utf-8")) }
class Storage {
    static get(path) {
        const data = loadData()
        try {
            const keys = path.split('/');
            return keys.reduce((acc, key) => {
                if (acc && acc[key] !== undefined) {
                    return acc[key]
                }
                return null
            }, data)

        } catch (error) {
            console.error(error)
            return null
        }
    }

    static set(path, value) {
        try {
            let data = loadData()
            const keys = path.split('/')
            let current = data;
            keys.slice(0, -1).forEach(key => {
                if (!current[key]) {
                    current[key] = {}
                }
                current = current[key]
            });
            current[keys[keys.length - 1]] = value
            fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
            console.log('File set succesfully')
            return true
        } catch (error) {
            console.error(error)
            return false
        }
    }
    static update(path, value) {
        const preData = this.get(path)
        this.set(path, { ...preData, ...value })
    }
}

export default Storage